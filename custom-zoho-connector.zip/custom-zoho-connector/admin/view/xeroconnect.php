<div class="wrap">
<h1>Xero API Settings</h1>
<?php if($_REQUEST['settings-updated'] == true){?>
<div class="notice notice-success is-dismissible"> 
	<p><strong>Settings saved.</strong></p>
</div>
<?php }

if(isset($_GET['msg']) && !empty($_GET['msg'])){?>
	<div class="notice notice-success is-dismissible"> 
		<p><strong><?php echo $_GET['msg'];?></strong></p>
	</div>
<?php
}

	$auth_request = '';
	
	$auth_url = site_url().'/wp-admin/admin-ajax.php?action=authxerologin';

	if(!empty(get_option('xero_client_id')) && !empty(get_option('xero_client_id'))){
		
		if(get_option('wc_xero_access_token') != '' && get_option('wc_xero_Refresh_Token') != ''){
			
			$auth_request .= '<span style="color: green;">You have authorized Xero App.</span>';
			
		}else{
			
			$auth_request .= '<a href="'.$auth_url.'" class="button-primary">'.__( 'Authorize Xero App', 'wc-zoho' ).'</a>';
		}
	}
	
	echo '<br>For Redirect URI in Xero App registration please add this url there - <b>'.site_url().'/wp-admin/admin-ajax.php?action=authxero</b>.&nbsp;'.$auth_request;

?>
<form method="post" action="options.php">
    <?php settings_fields( 'xero-settings-group' ); ?>
    <?php do_settings_sections( 'xero-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
			<th scope="row">Client ID</th>
			<td><input type="text" name="xero_client_id" value="<?php echo esc_attr( get_option('xero_client_id') ); ?>" style="width:55%;" required /></td>
        </tr>
         
        <tr valign="top">
			<th scope="row">Client Secret</th>
			<td><input type="text" name="xero_client_secret" value="<?php echo esc_attr( get_option('xero_client_secret') ); ?>" style="width:55%;" required /></td>
        </tr>
		
		<tr valign="top">
			<th scope="row">Xero Webhook Key</th>
			<td><input type="text" name="xero_webhook_key" value="<?php echo esc_attr( get_option('xero_webhook_key') ); ?>" style="width:55%;" /></td>
        </tr>
		
		<tr valign="top">
			<th scope="row">Payment Currency</th>
			<td>
				<select name="xero_currency">
					<option value="">Select</option>
					<option value="£" <?php if(get_option('xero_currency') == '£'){ echo "selected";}?>>GBP</option>
					<option value="$" <?php if(get_option('xero_currency') == '$'){ echo "selected";}?>>USD</option>
					<option value="€" <?php if(get_option('xero_currency') == '€'){ echo "selected";}?>>EURO</option>
				</select>
			</td>
        </tr>
		
    </table>
    <?php submit_button(); ?>
</form>
</div>