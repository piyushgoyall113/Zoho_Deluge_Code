<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * This will fire at the very end of a (successful) form entry.
 *
 * @link  https://wpforms.com/developers/wpforms_process_complete/
 *
 * @param array  $fields    Sanitized entry field values/properties.
 * @param array  $entry     Original $_POST global.
 * @param array  $form_data Form data and settings.
 * @param int    $entry_id  Entry ID. Will return 0 if entry storage is disabled or using WPForms Lite.
 */
 
function wpf_dev_process_complete( $fields, $entry, $form_data, $entry_id ) {
	
	global $wpdb;
	
	if ( $form_data[ 'id' ]  !== 1214  || $form_data[ 'id' ]  !== 44) {
        
		if($entry_id  > 0)
		{
			
			if($form_data[ 'id' ] == 1214)
			{
				$response = sent_data_crm($fields);
				
				//echo $response.'vfvfv'; die;
				
				if(!empty($response)){
					
					// Get the full entry object
					$entry = wpforms()->entry->get( $entry_id );
				 
					// Fields are in JSON, so we decode to an array
					$entry_fields = json_decode( $entry->fields, true );
				 
					$entry_fields[166][ 'value' ] = $response;
					
					// Convert back to json
					$entry_fields = json_encode( $entry_fields );
				 
					// Save changes
					wpforms()->entry->update( $entry_id, array( 'fields' => $entry_fields ), '', '', array( 'cap' => false ) );
					
					$userID = validate_duplicateCenterUserID($fields[168]['value']);
					
					update_user_meta($userID, 'zoho_record_id',$response);
					update_user_meta($userID, 'Application_Status',"Pending");
					
					/* Add centre qualification in custom table */
					
					$qualification   = $_POST['wpforms']['fields']['cq'];
					
					$TableQualifications = $wpdb->prefix.'center_register_qualification';
					
					foreach($qualification as $centerqualification){
						
						$wpdb->insert(
									$TableQualifications,
									array(
											'center_id'          =>    $userID,
											'qualification_id'   =>    $centerqualification,
											'date'               =>    date('Y-m-d H:i:s')
									)
								);
					}
					
			
				}
				
			}else{
				
				$response = sent_register_learners_data_crm($fields);
			}
			
			
		}
	
	}else{
		
		return;
	}
}
add_action( 'wpforms_process_complete', 'wpf_dev_process_complete', 10, 4 );

/* Send Data To ZOHO */

function sent_data_crm($data){
	
	//echo '<pre>'; print_r($data);
	//echo '<pre>'; print_r($_POST);  die;
	
	$documents = array();
	
	$zoho = array();
	
	$zoho_record_id = 0;
	
	/* Centre Information */
	
	if($data[54]['value'] == 'Yes I understand the requirements')
	{
		$zoho['Yes_I_understand_the_requirements']    = true;
	}
	
	//$zoho['Name']              				= $data[127]['value'];
	$zoho['Name']              				= $data[1]['value'];
	$applicationType 						= $data[123]['value'];
	$zoho['Application_type']               = $applicationType;
	$zoho['The_name_of_your_Organization']  = $data[1]['value'];
	$zoho['The_name_of_the_Lead_Centre']    = $data[124]['value'];
	$zoho['Phone_1']    					= $data[5]['value'];
	$zoho['Phone_1']    					= $data[5]['value'];
	$zoho['Address_Line_1']    			    = $data[6]['address1'];
	$zoho['Address_Line_2']    				= $data[6]['address2'];
	$zoho['City']    					    = $data[6]['city'];
	$zoho['State_Province_Region']    		= $data[6]['state'];
	$zoho['Postal_Code']    				= $data[6]['postal'];
	$zoho['Country']    					= $data[6]['country'];
	$zoho['Organization_type']    		    = $data[9]['value'];
	$zoho['Website_URL']    		    	= $data[7]['value'];
	$zoho['Email']    		    			= $data[8]['value'];
	$zoho['Facebook']    		    		= $data[131]['value'];
	$zoho['Twitter']    		    		= $data[132]['value'];
	$zoho['Instagram']    		    		= $data[133]['value'];
	$zoho['Company_registration_number']    = $data[53]['value'];
	$DevelopmentAssociate 					= $data[136]['value'];
	
	
	
	if($DevelopmentAssociate == 'Yes'){
		$zoho['Were_you_referred_to_ATHE_by_an_ATHE_Business_Deve']    = true;
		$zoho['Business_Development_Associate_Email']                  = $data[137]['value'];
	}
	
	$Qualification_Development 					= $data[129]['value'];
	if($DevelopmentAssociate != ''){
		$zoho['Qualification_Development']    = true;
	}
	
	/* Contact Details */
	
	$zoho['Head_of_Centre_Job_Title']    = $data[14]['value'];
	$zoho['Name1']    					 = $data[13]['value'];
	$zoho['Contact_Email']               = $data[15]['value'];
	
	$zoho['Finance_Contact_Job_Title']    = $data[16]['value'];
	$zoho['Finance_Contact_Name']    	  = $data[17]['value'];
	$zoho['Finance_Contact_Email']        = $data[18]['value'];
	
	$zoho['Quality_Assurance_Coordinator_Job_Title']  = $data[19]['value'];
	$zoho['Quality_Assurance_Coordinator_Name']    	  = $data[20]['value'];
	$zoho['Quality_Assurance_Coordinator_Email']      = $data[21]['value'];
	
	$zoho['Centre_Administrator_Job_Title']    = $data[23]['value'];
	$zoho['Centre_Administrator_Name']    	   = $data[25]['value'];
	$zoho['Centre_Administrator_Email']        = $data[51]['value']; 
	
	/* Centre Training – Centre Recognition => Create a sub form Array */
	
	$subform = [
					0 => ['Name1' => $data[139]['value'], 'Email' => $data[140]['value'], 'Job_Title' => $data[141]['value'] ],
					1 => ['Name1' => $data[143]['value'], 'Email' => $data[144]['value'], 'Job_Title' => $data[145]['value'] ],
					2 => ['Name1' => $data[146]['value'], 'Email' => $data[147]['value'], 'Job_Title' => $data[148]['value'] ],
					3 => ['Name1' => $data[149]['value'], 'Email' => $data[150]['value'], 'Job_Title' => $data[151]['value'] ],
					4 => ['Name1' => $data[152]['value'], 'Email' => $data[153]['value'], 'Job_Title' => $data[154]['value'] ],
					5 => ['Name1' => $data[155]['value'], 'Email' => $data[156]['value'], 'Job_Title' => $data[157]['value'] ],
					6 => ['Name1' => $data[158]['value'], 'Email' => $data[159]['value'], 'Job_Title' => $data[160]['value'] ],
					7 => ['Name1' => $data[161]['value'], 'Email' => $data[162]['value'], 'Job_Title' => $data[163]['value'] ]
	
			   ];
			   
	$zoho['Centre_Training_Centre']	= $subform;	
	
	
	$zoho['Do_you_wish_to_deliver_bespoke_qualifications']     = $data[125]['value']; 
	
	/* Delivery Information */
	
	$zoho['Are_you_planning_on_transferring_Learners_from_ano']     = $data[58]['value']; 
	
	$deliverymethods = explode( "\n", trim( $data[ 122 ]['value'] ) );
	
	$newarr2 = array();
    
    foreach($deliverymethods as $key1=>$new1){
    	$newarr2[$key1] = trim($new1);
    }
	
	$zoho['What_delivery_methods_do_you_offer']        				  = $newarr2;
	$zoho['Please_give_details_of_your_buildings_and_size_of']        = $data[33]['value']; 
	$zoho['Please_give_ownership_details_of_centre_premises']         = $data[34]['value']; 
	$zoho['Do_you_deliver_any_other_qualifications']                  = $data[35]['value']; 
	$zoho['How_many_learners_are_currently_enrolled']                 = $data[36]['value']; 
	$zoho['How_many_learners_are_you_planning_on_registering']        = $data[134]['value']; 
	$zoho['How_many_years_has_your_organisation_been_deliveri']       = $data[116]['value']; 
	$zoho['How_many_teaching_staff_are_currently_employed']           = $data[117]['value']; 
	$zoho['Is_your_organisation_recognised_by_any_regulatory']        = $data[40]['value']; 
	
	if(!empty($data[115]['value'])){
		
		$zoho['Premises_documentation']    = true;
	}
	
	/* VAT and Funding Information */
	
	$zoho['Section_5_Centre_VAT_Status_and_Funding']        	= $data[43]['value']; 
	$zoho['VAT_Registration_Number']        					= $data[165]['value']; 
	$VATregistered 												= !empty($data[165]['value']) ? 'Yes' : 'No';
	$zoho['Are_you_VAT_registered']         					= $VATregistered;
	$zoho['VAT_Exempt']         								= $data[113]['value']; 
	$zoho['Does_your_centre_receive_funding_from_the_Skills']   = $data[45]['value']; 
	
	/* ---------- Documents 1 checklist  -------- */
	
	if(!empty($data[100]['value'])){
		$zoho['Quality_systems']    = true;
	}
	
	if(!empty($data[98]['value'])){
		$zoho['A_list_of_the_staff']    = true;
	}
	
	if(!empty($data[97]['value'])){
		$zoho['Staffing_structures_and_or_organisation_chart']    = true;
	}
	
	if(!empty(trim($data[99]['value']))){
		$zoho['Systems_for_staff_development']    = true;
	}
	
	if(!empty($data[96]['value'])){
		$zoho['Assessment_strategy_or_plan']    = true;
	}
	
	if(!empty($data[95]['value'])){
		$zoho['Assessment_feedback']    = true;
	}
	
	if(!empty($data[92]['value'])){
		$zoho['Resubmissions']    = true;
	}
	
	if(!empty($data[93]['value'])){
		$zoho['Appeals_procedure']    = true;
	}
	
	/* ---------- Documents 2 checklist  -------- */
	
	if(!empty($data[90]['value'])){
		$zoho['Assessment_records']    = true;
	}
	
	if(!empty($data[89]['value'])){
		$zoho['Recruitment_of_learners']    = true;
	}
	
	if(!empty($data[88]['value'])){
		$zoho['Resources']    = true;
	}
	
	if(!empty($data[87]['value'])){
		$zoho['An_example_of_an_overarching_curriculum_plan']    = true;
	}
	
	if(!empty($data[86]['value'])){
		$zoho['Policy_and_systems_for_dealing_with_malpractice']    = true;
	}
	
	if(!empty($data[94]['value'])){
		$zoho['Health_and_safety']    = true;
	}
	
	if(!empty($data[83]['value'])){
		$zoho['Administration']    = true;
	}
	
	if(!empty($data[84]['value'])){
		$zoho['Equality_and_diversity']    = true;
	}
	
	if(!empty($data[82]['value'])){
		$zoho['Complaints_policy']    = true;
	}
	
	if(!empty($data[81]['value'])){
		$zoho['Data_protection']    = true;
	}
	
	/* ---------- Documents  -------- */
	
	foreach($data as $files){
		
		if($files['type'] == 'file-upload'){
			
			if(!empty($files['value'])){
			
				$file = explode( "\n", stripslashes( $files['value'] ) );
				array_push($documents,$file);
			}
		}
	}
	
	/* Final step data  */
	
	$zoho['How_did_you_hear_about_ATHE']   = $data[48]['value']; 
	
	$RecognisedCentre  = explode( "\n", trim( $data[ 49 ]['value'] ) );
	
	$newarr3 = array();
    
    foreach($RecognisedCentre as $key3=>$new3){
    	$newarr3[$key3] = trim($new3);
    }
	
	$zoho['What_made_you_interested_in_becoming_an_ATHE_RC']   = $newarr3; 
	
	$zoho['Centre_ID_Number']    		  	= $data[168]['value'];
	
	$zoho['Payment_Arrangement']    		= $data[172]['value'];
	
	$zoho['Application_Status']    		    = 'Pending';
	
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		
		$active_access_token = get_refresh_token();
	}
	
	/* Lead Information */
	
	$ZohoLead = array();
	
	$ZohoLead['First_Name']  = $data[13]['first'];
	$ZohoLead['Last_Name']   = $data[13]['last'];
	$ZohoLead['Company']     = $data[1]['value'];
	$ZohoLead['Phone']       = $data[5]['value'];
	$ZohoLead['Email']       = $data[8]['value'];
	$ZohoLead['Lead_Source'] = 'Website - Athe Center Portal';
	$ZohoLead['Lead_Status'] = 'Completed application form';
	
	$ZohoLead['Street']      = $data[6]['address1'].' '.$data[6]['address2'];
	$ZohoLead['State']       = $data[6]['state'];
	$ZohoLead['Country']     = $data[6]['country'];
	$ZohoLead['City']        = $data[6]['city'];
	$ZohoLead['Zip_Code']    = $data[6]['postal'];
	
	$ZohoLead['Website']    = $data[7]['value'];

	if($active_access_token === 1){
		
		$ZOHOdata         = array();
		$ZOHOdata[]       = $zoho;
		$params       	  = array('data'=>$ZOHOdata);			
		$ZohoRecordData   = request_zoho_data('Center_Registration', $params,'POST');
		
		if($ZohoRecordData['body']['data'][0]['status'] == 'success'){
			
			
			$zoho_record_id =  $ZohoRecordData['body']['data'][0]['details']['id'];
			
			
			$ZohoLead['Center_Name']    = array("id"=>$zoho_record_id);
			
			$ZOHOLeaddata         = array();
			$ZOHOLeaddata[]       = $ZohoLead;
		
			$paramsLeads       	  = array('data'=>$ZOHOLeaddata);
			$ZohoInsertLeadData   = request_zoho_data('Leads', $paramsLeads,'POST'); 		
			
			
			/* Qualifications Information */
	
			$qualification   = $_POST['wpforms']['fields']['cq'];
			
			 $newarr = array();
			
			foreach($qualification as $key=>$new){
				
				$newarr['data'][$key]["Center_Registration"] = array("id"=>$zoho_record_id);
				$newarr['data'][$key]["Which_ATHE_qualifications_are_you_looking"] = array("id"=>$new);
			}
			
			
			$zohoLinkingModuleData = request_zoho_data('Center_Re_X_Qualifica2', $newarr,'POST'); 	
			
			if(!empty($documents)){
				foreach($documents as $AttachmentDocument){
					foreach($AttachmentDocument as $urldocument){
						$Attachparams = array('attachmentUrl'=>$urldocument);	
						$SendAttachment = request_zoho_attachmentData('Center_Registration/'.$zoho_record_id.'/Attachments', $Attachparams,'POST');
					}
				}
			}
		}
	}
	
	
	return $zoho_record_id;	
}

/* Register Learners Form Data Sent To ZOHO CRM */

function sent_register_learners_data_crm($data){

	
	$RegisterZOHOParam = array();
	
	$RegisterZOHOParam['Name']              = $data[10]['value'];
	$RegisterZOHOParam['Government_Funded'] = $data[13]['value'];
	
	$RegisterZOHOParam['Date_of_birth'] 	= date('Y-m-d',$data[11]['unix']);
	
	$RegisterZOHOParam['Gender']              = $data[14]['value'];
	$RegisterZOHOParam['Ethnicity']           = $data[15]['value'];
	
	$RegisterZOHOParam['Centre_ID_Number']    = $data[2]['value'];
	$RegisterZOHOParam['The_Qualification']   = $data[9]['value'];
	$RegisterZOHOParam['The_site_where_delivery_is_taking_place']           		= $data[4]['value'];
	$RegisterZOHOParam['Start_Date']           										= date('Y-m-d',$data[5]['unix']);
	$RegisterZOHOParam['End_Date']           										= date('Y-m-d',$data[6]['unix']);
	$RegisterZOHOParam['I_Agree_to_be_bound_by_the_terms_and_conditions']           = true;
	
	$filedata = $data[7]['value'];
	
	$fileLink = '';
	
	if(!empty($filedata)){
		
		 $uploaded_files2 =   json_decode($filedata);
		 
		 $first_entry     =   current($uploaded_files2);
		 
		 $fileLink        =   urldecode($first_entry->link);
	}
	
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		$active_access_token = get_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$ZOHOLearningdata         = array();
		$ZOHOLearningdata[]       = $RegisterZOHOParam;
		$params       	          = array('data'=>$ZOHOLearningdata);			
		$Data                     = request_zoho_data('Learner_Registration', $params,'POST');
	
		
		if($Data['body']['data'][0]['status'] == 'success'){
			
			$zoho_record_id =  $Data['body']['data'][0]['details']['id'];
			
			if(!empty($fileLink)){
				
				$Attachparams = array('attachmentUrl'=>$fileLink);	
				$SendAttachment = request_zoho_attachmentData('Learner_Registration/'.$zoho_record_id.'/Attachments', $Attachparams,'POST');
			}
			
		}
		
		//die('completed process');
	}
}

/* function Image download from url and save in Temp folder then rename and send to ZOHO CRM Attachment */

function image_dowmload_rename($documents){

	
	$renameImage = array();
	
	$path 	= TEMP_FOLDER;
	
	$siteurl = TEMP_URL;
	
	if(!empty($documents)){
		
		foreach($documents as $key=>$imageData){
			
			$fileRename  = str_replace(" ",'',$imageData['Filename']);
			$fileUrlData = $imageData['fileUrlData'];
			
			foreach($fileUrlData as $key1=>$urldocument){
				
				// Use basename() function to return the base name of file
				$file_name = basename($urldocument);
				$ext       = pathinfo($file_name, PATHINFO_EXTENSION);
				
				$indexKey = $key.$key1;
				
				$newimageName =  $fileRename.'-'.$indexKey.time().'.'.$ext;
				
				if (file_put_contents($path.$file_name, file_get_contents($urldocument)))
				 {
					
					rename( $path.$file_name, $path.$newimageName) ;
					
					$renameImage[] = $siteurl.$newimageName;
					
				 }
				 
			}
		 
		}
		 
		return $renameImage;
	}
}
?>