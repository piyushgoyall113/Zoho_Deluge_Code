<?php 
add_action('rest_api_init', function () {
	
	/* Zoho Qualification Sync  api */
	
	register_rest_route( 'zohocustom/v1', 'authqualificationzohosync',array(
                'methods'             => 'POST',
                'callback' 			  => 'calback_authqualificationzohosync',
	));
	
	register_rest_route( 'zohocustom/v1', 'authqualificationDeletezohosync',array(
                'methods'  => 'POST',
                'callback' => 'calback_authqualificationDeletezohosync'
    ));
	
	register_rest_route( 'zohocustom/v1', 'unitcreateupdatezohosync',array(
                'methods'  => 'POST',
                'callback' => 'calback_unitcreateupdatezohosync'
    ));
	
	register_rest_route( 'zohocustom/v1', 'unitdeletezohosync',array(
                'methods'  => 'POST',
                'callback' => 'calback_unitdeletezohosync'
    ));
	
	register_rest_route( 'zohocustom/v1', 'relationUnitqualificationcreateupdatezohosync',array(
                'methods'  => 'POST',
                'callback' => 'calback_relationUnitqualificationcreateupdatezohosync'
    ));
	
	register_rest_route( 'zohocustom/v1', 'DeleteRelationQU',array(
                'methods'  => 'POST',
                'callback' => 'calback_DeleteRelationQU'
    ));
	
	register_rest_route( 'zohocustom/v1', 'registerNewqualification',array(
                'methods'  => 'POST',
                'callback' => 'calback_registerNewqualification'
    ));
	
	register_rest_route( 'zohocustom/v1', 'SyncCentreData',array(
                'methods'  => 'POST',
                'callback' => 'SyncCentreData_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'EqaregistrationFromZoho',array(
                'methods'  => 'POST',
                'callback' => 'EqaregistrationFromZoho_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'EqaResultsRequestFromZoho',array(
                'methods'  => 'POST',
                'callback' => 'EqaResultsRequestFromZoho_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'EqaStatusChangeNoResponse',array(
                'methods'  => 'POST',
                'callback' => 'EqaStatusChangeNoResponse_callbackv1'
    ));
	
	
	register_rest_route( 'zohocustom/v1', 'eqaresultreport',array(
                'methods'  => 'POST',
                'callback' => 'eqaresultreport_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'CentreActionPoint',array(
                'methods'  => 'POST',
                'callback' => 'CentreActionPoint_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'CentreActionPointStatus',array(
                'methods'  => 'POST',
                'callback' => 'CentreActionPointStatus_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'CentreReportData',array(
                'methods'  => 'POST',
                'callback' => 'CentreReportData_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'CertificateCSV',array(
                'methods'  => 'POST',
                'callback' => 'CertificateCSV_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'Qualificationachieved',array(
                'methods'  => 'POST',
                'callback' => 'Qualificationachieved_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'DeleteCentreQualification',array(
                'methods'  => 'POST',
                'callback' => 'DeleteCentreQualification_callbackv1'
    ));
	
	register_rest_route( 'zohocustom/v1', 'UpdateLearnersDates',array(
                'methods'  => 'POST',
                'callback' => 'UpdateLearnersDates_callbackv1'
    ));
	
}); 

/* Zoho Qualification callback */

function calback_authqualificationzohosync($request){

	
	//$path = $_SERVER['DOCUMENT_ROOT'].'/data.txt'; 
	
	//file_put_contents($path, print_r($_REQUEST,true).PHP_EOL, FILE_APPEND | LOCK_EX);

	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'custom_qualification';
		
		$record_id = $_REQUEST['record_id'];
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		if(!empty($data))
		{
			
			$qualification = $wpdb->get_row('SELECT zoho_record_id FROM '.$table.' WHERE zoho_record_id = "'.$record_id.'"');
			
			if(!empty($qualification))
			{
			
				
				$wpdb->update(
								$table,
								array(
										'name'        				=> $data['Qualification_Name'],
										'date'        			    => date('Y-m-d H:i:s'),
										'bespoke'           		=> $data['bespoke'],
										'qualification_level'       => $data['qualification_level'],
										'total_credits'           	=> $data['total_credits'],
										'qualification_number'      => $data['qualification_number'],
										'late_fees'           		=> $data['late_fees'],
									 ),
								array('zoho_record_id'=>$record_id),
								array('%s','%s','%s','%s','%s','%s','%s'),
								array('%s')
							 );
			}else{
				
				
				$wpdb->insert(
								$table,
								array(
										'name'        				=> $data['Qualification_Name'],
										'zoho_record_id'    		=> $record_id,
										'date'             			=> date('Y-m-d H:i:s'),
										'bespoke'           		=> $data['bespoke'],
										'qualification_level'       => $data['qualification_level'],
										'total_credits'           	=> $data['total_credits'],
										'qualification_number'      => $data['qualification_number'],
										'late_fees'           		=> $data['late_fees'],
										
									 ),
								array('%s','%s','%s','%s','%s','%s','%s','%s')
							 );
				
			}
		}
	}
}

/* Delete Qualification From ZoHO sync */
function calback_authqualificationDeletezohosync(){
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'custom_qualification';
		$record_id = $_REQUEST['record_id'];
		
		$wpdb->delete(
						$table,
						array('zoho_record_id'=>$record_id),
						array('%s')
					 );
	}
}

/* Zoho unit sync */

function calback_unitcreateupdatezohosync($request){
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		
		
		global $wpdb;
		
		$table = $wpdb->prefix.'zoho_unit';
		
		$record_id = $_REQUEST['record_id'];
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		if(!empty($data))
		{
			
			$unit = $wpdb->get_row('SELECT zoho_unit_id FROM '.$table.' WHERE zoho_unit_id = "'.$record_id.'"');
			
			if(!empty($unit))
			{
			
				
				$wpdb->update(
								$table,
								array(
										'unit_name'       => $data['Unit_Name'],
										'code'            => $data['Code'],
										'created'         => date('Y-m-d H:i:s'),
										'unit_credit_value'      => $data['unit_credit_value'],
										'unit_ssa'               => $data['unit_ssa'],
										'unit_level'             => $data['unit_level'],
										'guided_learning_hours'  => $data['guided_learning_hours']
									 ),
								array('zoho_unit_id'=>$record_id),
								array('%s','%s','%s','%s','%s','%s','%s'),
								array('%s')
							 );
							 
							 
					file_put_contents($path, print_r($wpdb->last_query,true).PHP_EOL, FILE_APPEND | LOCK_EX);	
					
			}else{
				
				
				$wpdb->insert(
								$table,
								array(
										'unit_name'         => $data['Unit_Name'],
										'zoho_unit_id'      => $record_id,
										'code'              => $data['Code'],
										'created'           => date('Y-m-d H:i:s'),
										'unit_credit_value'      => $data['unit_credit_value'],
										'unit_ssa'               => $data['unit_ssa'],
										'unit_level'             => $data['unit_level'],
										'guided_learning_hours'  => $data['guided_learning_hours']
									 ),
								array('%s','%s','%s','%s','%s','%s','%s','%s')
							 );
				
			}
		}
	}
}

/* Delete unit From wordpress sync */
function calback_unitdeletezohosync(){
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'zoho_unit';
		$record_id = $_REQUEST['record_id'];
		
		$wpdb->delete(
						$table,
						array('zoho_unit_id'=>$record_id),
						array('%s')
					 );
	}
}

/* Relation Unit and Qualification */
function calback_relationUnitqualificationcreateupdatezohosync($request){
	
	//$path = $_SERVER['DOCUMENT_ROOT'].'/data.txt'; 
	
	//file_put_contents($path, print_r($_REQUEST,true).PHP_EOL, FILE_APPEND | LOCK_EX);
	
	//echo '<pre>'; print_r($request->get_body()); die;
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'zoho_relation_unit_qualification';
		
		$record_id = $_REQUEST['record_id'];
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		if(!empty($data))
		{
			
			$unitRelation = $wpdb->get_row('SELECT relation_zoho_id FROM '.$table.' WHERE relation_zoho_id = "'.$record_id.'"');
			
			if(!empty($unitRelation))
			{
			
				
				$wpdb->update(
								$table,
								array(
										'quali_id'       => $data['quali_id'],
										'unit_id'        => $data['unit_id'],
										'type'           => $data['type'],
										'update'         => date('Y-m-d H:i:s')
									 ),
								array('relation_zoho_id'=>$record_id),
								array('%s','%s','%s','%s'),
								array('%s')
							 );
			}else{
				
				
				$wpdb->insert(
								$table,
								array(
										'relation_zoho_id'      => $record_id,
										'quali_id'              => $data['quali_id'],
										'unit_id'      			=> $data['unit_id'],
										'type'              	=> $data['type'],
										'update'           		=> date('Y-m-d H:i:s')
									 ),
								array('%s','%s','%s','%s','%s')
							 );
				
			}
		}
	}
}

/* delete relation b/w qualification and unit from zoho side */
function calback_DeleteRelationQU(){
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'zoho_relation_unit_qualification';
		$record_id = $_REQUEST['record_id'];
		
		$wpdb->delete(
						$table,
						array('relation_zoho_id'=>$record_id),
						array('%s')
					 );
	}
	
}

/* Add new qualification for centre from zoho  */
function calback_registerNewqualification(){
	
	$path = $_SERVER['DOCUMENT_ROOT'].'/data.txt'; 
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		global $wpdb;
		
		$table = $wpdb->prefix.'center_register_qualification';
		$record_id = $_REQUEST['record_id'];
		
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		$ZoHOCentreID              = $data['centreID'];
		$ZoHOCentreQualificationID = $data['quali_ID'];
		
		$userID = get_user_id_by_zohoid($ZoHOCentreID);
		
	    $alreadyExists = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE center_id = %d AND qualification_id	= %s",$userID,$ZoHOCentreQualificationID));
		
		if(empty($alreadyExists)){
			
			$wpdb->insert(
								$table,
								array(
										'center_id'      		=> $userID,
										'qualification_id'      => $ZoHOCentreQualificationID,
										'date'           		=> date('Y-m-d H:i:s')
									 ),
								array('%d','%s','%s')
							 );
		}
		
	}
}

/* Update Centre Profile Data Frpm ZOHO to WP */
function SyncCentreData_callbackv1($request){
	
	global $wpdb;
	
	//$path = $_SERVER['DOCUMENT_ROOT'].'/data.txt';
	
	//file_put_contents($path, print_r($_REQUEST,true).PHP_EOL, FILE_APPEND | LOCK_EX);
	
	if(isset($_REQUEST['record_id']) && $_REQUEST['record_id'] != '')
	{
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		//file_put_contents($path, print_r($data,true).PHP_EOL, FILE_APPEND | LOCK_EX);
		
		$userID = get_user_id_by_zohoid($_REQUEST['record_id']);
		
		$xero_contact_id  = $data['xero_contact_id'];
		$discount         = $data['discount'];
		$tax              = $data['tax'];
		$tag              = $data['tag'];
		$email            = $data['email'];
		
		$Address_Line_1   = $data['Address_Line_1'];
		$Address_Line_2   = $data['Address_Line_2'];
		$City             = $data['City'];
		$state            = $data['state'];
		$country          = $data['country'];
		$zipcode          = $data['zipcode'];
		$zohoOwner        = $data['zohoOwner'];
		
		
		
		$HighPerformingStatus = $tag == 'true' ? 1 : 0;
		
		update_user_meta($userID,'xero_contact_id',$xero_contact_id);
		update_user_meta($userID,'discount',$discount);
		update_user_meta($userID,'High_Performing_Status',$HighPerformingStatus);
		update_user_meta($userID,'tax',$tax);
		
		update_user_meta($userID,'Address_Line_1',$Address_Line_1);
		update_user_meta($userID,'Address_Line_2',$Address_Line_2);
		update_user_meta($userID,'City',$City);
		update_user_meta($userID,'state',$state);
		update_user_meta($userID,'country',$country);
		update_user_meta($userID,'zipcode',$zipcode);
		update_user_meta($userID,'zohoOwner',$zohoOwner);
	}
}

/* EQA registration from zoho into WP */
function EqaregistrationFromZoho_callbackv1($request){
	
	
	global $wpdb;
	
	if(isset($_REQUEST['recoard_id']) && $_REQUEST['recoard_id'] != '')
	{
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		$userID = get_user_id_by_zohoid($_REQUEST['recoard_id']);
		
		if($userID > 0){
			
			$user_data = wp_update_user( array( 'ID' => $userID, 'first_name' => $data['name'] , 'user_email' => $data['email']) );
			
			update_user_meta($userID,'_EQA_phone',$data['phone']);
			update_user_meta($userID,'_EQA_SecondaryEmail',$data['SecondaryEmail']);
			update_user_meta($userID,'_EQA_ContractStartDate',$data['ContractStartDate']);
			update_user_meta($userID,'_EQA_ContractEndDate',$data['ContractEndDate']);
			update_user_meta($userID,'_EQA_Status',$data['Status']);
			update_user_meta($userID,'_EQA_Rating',$data['Rating']);	
			update_user_meta($userID,'_EQA_Skills',$data['Skills']);	
			update_user_meta($userID,'_EQA_Levels',$data['Levels']);	
			update_user_meta($userID,'_EQA_Task',$data['Task']);	
			
			
		}else{
			
			$password = EQArandomPassword();
			
			$userID = wp_insert_user(array(
			
						'user_login'		=> $data['email'],
						'user_pass'	 		=> $password,
						'user_email'		=> $data['email'],
						'first_name'		=> $data['name'],
						'user_registered'	=> date('Y-m-d H:i:s'),
						'role'				=> 'eqa'
					));
					
			if($userID){
			
				update_user_meta($userID,'zoho_record_id',$_REQUEST['recoard_id']);
				update_user_meta($userID,'_EQA_phone',$data['phone']);
				update_user_meta($userID,'_EQA_SecondaryEmail',$data['SecondaryEmail']);
				update_user_meta($userID,'_EQA_ContractStartDate',$data['ContractStartDate']);
				update_user_meta($userID,'_EQA_ContractEndDate',$data['ContractEndDate']);
				update_user_meta($userID,'_EQA_Status',$data['Status']);
				update_user_meta($userID,'_EQA_Rating',$data['Rating']);	
				update_user_meta($userID,'_EQA_Skills',$data['Skills']);	
				update_user_meta($userID,'_EQA_Levels',$data['Levels']);	
				update_user_meta($userID,'_EQA_Task',$data['Task']);	
				
				$data = array('name'=>$data['name'],'username'=>$data['email'],'password'=>$password);
				
				$sendWelcomeEmail = eqa_welcomeEmail($data);
			
				
			}

		}
	}
}

/* When ZOHO admin will approve and submit results From ZOHO then a request genertae into WP EQA dashboard */
function EqaResultsRequestFromZoho_callbackv1($request){
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	$zoho_request_no 		= $decodeBody->zoho_request_no;
	$zoho_eqaprofile_id 	= $decodeBody->zoho_eqaprofile_id;
	$zoho_request_id 		= $decodeBody->zoho_request_id;
	$asign_centre 			= $decodeBody->asign_centre;
	$learners_ids 			= $decodeBody->learners_ids;
	$request_status 		= $decodeBody->request_status;
	$zoho_qualification_id  = $decodeBody->zoho_qualification_id;
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_eqa_results_request';
	
	$wpdb->insert($table,
					array(
							'zoho_request_no' 		=> $zoho_request_no,
							'zoho_eqaprofile_id' 	=> $zoho_eqaprofile_id,
							'zoho_request_id' 		=> $zoho_request_id,
							'asign_centre' 			=> $asign_centre,
							'learners_ids' 			=> implode(',',$learners_ids),
							'request_status' 		=> $request_status,
							'zoho_qualification_id' => implode(',',$zoho_qualification_id),
							'created' 				=> date('Y-m-d H:i:s'),
							'updated' 				=> date('Y-m-d H:i:s'),
						 )
				);
						
}
 
/* change task status "No Response "*/
 
function EqaStatusChangeNoResponse_callbackv1($request){
	
	global $wpdb;
	
	 
	if(isset($_REQUEST['recoard_id']) && $_REQUEST['recoard_id'] != '')
	{
		
		$table = $wpdb->prefix.'zoho_eqa_results_request';
		
		$wpdb->update(
								$table,
								array(
										'request_status'  => 'No response',
										'updated'         => date('Y-m-d H:i:s')
									 ),
								array('zoho_request_id'=>$_REQUEST['recoard_id']),
								
							 );
	}
}

/* Once EQA will submit report by panel then not allow again submit report */

function eqaresultreport_callbackv1($request){
	
	global $wpdb;
	
	if(isset($_REQUEST['recoard_id']) && $_REQUEST['recoard_id'] != '')
	{
		
		$table = $wpdb->prefix.'zoho_eqa_results_request';
		
		$data 	   = json_decode(str_replace('\\', '', $_REQUEST['data']), true);
		
		$wpdb->update(
								$table,
								array(
										'result_report_id'  => $_REQUEST['recoard_id'],
									 ),
								array('zoho_request_id'=>$data['request_id']),
								
							 );
	}
}

/* Insert centre Action Point From ZOHO */
function CentreActionPoint_callbackv1($request){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_centre_action_point';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	if(!empty($body)){
		
		foreach($decodeBody as $data){
			
			$zoho_action_point_id = $data->zoho_action_point_id;
			$action_point_content = $data->action_point_content;
			$responsibility       = $data->responsibility;
			$priority             = $data->priority;
			$prior_to_submitting  = ( $data->prior_to_submitting == 1) ? $data->prior_to_submitting : 0;
			$deadline             = $data->deadline;
			$zoho_centre_id       = $data->zoho_centre_id;
			$status               = $data->status;
			
			$wpdb->Insert(
								$table,
								array(
										'zoho_action_point_id'  => $zoho_action_point_id,
										'action_point_content'  => $action_point_content,
										'responsibility'  		=> $responsibility,
										'priority'  			=> $priority,
										'prior_to_submitting_further_results'  => $prior_to_submitting,
										'deadline'  			=> $deadline,
										'status'  			    => $status,
										'zoho_centre_id'  		=> $zoho_centre_id,
										'created'  				=> date('Y-m-d H:i:s'),
										'updated'  				=> date('Y-m-d H:i:s')
									 )
						);
		}
	}
}

/* update centre action point status by SM */

function CentreActionPointStatus_callbackv1($request){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_centre_action_point';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);

	
	if(!empty($body)){
		
		$recoard_id = $decodeBody->recoard_id;
		$status     = $decodeBody->status;
		
		$wpdb->update($table,array('status'=>$status),array('zoho_action_point_id'=>$recoard_id));
		
		echo $wpdb->last_query;
	}
}

/* Save EQA report data and dispay to centre */
function CentreReportData_callbackv1($request){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_report_submission';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);

	
	if(!empty($body)){
		
		$centre_id    = $decodeBody->centre_id;
		$eqa_name     = $decodeBody->eqa_name;
		$report_data  = json_encode($decodeBody->report_data);
		
		$wpdb->Insert($table,array('centre_id'=>$centre_id,'eqa_name'=>$eqa_name,'report_data'=>$report_data,'created'=>date('Y-m-d H:i:s')));
	}
}

/* save certificate csv file in folder */
function CertificateCSV_callbackv1($request){
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body,true);
	
 
    //$filename = "certificate" . time() . ".csv"; 
    $filename = "certificate.csv"; 
	
	
	$csvRows = "";
	
	$csvHeading = "Qualification Name, Learner ID, Forename(s), Surname, DOB, Award Date, Qual Code, Credits Achieved, Certificate ID, Centre ID, Unit 1,Grade 1,Credits 1,Code 1,Level 1,Unit 2,Grade 2,Credits 2,Code 2,Level 2,Unit 3,Grade 3,Credits 3,Code 3,Level 3, Unit 4,Grade 4,Credits 4,Code 4,Level 4,Unit 5,Grade 5,Credits 5,Code 5,Level 5,Unit 6,Grade 6,Credits 6,Code 6,Level 6,Unit 7,Grade 7,Credits 7,Code 7,Level 7,Unit 8,Grade 8,Credits 8,Code 8,Level 8,Unit 9,Grade 9,Credits 9,Code 9,Level 9,Unit 10,Grade 10,Credits 10,Code 10,Level 10,Unit 11,Grade 11,Credits 11,Code 11,Level 11,Unit 12,Grade 12,Credits 12,Code 12,Level 12,Unit 13,Grade 13,Credits 13,Code 13,Level 13,Unit 14,Grade 14,Credits 14,Code 14,Level 14,Unit 15,Grade 15,Credits 15,Code 15,Level 15,Fname again,Sname again,Assessment language\n";
	
	foreach($decodeBody as $data){
		
		$QualificationName 		= $data['Qualification Name'];
		$LearnerID         		= $data['Learner ID'];
		$fname 			   		= $data['Forename(s)'];
		$Surname 				= $data['Surname'];
		$DOB 					= $data['DOB'];
		$AwardDate 				= $data['Award Date'];
		$QualCode 				= $data['Qual Code'];
		$CreditsAchieved 		= $data['Credits Achieved'];
		$CertificateID 			= $data['Certificate ID'];
		$CentreID 				= $data['Centre ID'];
		$assessmentlanguage 	= $data['assessment language'];
		
		$units = count($data['units']);
		
		$filledUnits = $unfilledUnits = "";
		
		$i = 1;
		foreach($data['units'] as $unitRow){
			
			$filledUnits .= $unitRow['Unit'].",".$unitRow['Grade'].",".$unitRow['Credits'].",".$unitRow['Code'].",".$unitRow['Level'].",";
			
		}
		
		$remaingUnits = 15 - $units;
		
		$removelastCommaFilledUnits =  rtrim($filledUnits,',');
		
		$blankData = array('Unit'=>' ','Grade'=>' ','Credits'=>' ','Code'=>' ','Level'=>' ');
		
		for($j=1;$j<=$remaingUnits;$j++){
			
			$unfilledUnits .= $blankData['Unit'].', '.$blankData['Grade'].', '.$blankData['Credits'].', '.$blankData['Code'].', '.$blankData['Level'].',';
		}
		
		$removelastCommaUnfilledFilledUnits =  rtrim($unfilledUnits,',');
		
		
		
		$csvRows.= $QualificationName.",".$LearnerID.",".$fname.",".$Surname.",".$DOB.",".$AwardDate.",".$QualCode.",".$CreditsAchieved.",". $CertificateID.",".$CentreID.",".$removelastCommaFilledUnits.",".$removelastCommaUnfilledFilledUnits.",".$fname.",".$Surname.",". $assessmentlanguage."\n"; 
		
	}

	$csvData=  $csvHeading . $csvRows ;

	$f = fopen (ZOHO_PLUGIN_PATH.'front/certificate/'.$filename,'w');
	fputs($f, $csvData);
	fclose($f);
	
	$response = array('url'=>ZOHO_PLUGIN_URL.'front/certificate/'.$filename);
	
	return json_encode($response);
}

/* update learners achive Qualification */
function Qualificationachieved_callbackv1($request){
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body,true);
	
	
	if(!empty($body)){
		
		global $wpdb;
		
		$table = $wpdb->prefix.'custom_learners_admission';
		
		foreach($decodeBody  as $row){
		
			$wpdb->update(
						$table,
						
						array(
								'overall_grade' 		=> $row['grade'],
								'is_completed'  		=> 1,
								'certification_id'		=> $row['certification_id'],
								'credit_value'          => $row['credit_value'],
								'updated'          		=> date('Y-m-d H:i:s'),
							),
							array(
									'qualification_id'  =>  $row['qid'],
									'learner_zoho_id'   =>  $row['lid']
								)
					);
					
		}
	}
}

/* When delete Qualification from ZOHO then delete centre Qualification from WP */

function DeleteCentreQualification_callbackv1($request){
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	global $wpdb;
		
	$table = $wpdb->prefix.'center_register_qualification';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body,true); 
	
	if(!empty($body)){
		
		$qid 		  = $decodeBody['qid'];
		$ZoHOCentreID = $decodeBody['cid'];
		
		$userID = get_user_id_by_zohoid($ZoHOCentreID);
		
		$wpdb->delete(
								$table,
								array(
										'center_id'      		=> $userID,
										'qualification_id'      => $qid,
									)
							 );	 
	}
}

/* Update Learners admission start and end date */
function UpdateLearnersDates_callbackv1($request){
	
	global $wpdb;
		
	$table = $wpdb->prefix.'custom_learners_admission';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body,true); 
	
	if(!empty($body)){
		
		$wpdb->update(
						$table,
						
						array(
								'start'     => $decodeBody['start_date'],
								'end'  		=> $decodeBody['end_date'],
							),
							array(
									'zoho_recoard_id'  =>  $decodeBody['admission_id']
								)
					);		
	}
}
?>