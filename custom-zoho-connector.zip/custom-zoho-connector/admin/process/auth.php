<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/* Zoho App registration */ 

add_action('wp_ajax_authzoho','zoho_authzoho');
function zoho_authzoho(){

		if(isset($_REQUEST['code']))
		{
			$oauth = 0;
			$response = OAuth($_REQUEST['code']);
			
			if( !is_wp_error( $response ) ){
				$data = json_decode($response['body'], true);
				if(isset($data['access_token']))
				{
					update_option('wc_zoho_access_token', $data['access_token']);
					update_option('wc_zoho_access_token_expires_on', strtotime(current_time('mysql')) + 3600);
					
					if(isset($data['refresh_token']))
						update_option('wc_zoho_refresh_token', $data['refresh_token']);
					
					$oauth = 1;
				}
			}
			
			wp_redirect(admin_url('admin.php?page=zoho_connect&oauth='.$oauth));
			exit;
		}
	
die;	
}

/* Create authorization code */

function OAuth($code){
	
	if(ZOHO_CLIENT_ID != '')
		{
			$response = wp_remote_post( ZOHO_AUTH_URL, array(
				'body'	=> array(
					'code' 			=> $code,
					'redirect_uri' 	=> ZOHO_REDIRECT_URL,
					'client_id' 	=> ZOHO_CLIENT_ID,
					'client_secret' => ZOHO_CLIENT_SECRET,
					'grant_type' 	=> 'authorization_code',	
				)
			));
			
			return $response;
		}
}

function get_refresh_token()
{
		$status = 0;
		if(ZOHO_CLIENT_ID != '' && ZOHO_CLIENT_SECRET != '')
		{
			$response = wp_remote_post( ZOHO_AUTH_URL, array(
				'body'	=> array(
					'refresh_token'	=> get_option('wc_zoho_refresh_token'),
					'client_id' 	=> ZOHO_CLIENT_ID,
					'client_secret' => ZOHO_CLIENT_SECRET,
					'grant_type' 	=> 'refresh_token',	
				)
			));
			
			if( !is_wp_error( $response ) ){
				$data = json_decode($response['body'], true);
				if(isset($data['access_token']))
				{
					update_option('wc_zoho_access_token', $data['access_token']);
					update_option('wc_zoho_access_token_expires_on', strtotime(current_time('mysql')) + 3600);

					$status = 1;
				}
			}	
		}
		
		return $status;
}

function request_zoho_data($module, $params, $method = 'GET')
{
		$response = wp_remote_request( ZOHO_DOMAIN_URL.$module, array(
				'method' => $method,
				'headers' => array(
					'Authorization' => 'Zoho-oauthtoken ' . get_option('wc_zoho_access_token'),
				),
				'body'	=> json_encode($params)
			));
			
		if( !is_wp_error( $response ) ){
			return array('status'=>1, 'body'=>json_decode($response['body'], true));
		}
		else{
			return array('status'=>0);
		}	
}

/* Update Attachment With ZOHO Recorad ID */

function request_zoho_attachmentData($Attachmodule, $params, $method = 'GET')
{
	
		
		$response = wp_remote_request( ZOHO_DOMAIN_URL.$Attachmodule, array(
				'method' => $method,
				'headers' => array(
					'Authorization' => 'Zoho-oauthtoken ' . get_option('wc_zoho_access_token'),
				),
				'body'	=> $params
			));
			
		if( !is_wp_error( $response ) ){
			return array('status'=>1, 'body'=>json_decode($response['body'], true));
		}
		else{
			return array('status'=>0);
		}	 
}

/* Update Recoard data */

function update_zoho_data($module, $params, $recoardID ,$method = 'PUT')
{
		$response = wp_remote_request( ZOHO_DOMAIN_URL.$module.'/'.$recoardID, array(
				'method' => $method,
				'headers' => array(
					'Authorization' => 'Zoho-oauthtoken ' . get_option('wc_zoho_access_token'),
				),
				'body'	=> json_encode($params)
			));
			
		if( !is_wp_error( $response ) ){
			return array('status'=>1, 'body'=>json_decode($response['body'], true));
		}
		else{
			return array('status'=>0);
		}	
}


/* GET Recoard data */

function get_zoho_data($module, $recoardID ,$method = 'GET')
{
		
		$response = wp_remote_request( ZOHO_DOMAIN_URL.$module.'/'.$recoardID, array(
				'method' => $method,
				'headers' => array(
					'Authorization' => 'Zoho-oauthtoken ' . get_option('wc_zoho_access_token'),
				)
			));
			
		if( !is_wp_error( $response ) ){
			return array('status'=>1, 'body'=>json_decode($response['body'], true));
		}
		else{
			return array('status'=>0);
		}	
}


/* File Upload multipart Attachment With ZOHO Recorad ID */

function request_zoho_file_upload($Attachmodule, $params, $method = 'POST')
{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => ZOHO_DOMAIN_URL.$Attachmodule,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => $params,
			CURLOPT_HTTPHEADER => array(
				'Authorization: Zoho-oauthtoken '.get_option('wc_zoho_access_token'),
			),
		));

		$response = curl_exec($curl);
		$response = json_decode($response);
		curl_close($curl);
		
		//echo '<pre>'; print_r($response); die;
		
		if(count($response->data) > 0){
			
			return array('status'=>1, 'id'=>$response->data[0]->details->id);
			
		}else{
			
			return array('status'=>0);
		}
}

function multiple_request_zoho_file_upload($Attachmodule, $params, $method = 'POST')
{
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => ZOHO_DOMAIN_URL.$Attachmodule,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'POST',
			CURLOPT_POSTFIELDS => $params,
			CURLOPT_HTTPHEADER => array(
				'Authorization: Zoho-oauthtoken '.get_option('wc_zoho_access_token'),
			),
		));

		$response = curl_exec($curl);
		$response = json_decode($response);
		curl_close($curl);
		
		return $response;
}


/* Delete Recoard data */

function delete_zoho_data($module,$method = 'DELETE')
{
		
		$response = wp_remote_request( ZOHO_DOMAIN_URL.$module, array(
				'method' => $method,
				'headers' => array(
					'Authorization' => 'Zoho-oauthtoken ' . get_option('wc_zoho_access_token'),
				)
			));
			
		if( !is_wp_error( $response ) ){
			return array('status'=>1, 'body'=>json_decode($response['body'], true));
		}
		else{
			return array('status'=>0);
		}	
}

?>