<div class="container">
	<?php 
	global $wpdb,$current_user,$wp_query;
	$variables 	  = $wp_query->query_vars;
	$StaffID 	  = $variables['staffid'];
	if(!in_array('applicant',$current_user->roles)){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
	}elseif(isset($variables['staffid']) && empty($variables['staffid'])){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
		
	}else{
		
		$Table       = $wpdb->prefix.'zoho_centre_staff_data';
		
		$getStaffInfo = $wpdb->get_row($wpdb->prepare("SELECT * FROM $Table WHERE id =%d",$StaffID),ARRAY_A);
		
		?>
			<form class="update_staff mt-5" id="update_staff" method="post" enctype="multipart/form-data">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">First Name <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="fname" value="<?php echo $getStaffInfo['fname'];?>" autocomplete="off" maxlength="15"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput2">Last Name <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="lname" value="<?php echo $getStaffInfo['lname'];?>" autocomplete="off" maxlength="15"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput3">Email Address <span class="astrick">*</span></label>
							<input type="email" class="form-control" name="email" value="<?php echo $getStaffInfo['email'];?>" autocomplete="off" maxlength="50"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput4">Job Title <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="jobtitle" value="<?php echo $getStaffInfo['job_title'];?>" autocomplete="off" maxlength="40"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput4">Upload CV</label>
							<input type="file" class="form-control" name="cv" value="" autocomplete="off" style="border:none;"> 
							<em style="color:red;">Support format pdf, docx, doc</em><br>
							<em style="color:red;">Maximum allowed file size: 100 MB</em>
							<br>
							<?php 
								if(!empty($getStaffInfo['resume'])){
									
									$resume = '<a href="javascript:void(0)" class="resumedownloadmanually" data-id="'.$getStaffInfo['id'].'" title="Download CV">View CV</a>';
									
									echo $resume;
								}
							?>
						</div>
					</div>
				</div>
				<input type="hidden" name="action" value="update_staff">
				<input type="hidden" name="staffid" value="<?php echo base64_encode($getStaffInfo['id']);?>">
				<input type="submit" value="Update" class="btn btn-primary disablebtn">
			</form>
			<div class="displayerror" style="margin-top:25px;"></div>
		<?php
	}
	?>
</div>