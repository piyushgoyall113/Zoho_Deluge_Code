<?php 
global $wpdb,$current_user;
$userID   = $current_user->ID;
$table = $wpdb->prefix.'center_register_qualification';
$table2 = $wpdb->prefix.'custom_qualification';

$where = "AND center_id = $userID";

$centreID = '';
if(in_array('applicant',$current_user->roles)){
	
	$userID   = $current_user->ID;
	$centreID = get_user_meta($userID, 'centre_id_number',true);
	
	$query = "SELECT t1.qualification_id as zoho_record_id,t2.name as name FROM $table as t1 Left JOIN $table2 as t2 ON t1.qualification_id = t2.zoho_record_id WHERE 1 $where ORDER BY t1.id DESC";
	
	$data  = $wpdb->get_results($query,ARRAY_A);
}
?>
<div class="container">
   <div class="row">
	<div class="col-md-12">
      <form class="custom_learner_reg" id="custom_learner_reg" method="post">
		 <div class="form-group">
			<label for="exampleFormControlInput1">Your Centre ID Number <span class="astrick">*</span></label>
			<input type="text" class="form-control" name="cenername" value="<?php echo $centreID;?>" autocomplete="off"> 
		  </div>
         <div class="form-group">
            <label for="exampleInputEmail1" style="display:block;">The Qualification <span class="astrick">*</span></label>
            <select class="form-control commanselect2" name="qualification">
			  <option value="">-Select-</option>
			  <?php foreach($data as $listing){ ?>
				<option value="<?php echo $listing['zoho_record_id'];?>"><?php echo $listing['name'];?></option>
			  <?php } ?>
			</select>
         </div>
         <div class="form-group">
            <label for="exampleInputPassword1">Funding</label>
			<select class="form-control" name="funding">
			  <option value="">-Select-</option>
			  <option value="16 -19">16 -19</option>
			  <option value="Adult Learner Loans (ALL)">Adult Learner Loans (ALL)</option>
			  <option value="Adult Education Budget (AEB)">Adult Education Budget (AEB)</option>
			  <option value="Free Courses for Jobs">Free Courses for Jobs</option>
			  <option value="European Social Fund (ESF)">European Social Fund (ESF)</option> 
			</select>
         </div>
         <div class="form-group">
			<label for="exampleFormControlInput1">Start Date <span class="astrick">*</span></label>
			<input type="text" class="form-control" name="sdate" value="" id="sdate" autocomplete="off">
		  </div>
		  <div class="form-group">
			<label for="exampleFormControlInput1">End Date <span class="astrick">*</span></label>
			<input type="text" class="form-control" name="edate" id="edate" value="" autocomplete="off">
		  </div>
		  
		  <div class="heading">
			<h4>Learner Details ( You only allow at a time 10 Learners register.)</h4>
		  </div>
		  
		  <div class="addmorelearnerdetailsouter">
			<input type="hidden" name="totalrows" class="totalrows" value="0">
			<div class="addmorelearnerdetailsreapter">
				<div class="addnew">
					<a href="javascript:void(0)" class="add_more_entry" title="Add New Entry"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Entry</a>
				</div>
			</div>
			</div>
		 <input type="hidden" name="action" value="sens_zoho_learner">
		 <input type="submit" value="Submit" class="btn btn-primary disablebtn">
      </form>
	  </div>
   </div>
   <div class="displayerror" style="margin-top:25px;"></div>
</div>