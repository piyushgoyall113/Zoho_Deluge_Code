<div class="container">
	<form class="check_learners_status mt-5" id="check_learners_status" method="post">
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Please enter your email-ID <span class="astrick">*</span></label>
					<input type="email" class="form-control" name="lemail" value="" autocomplete="off"> 
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Please enter your date of birth <span class="astrick">*</span></label>
					<input type="text" class="form-control" name="dob" value="" autocomplete="off" id="commandatepicker"> 
				</div>
			</div>
		</div>
		<input type="hidden" name="action" value="check_learners_status">
			<?php wp_nonce_field( 'plstatus', 'lstatus' ); ?>
		<input type="submit" value="Submit" class="btn btn-primary disablebtn">
	</form>
	<div class="displayerror" style="margin-top:25px;"></div>
	<div class="displaycontent" style="margin-top:25px;"></div>
</div>