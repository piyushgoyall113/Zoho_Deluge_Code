<div class="container learners_report">
	<?php 
	global $wpdb,$current_user,$wp_query;
	$variables 	  = $wp_query->query_vars;
	$ViewID 	  = $variables['view'];
	if(!in_array('applicant',$current_user->roles)){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
	}elseif(isset($variables['view']) && empty($variables['view'])){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
		
	}else{
		
		$Table       = $wpdb->prefix.'zoho_report_submission';
		
		$Table2       = $wpdb->prefix.'zoho_report_submission_eqa_learners';
		
		$getInfo = $wpdb->get_row($wpdb->prepare("SELECT centre_id,report_data FROM $Table WHERE id =%d",$ViewID),ARRAY_A);
		
		$reportData = json_decode($getInfo['report_data']);
		
		$userID            = $current_user->ID;
		
		$centreOrg = !empty(get_user_meta($userID,'organisation_name',true)) ? get_user_meta($userID,'organisation_name',true) : 'N/A';
		
		$totalLearners = $totalactionpoint = 0;
		
		/* Get all learners details */
		
		$getLearners = $wpdb->get_results($wpdb->prepare("SELECT * FROM $Table2 WHERE centre_id =%s AND is_sent = %d",$getInfo['centre_id'],1),ARRAY_A);
		
		//echo '<pre>'; print_r($getLearners);
		
		if(!empty($getLearners)){
			
			$totalLearners = count($getLearners);
		}
		
		if(isset($reportData->Action_Points) && !empty($reportData->Action_Points)){
			
			$totalactionpoint = count($reportData->Action_Points);
		}
		
		?>
			
		<div class="row">
			
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">Centre Name</label>
					<label class="value"><?php echo $centreOrg;?></label> 
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">EQA Name</label>
					<label class="value"><?php echo $reportData->EQA->name;?></label> 
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">Approver </label>
					<label class="value"><?php echo $reportData->Approver;?></label> 
				</div>
			</div>
		</div>	
		
		<div class="row mt-3">
			
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">EQA Email Address</label>
					<label class="value"><?php echo $reportData->EQA_Email_Address;?></label> 
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">Date of Moderation</label>
					<label class="value"><?php echo date('M d, Y',strtotime($reportData->Date_of_Moderation));?></label> 
				</div>
			</div>
		</div>	
		
		<h2 class="mt-3">Centre Details</h2>
		
		<hr>
		
		<div class="row mt-3">
			
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">First Name</label>
					<label class="value"><?php echo $reportData->First_Name;?></label> 
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">Last Name</label>
					<label class="value"><?php echo $reportData->Last_Name;?></label> 
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label for="exampleFormControlInput1">Communication Channels</label>
					<label class="value">
						<?php 
						
						if(!empty($reportData->Communication_Channels)){
							
							echo $Channels = implode(', ',$reportData->Communication_Channels);
						}else{
						
							echo 'N/A';
						}
						
						?>
					</label> 
				</div>
			</div>
		</div>	
		
		<div class="row mt-3">
		
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">
					<input type="checkbox" <?php if(!empty($reportData->Was_this_Moderation_onsite)){ echo "checked";}?> disabled>&nbsp;&nbsp;Was this Moderation onsite?</label>
				</div>
			</div>
			
		</div>	
		<?php 
		if(!empty($reportData->Was_this_Moderation_onsite)){
		?>
			<div class="row mt-3">
			
				<div class="col-md-12"><h3>Centre Address</h3></div>
			
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">Street Address</label>
						<label class="value"><?php echo $reportData->Street_Address;?></label> 
					</div>
				</div>
				
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">Address Line 2</label>
						<label class="value"><?php echo $reportData->Address_Line_2;?></label> 
					</div>
				</div>
				
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">City</label>
						<label class="value"><?php echo $reportData->City;?></label> 
					</div>
				</div>
			
			</div>
			
			<div class="row mt-3">
			
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">State/Region/Province</label>
						<label class="value"><?php echo $reportData->State_Region_Province;?></label> 
					</div>
				</div>
				
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">Postal / Zip Code</label>
						<label class="value"><?php echo $reportData->Postal_Zip_Code;?></label> 
					</div>
				</div>
				
				<div class="col-md-4  mt-3">
					<div class="form-group">
						<label for="exampleFormControlInput1">Country</label>
						<label class="value"><?php echo $reportData->Country;?></label> 
					</div>
				</div>
			
			</div>
		<?php	
		}
		?>
		
		<div class="row mt-3">
			
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">
					<input type="checkbox" <?php if(!empty($reportData->Have_any_of_the_learners_submitted_been_assessed)){ echo "checked";}?> disabled>&nbsp;&nbsp;Have any of the learners submitted been assessed in a language other than English</label>
				</div>
			</div>
		</div>	
		<?php
		
		if(!empty($reportData->Have_any_of_the_learners_submitted_been_assessed)){
			?>
			<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Details of delivery, assessing in a language other than English</label>
						<label class="value"><?php echo $reportData->Details_of_delivery_assessing_in_a_language_other;?></label> 
					</div>
				</div>	
			</div>
			<?php
		}?>
		
		<h2 class="mt-3">Quality & Assessment Judgements</h2>
		
		<hr>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Are the assessment judgements valid</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Are_the_assessment_judgements_valid;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Has evidence of standardisation activity been provided, including meetings / sharing of good practice</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Has_evidence_of_standardization_activity;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Work sampled shows students have achieved the LOs at the standards decribed by the AC</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Work_sampled_shows_students_have_achieved_the_LOs;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Learners have followed the assignment provided and produced work as required by the tasks</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Learners_have_followed_the_assignment_provided_and;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Learners have demonstrated good practice in their work with for example the use of relevant examples, appropriate referencing and the use of bibliographies.</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Learners_have_demonstrated_good_practice_in_their;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Learners have demonstrated employability and/or study skills in the completion of their work</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Learners_have_demonstrated_employability_and_or;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Is the centre using ATHE approved centre devised assessments</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Is_the_centre_using_ATHE_approved_centre_devised_a;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Have assessors provided clear feedback to the learner based on achievement of the LOs at the standards provided</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Have_assessors_provided_clear_feedback;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Are assessment records accurate and up to date</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Are_assessment_records_accurate_and_up_to_date;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Have reasonable adjustments or special considerations been recorded and have they imptacted on learner access to assesessment</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Have_reasonable_adjustments_or_special_considerate;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Have there been any resubmissions of learner work and are they recorded appropriately</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Have_there_been_any_resubmissions_of_learner_work;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Is an IQA sampling plan in place and provided to the EQA</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Is_an_IQA_sampling_plan_in_place_and_provided;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Have rigorous and robust IQA records been kept and maintained in accordance with ATHE standards</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Have_rigorous_and_robust_IQA_records_been_kept_and;?></label> 
					</div>
				</div>				
		</div>
		
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Is the IQA effective in ensuring valid assessment judgements</label>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label class="value"><?php echo $reportData->Is_the_IQA_effective_in_ensuring_valid_assessment;?></label> 
					</div>
				</div>				
		</div>
		<hr>
		<div class="row mt-3">
				<div class="col-md-8">
					<div class="form-group">
						<label for="exampleFormControlInput1">Comments</label>
						<label class="value"><?php echo $reportData->Comments;?></label>
					</div>
				</div>				
		</div>
		<h2 class="mt-3">Learner Details (<?php echo $totalLearners;?>)</h2>
		<hr>
		<?php 
		if(!empty($getLearners)){
			echo '<div class="row mt-3">';
			 foreach($getLearners as $Learner){
				 ?>
				
						<div class="col-md-4">
							<div class="card bg-light mb-3">
							  <div class="card-header">
								<input type="checkbox" <?php if($Learner['RPL'] == 1){ echo "checked";}?> disabled>&nbsp;&nbsp;Is RPL being used against this learner</label>
							  </div>
							  <div class="card-body">
								<div class="row">
									<div class="col-md-4"><label for="exampleFormControlInput1">Qualification</label></div>
									<div class="col-md-8"><label class="learnersvalue"><?php echo get_qualification_name_by_id($Learner['qualification_id']);?></label></div>
								</div>
								<hr>
								<div class="row">
									<div class="col-md-4"><label for="exampleFormControlInput1">Learner Name</label></div>
									<div class="col-md-8"><label class="learnersvalue"><?php echo get_learner_name_by_zohoid($Learner['learner_id']);?></label></div>
								</div>
								<hr>
								<div class="row">
									<div class="col-md-4"><label for="exampleFormControlInput1">Unit Title</label></div>
									<div class="col-md-8"><label class="learnersvalue"><?php echo get_unit_name_by_id($Learner['unit_id']);?></label></div>
								</div>
								<hr>
								<div class="row">
									<div class="col-md-4"><label for="exampleFormControlInput1">Grade - based on EQA judgement</label></div>
									<div class="col-md-8"><label class="learnersvalue"><?php echo $Learner['grade'];?></label></div>
								</div>
								<hr>
								<div class="row">
									<div class="col-md-4"><label for="exampleFormControlInput1">EQA judgement</label></div>
									<div class="col-md-8"><label class="learnersvalue"><?php echo $Learner['EQA_judgement'];?></label></div>
								</div>
								<hr>
								<div class="row">
									<div class="col-md-8">
										<div class="form-group">
											<label for="exampleFormControlInput1">Feedback / Comments</label>
											<label class="value"><?php echo $Learner['feedback'];?></label>
										</div>
									</div>	
								</div>
							  </div>
							</div>
						</div>	
					
				 <?php
			 }
			 echo '</div>';
		 }
		?>
		<h2 class="mt-3">Action Points (<?php echo $totalactionpoint;?>)</h2>
		<hr>
		<?php
		if(isset($reportData->Action_Points) && !empty($reportData->Action_Points)){
			echo '<div class="row mt-3">';
			foreach($reportData->Action_Points as $points){
				?>
				
					<div class="col-md-6">
						<div class="card bg-light mb-3">
						  <div class="card-header">
							<input type="checkbox" <?php if(!empty($points->Prior_to_submitting_further_results)){ echo "checked";}?> disabled>&nbsp;&nbsp;Prior to submitting further results</label>
						  </div>
						  <div class="card-body">
							<div class="row">
								<div class="col-md-4"><label for="exampleFormControlInput1">Responsibility</label></div>
								<div class="col-md-8"><label class="learnersvalue"><?php echo $points->Responsibility;?></label></div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-4"><label for="exampleFormControlInput1">Priority</label></div>
								<div class="col-md-8"><label class="learnersvalue"><?php echo $points->Priority;?></label></div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-4"><label for="exampleFormControlInput1">Deadline</label></div>
								<div class="col-md-8"><label class="learnersvalue"><?php echo date('M d, Y',strtotime($points->Deadline));?></label></div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-8">
									<div class="form-group">
										<label for="exampleFormControlInput1">Action Point</label>
										<label class="value"><?php echo $points->Action_Point;?></label>
									</div>
								</div>	
							</div>
						  </div>
						</div>
					</div>	
				
				<?php
			}
			echo '</div>';
		}
		?>
		<div class="row mt-3">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">
					<input type="checkbox" <?php if(!empty($reportData->Malpractice_Maladministration_identified)){ echo "checked";}?> disabled>&nbsp;&nbsp;Malpractice / Maladministration identified</label>
				</div>
			</div>
		</div>
		<?php
		if(!empty($reportData->Malpractice_Maladministration_identified)){
			?>
			<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Malpractice type</label>
						<label class="value"><?php echo $reportData->Malpractice_type;?></label> 
					</div>
				</div>	
			</div>
			<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Notes on malpractice</label>
						<label class="value"><?php echo $reportData->Notes_on_malpractice;?></label> 
					</div>
				</div>	
			</div>
		<?php
		}
		?>
		<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Identification of training and support ATHE can offer to the centre.</label>
						<label class="value"><?php echo $reportData->Identification_of_training_and_support_ATHE;?></label> 
					</div>
				</div>	
		</div>
		<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Good practice identified</label>
						<label class="value"><?php echo $reportData->Good_practice_identified;?></label> 
					</div>
				</div>	
		</div>
		<div class="row mt-3">
				<div class="col-md-12">
					<div class="form-group">
						<label for="exampleFormControlInput1">Learner Moderation Judgement</label>
						<label class="value"><?php echo $reportData->Learner_Moderation_Judgement;?></label> 
					</div>
				</div>	
		</div>
		<?php
	}
	?>
</div>