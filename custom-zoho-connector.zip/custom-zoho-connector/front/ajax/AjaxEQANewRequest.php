<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$user = $current_user->ID;
	
	$userID = get_user_meta($user,'zoho_record_id',true);
	
	$keyword = $_POST['search']['value'];
	$filter  = $_POST['searchstatus'];
	
	$Table       = $wpdb->prefix.'zoho_eqa_results_request';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND zoho_eqaprofile_id = $userID";
	
	if(!empty($keyword) && empty($filter)){
	
		$where = " AND ( zoho_request_no LIKE '%".$keyword."%')  AND zoho_eqaprofile_id = '".$userID."'";
		
	}elseif(empty($keyword) && !empty($filter)){
		
		$where = " AND ( request_status = '".$filter."')  AND zoho_eqaprofile_id = '".$userID."'";
		
	}elseif( !empty($keyword) && !empty($filter) ){
		
		$where = " AND ( zoho_request_no LIKE '%".$keyword."%' AND  request_status = '".$filter."')   AND zoho_eqaprofile_id = '".$userID."'";
	}
	
	$getData    = $wpdb->get_results("SELECT * FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	//echo $wpdb->last_query;
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();
	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$result){
			
			$ID           			  = $result['id'];
			$zoho_request_no          = $result['zoho_request_no'];
			$zoho_request_id          = $result['zoho_request_id'];
			$asign_centre   	  	  = $result['asign_centre'];
			$learners   	  	  	  = count(explode(',',$result['learners_ids']));
			$registered   			  = date('M d, Y',strtotime($result['updated']));
			
			 $centreID = get_user_id_by_zohoid($asign_centre);
			
			$centreData = get_userdata($centreID);
			
			$actionBtn = '';
			
			if($result['request_status'] == 'New'){
			
				$actionBtn = '<button type="button" class="btn btn-success requestAccept" style="padding: 4px;" data-id="'.$result['zoho_request_id'].'">Accept</button>&nbsp;&nbsp;<button type="button" class="btn btn-danger requestReject" style="padding: 4px;" data-id="'.$result['zoho_request_id'].'">Reject</button>';
				
			}elseif($result['request_status'] == 'Accepted'){
				
					$EQAWPdata = get_user_id_by_zohoid($result['zoho_eqaprofile_id']);
					
					
				
				
					$UrlDate = date('d-M-Y',strtotime(str_replace('/', '-', $result['result_completed_date'])));
						
					$EQAData = get_userdata($EQAWPdata);
					
					$name = explode(" ",$EQAData->first_name);
					
					$zohoFormUrl = "https://forms.zohopublic.com/atheltd/form/LearnerModerationReport/formperma/1ZQgpQwKpoNeAL_XtBqKPHkODUqqaPbI1QrvO4ilFj0?centrename=".$centreData->first_name."&centerid=".$result['asign_centre']."&eqaid=".$result['zoho_eqaprofile_id']."&requestid=".$result['zoho_request_id']."&fname=".$name[0]."&lname=".$name[1]."&email=".$EQAData->user_email."&date=".$UrlDate;
				
					$actionBtn = '<a class="eqaviewresults" href="javascript:void(0)" title="View learners" data-id="'.$result['id'].'" data-rid="'.$result['result_report_id'].'"><i class="fa-eye fa" aria-hidden="true"></i></a>';
					
					if(empty($result['result_report_id'])){
					
						$actionBtn .= '&nbsp;<a class="eqaviewresultsreport" href="'.$zohoFormUrl.'" target="_blank" title="Submit Report"><i class="fa fa-list-alt" aria-hidden="true"></i></a>';
						
					}else{
						
						$actionBtn .= '&nbsp<a class="reportsubmitted" href="javascript:void(0)"  title="Report Submitted"><i class="fa fa-ban" aria-hidden="true"></i></a>';
					}
				
			}
		
			$style = '';
						
			if($result['request_status'] == 'New'){
				$style = 'style="color:#fff;background-color: #138496;padding: 5px;"';
			}elseif($result['request_status'] == 'Accepted'){
				$style = 'style="color:#fff;background-color: #28a745;padding: 5px;"';
			}elseif($result['request_status'] == 'Rejected'){
				$style = 'style="color:#fff;background-color: #dc3545;padding: 5px;"';
			}elseif($result['request_status'] == 'No response'){
				$style = 'style="color:#fff;background-color: #ffc107;padding: 5px;"';
			}
			
			
			if(!empty($row['result_completed_date'])){
							
				$changesubmitDate = date('M d, Y',strtotime(str_replace('/', '-', $result['result_completed_date'])));
			}else{
			
				$changesubmitDate = '';
			}
			
			
			$recoards[$key] = array(
										
										'zoho_request_no'      => $zoho_request_no,
										'learners' 			   => $learners,
										'centre_name' 		   => $centreData->first_name,
										'centre_email' 		   => $centreData->user_email,
										'status'    	   	   => '<span '.$style.'>'.$result['request_status'].'</span>',
										'result_completed_date'    	   => $changesubmitDate,
										'registered'    	   => $registered,
										'action'               => $actionBtn
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response);
	
?>	