<?php 
include('../../../../../wp-load.php');

ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

	global $wpdb,$current_user;

	$keyword = $_POST['search']['value'];
	
	$searchquali = $_POST['searchquali'];
	
	$searchByFromdate = $_POST['searchByFromdate'];
	
	$searchByTodate = $_POST['searchByTodate'];
	
	$dateRange = array();
	
	$newsdate = $newEdate = '';
	
	if(!empty($searchByFromdate) && !empty($searchByTodate)){
		
		$dateRange = array( str_replace("-","",$searchByFromdate), str_replace("-","",$searchByTodate) );
		
		$newsdate = str_replace("-","",$searchByFromdate);
		$newEdate = str_replace("-","",$searchByTodate);
	}
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$centerID = $current_user->ID;
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	$where = '';
	
	$TotalData = 0;
	
	if(!empty($keyword) && empty($searchquali) && empty($dateRange) ){
		
		/* 1. Keyword is not empty rest empty */
	 
		 $where = "AND ( t1.name LIKE '%".$keyword."%') AND t1.center_id = '".$centerID."'";
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
			
	}elseif( empty($keyword) && !empty($searchquali) && empty($dateRange) ){
		
	
		
		/* 2. Qualification is not empty rest empty */
		 
		  $where = "AND t1.qualification_id = '".$searchquali."' AND t1.center_id = '".$centerID."'";
		 
		$query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
			
	 }elseif( empty($keyword) && empty($searchquali) && !empty($dateRange) ){
		 
		 /* 3.  Date Range is not empty rest empty */
		 
		 $where = "AND start >= '".$newsdate."' AND end <= '".$newEdate."' AND t1.center_id = '".$centerID."'";
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
		 
	 }elseif( !empty($keyword) && !empty($searchquali) && empty($dateRange) ){
		 
		  /* 4.  Date Range is empty rest not empty */
		 
		 $where = "AND t1.qualification_id = '".$searchquali."' AND ( t1.name LIKE '%".$keyword."%') AND t1.center_id = '".$centerID."'"; 
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
			
		
	}elseif( !empty($keyword) && empty($searchquali) && !empty($dateRange) ){
		
		/* 5.  Qualification is empty rest not empty */
		
		$where = "AND ( start >= '".$newsdate."' AND end <= '".$newEdate."' ) AND ( t1.name LIKE '%".$keyword."%') AND t1.center_id = '".$centerID."'"; 
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
		
	}elseif( empty($keyword) && !empty($searchquali) && !empty($dateRange) ){
		
		/* 6.  Keyword is empty rest not empty */
		
		$where = "AND ( start >= '".$newsdate."' AND end <= '".$newEdate."' ) AND t1.qualification_id = '".$searchquali."' AND t1.center_id = '".$centerID."'"; 
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
		
	}elseif( !empty($keyword) && !empty($searchquali) && !empty($dateRange) ){
		
		$where = "AND ( start >= '".$newsdate."' AND end <= '".$newEdate."' ) AND t1.qualification_id = '".$searchquali."' AND ( t1.name LIKE '%".$keyword."%') AND t1.center_id = '".$centerID."'"; 
		
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
		
	}else{
		
		/* 8.  All is empty*/
		 
		 $where = "AND t1.center_id = '".$centerID."'";
		 
		 $query = "SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE 1 $where ORDER BY t1.id DESC LIMIT $offset,$length";
		
		 $sqlCount = "SELECT count(t1.id) as total FROM $learnersadmissiontable as t1 WHERE 1 $where ORDER BY t1.id DESC ";
		
		$TotalData = $wpdb->get_row($sqlCount,ARRAY_A);
		
		$TotalData  = $TotalData['total'];
		
	 }	
	 
	$Data = $wpdb->get_results($query,ARRAY_A); 
	
	$test = array();
	
	if (!empty($Data)){

		$i = 1;
		
	  foreach ( $Data as $key=>$result ) {
		
			$ID           = $result['id'];
			$LID          = $result['lid'];
			$name         = $result['name'];
			$email   	  = $result['email'];
			$registered   = date('Y-m-d',strtotime($result['updated']));
			
			$qualification = $result['qualification_id'];
			
			$quali = get_qualification_name_by_id($qualification);
				
			$redirect    = site_url('learner-update').'/'.$ID;
			
			$status        = $result['registered_status'];
			
			$classpaymentstatus = ($status == 'Pending') ? 'badge-secondary p-1' : 'badge-success p-1';
			
			$QA  = $result['is_completed'] == 1 ? 'Completed' : 'Pending';
			$QAC = $result['is_completed'] == 1 ? 'badge-secondary p-1' : 'badge-warning p-1';
			
			$certificateLogo = "";
							
			if($result['is_completed'] == 1){
								
				if($result['overall_grade'] == 'Pass'){
					
					$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-p.png">';
					
				}elseif($result['overall_grade'] == 'Merit'){
					
					$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-m.png">';
					
				}elseif($result['overall_grade'] == 'Distinction'){
					
					$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-d.png">';
				}else{
					
					$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-f.png">';
				}
			}
			
			$actionBtn = '<a class="viewinfo" href="javascript:void(0)" title="View Details" data-user="'.$LID.'" data-id="'.$ID.'"><i class="fa-eye fa"></i></a>&nbsp;&nbsp;';
			
			if($result['is_completed'] != 1){
				
				$actionBtn .= '<a class="editinfo" href="'.$redirect.'" title="Edit Details"><i class="fas fa-edit"></i></a>&nbsp;&nbsp;';
			}
			
			$actionBtn .= '<a class="viewresults" href="javascript:void(0)" title="View Results" data-id="'.$ID.'"><i class="fa fa-list-alt" aria-hidden="true"></i></a>';
			
			$recoards[$key] = array(
										'sn' 			=> '#'.$LID,
										'name' 			=> $certificateLogo.$name,
										'email' 		=> '<a class="text-link" href="mailto:'.$email.'">'.$email.'</a>',
										'qualification' => $quali,
										'status'      => '<span class="pstatus '.$classpaymentstatus.'">'.$status.'</span>',
										'qstatus'      => '<span class="qstatus '.$QAC.'">'.$QA.'</span>',
										'action'        => $actionBtn,
									); 
			
			$i++;	
			$test[] = array_values($recoards[$key]);							

	  }

	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);

	echo json_encode($response);
?>