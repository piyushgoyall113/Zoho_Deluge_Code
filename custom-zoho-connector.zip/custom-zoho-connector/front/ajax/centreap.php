<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$user = $current_user->ID;
	
	$userID = get_user_meta($user,'zoho_record_id',true);
	
	
	$filter  = $_POST['searchstatus'];
	
	$Table       = $wpdb->prefix.'zoho_centre_action_point';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND zoho_centre_id = $userID";
	
	if(!empty($filter)){
		
		$where = " AND ( status = '".$filter."')  AND zoho_centre_id = '".$userID."'";
		
	}
	
	$getData    = $wpdb->get_results("SELECT * FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	//echo $wpdb->last_query;
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();
	
	$currentTime = strtotime(date('Y-m-d'));
	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$row){
			
			$status = '<span class="pstatus badge-warning p-1" style="color:#fff;">'.$row['status'].'</span>';
			
			if($row['status'] != 'Pending'){
				
				$status = '<span class="pstatus badge-success p-1" style="color:#fff;">'.$row['status'].'</span>';
			}
			
			$actionBtn = '<a class="viewinfoaction" href="javascript:void(0)" title="View Action Content"  data-id="'.$row['id'].'"><i class="fa-eye fa"></i></a>&nbsp;';
			
			if($row['responsibility'] == 'Centre' && empty($row['evidence'])){
				
				$actionBtn .= '<a class="uploadEvidence" href="javascript:void(0)" title="Upload Evidence ( only one time)"  data-id="'. $row['id'].'"><i class="fa fa-upload" aria-hidden="true"></i></a>';
			}
			
			$further = 'False';
			
			if($row['prior_to_submitting_further_results'] == 1){ $further =  "True";}
			
			$Deadlinetime = strtotime($row['deadline']);
							
			//$highlight = $currentTime > $Deadlinetime ? '<span class="highlightdeadline"><img src="'.ZOHO_PLUGIN_URL.'assets/images/overdue.png"></span>' : '';
			
			//$highlightStyle = $currentTime > $Deadlinetime ? 'pstatus badge-danger p-1' : '';
			
			if(!empty($row['evidence'])){
												
				$download =  '<a class="downloadevidence" href="javascript:void(0)" title="Download Evidence"  data-id="'.$row['id'].'?>"><i class="fa fa-download" aria-hidden="true"></i></a>';
			}else{
				
				$download =  'N/A';
			}
			
			
			if($row['status'] == 'Pending'){
								
				$highlightStyle = $currentTime > $Deadlinetime ? 'pstatus badge-danger p-1' : '';
				
				$highlight = $currentTime > $Deadlinetime ? '<span class="highlightdeadline"><img src="'.ZOHO_PLUGIN_URL.'assets/images/overdue.png"></span>' : '';
			}

			$recoards[$key] = array(
										
										'responsibility'        => $row['responsibility'],
										'priority' 			    => $row['priority'],
										'deadline' 		        => '<span class="'.$highlightStyle.'">'.date('M d, Y',strtotime($row['deadline'])).'</span>'.$highlight,
										'status' 		   		=> $status,
										'prior'    	   	   		=> $further,
										'evidence'    	   		=> $download,
										'created'    	   		=> date('M d, Y',strtotime($row['created'])),
										'updated'               => date('M d, Y',strtotime($row['updated'])),
										'action'                => $actionBtn
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response); 
	
?>