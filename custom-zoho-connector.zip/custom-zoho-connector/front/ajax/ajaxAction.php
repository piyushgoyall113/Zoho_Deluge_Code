<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/* Load learners details */

add_action('wp_ajax_get_learners_full_details','get_learners_full_details');
function get_learners_full_details(){
	
	global $wpdb;
	
	$LID               = intval($_POST['userID']);
	$ID  			   = intval($_POST['ID']);
	
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	$result = $wpdb->get_row("SELECT t1.*,t2.funding,t2.dob,t2.gender,t2.ethnicity,t2.email,t2.language FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE ( t1.id = $ID)");
	
	$name          = $result->name;
	$email   	   = $result->email;
	$dob           = $result->dob;
	$gender        = $result->gender;
	$ethnicity     = $result->ethnicity;
	$language      = $result->language;
	$qualification = $result->qualification_id;
	$registered    = date('Y-m-d',strtotime($result->updated)); 
	$startdate     = $result->start;
	$enddate       = $result->end;
	$funding       = $result->funding;
	
	$quali = get_qualification_name_by_id($qualification);
	
	$information = array(
											'name' 			=> $name,
											'dob' 			=> date('d M, Y',strtotime($dob)),
											'gender' 		=> $gender,
											'ethnicity' 	=> $ethnicity,
											'email' 		=> $email,
											'language' 		=> $language,
											'qualification' => $quali,
											'funding'       => $funding,
											'startdate'     =>  date('d M, Y',strtotime($startdate)),
											'enddate'       =>  date('d M, Y',strtotime($enddate)),
											'registered'    => $registered
											
				
										);
							
	echo json_encode($information);		
	
die;	
}


/* Load learners results */

add_action('wp_ajax_get_learners_results','get_learners_results');
function get_learners_results(){
	
	global $wpdb;
	
	$resultstable     = $wpdb->prefix.'learners_results';
	$resultsmetatable = $wpdb->prefix.'zoho_learners_results_meta';
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	$LID = intval($_POST['userID']);
	
	$LEARNERSname  = $wpdb->get_row($wpdb->prepare("SELECT name,is_completed FROM $learnersadmissiontable WHERE id = %d",$LID),ARRAY_A);
	
	$response = array();
	
	$getresults = $wpdb->get_row($wpdb->prepare("SELECT * FROM $resultstable WHERE learner_addimission_id = %d",$LID),ARRAY_A);
	
	$resultsData = array('name'=>$LEARNERSname['name'],'is_completed'=>$LEARNERSname['is_completed']);
	
	if(!empty($getresults)){
		
		$qualificationID = $getresults['qualification_id'];
		
		$qualiName = get_qualification_name_by_id($qualificationID);
		$created   = date('d M, Y H:i a',strtotime($getresults['created']));
		
		$resultsData['quali']   = $qualiName;
		$resultsData['created'] = $created;
		
		$getresultMeta = $wpdb->get_results($wpdb->prepare("SELECT * FROM $resultsmetatable WHERE result_id = %d",$getresults['id']),ARRAY_A);
		
		if(!empty($getresultMeta)){
			
			$resultsmeta = array();
			
			foreach($getresultMeta as $data){
				
				$unitname          =  get_unit_name_by_id($data['unit']);
				$grade    		   =  $data['grade'];
				$zoho_result_id    =  $data['zoho_result_id'];
				$result_resubmit   =  $data['result_resubmit'];
				$id                =  $data['result_id'];
				
				$resultsmeta[] = array('id'=>$id,'unit'=>$unitname,'grade'=>$grade,'zoho_result_id'=>$zoho_result_id,'result_resubmit'=>$result_resubmit);
			}
			
			$resultsData['meta'] = $resultsmeta;
			
			$response = array('status'=>'sucess','data'=>$resultsData);
			
		}else{
			
			$response = array('status'=>'fail','data'=>$resultsData);
		}
		
	}else{
		
		$response = array('status'=>'fail','data'=>$resultsData);
	}
	
	echo json_encode($response);
	
die;
}

/* Add new staff under centre */
add_action('wp_ajax_add_new_staff','add_new_staff');
function add_new_staff(){
	
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	
	$fname     = sanitize_text_field($_POST['fname']);
	$lname     = sanitize_text_field($_POST['lname']);
	$email     = sanitize_email($_POST['email']);
	$jobtitle  = sanitize_text_field($_POST['jobtitle']);
	
	$zoho_record_id = get_user_meta($userID,'zoho_record_id',true);
	
	$file      = $_FILES['cv']['name']; 
	$temp      = $_FILES['cv']['tmp_name'];
	$keysize   = $_FILES['cv']['size'];
	
	$keysizeinMB = number_format($keysize / 1048576);
	
	
	$supported = array('pdf','docx','doc');
	$ext       = strtolower(pathinfo($file, PATHINFO_EXTENSION));
	
	$response = $error = $zohoParam = array();
	
	if(empty($fname)){
		array_push($error,"First Name field is required.");
	}if(empty($lname)){
		array_push($error,"Last Name field is required.");
	}if(empty($email)){
		array_push($error,"Email field is required.");
	}if(empty($jobtitle)){
		array_push($error,"Job Title field is required.");
	}
	
	if(empty($error)){
		
		$alreadyExists  = $wpdb->get_row("SELECT id FROM $Table WHERE email = '".$email."'");
		
		if(!empty($alreadyExists)){
			
			array_push($error,$email." address already exists.");
			$response = array('status'=>'fail','message'=>$error);
			
			
		}else{
			
			
				if(empty($file)){
				
					$zohoParam['Name']      = $fname.' '.$lname;
					$zohoParam['Email']     = $email;
					$zohoParam['Job_title'] = $jobtitle;
					$zohoParam['Associated_Centre']    = array('id'=>$zoho_record_id);
					
				}else{
					
					if(!in_array($ext, $supported)){
						
						array_push($error,"CV format is not valid.");
						$response = array('status'=>'fail','message'=>$error);
					
					}elseif($keysizeinMB > 100){
						
						array_push($error,"Your CV is too big OR is greater than 100MB.");
						$response = array('status'=>'fail','message'=>$error);
						
						
					}else{
						
						$zohoParam['Name']      = $fname.' '.$lname;
						$zohoParam['Email']     = $email;
						$zohoParam['Job_title'] = $jobtitle;
						$zohoParam['Associated_Centre']    = array('id'=>$zoho_record_id);
					}
				}
				
				$ZOHOStaffdata         = array();
				$ZOHOStaffdata[]       = $zohoParam;
				
				$active_access_token = 1;
				if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
				{
					
					$active_access_token = get_refresh_token();
				}
				
				if($active_access_token === 1){
			
					$paramsStaff       	  = array('data'=>$ZOHOStaffdata);
					$ZohoInsertStaffData   = request_zoho_data('Centre_Staff', $paramsStaff,'POST'); 
					
					if($ZohoInsertStaffData['body']['data'][0]['status'] == 'success'){
					
						$staff_record_id =  $ZohoInsertStaffData['body']['data'][0]['details']['id'];
						
						$zoho_attachment_id = $resumefile = '';
						
						if(!empty($file)){
							
							/* move file in folder */
							
							$targetPath = ZOHO_PLUGIN_PATH.'front/staffCV/'.time().$file;
							
							$resumefile = time().$file;
							
							move_uploaded_file($temp, $targetPath);
							
							$Attachparams = array('file'=>new \CURLFILE($targetPath));
							$SendAttachment = request_zoho_file_upload('Centre_Staff/'.$staff_record_id.'/Attachments', $Attachparams,'POST');
							
							if($SendAttachment['status'] == 1){
								
								$zoho_attachment_id = $SendAttachment['id'];
							}
							
						}	
						
						/* Insert staff entry in WP */
						
						$wpdb->insert(
									$Table,
									array(
											'center_id'            =>    $userID,
											'fname'   			   =>    $fname,
											'lname'   			   =>    $lname,
											'email'   			   =>    $email,
											'job_title'   		   =>    $jobtitle,
											'resume'               =>    $resumefile,
											'zoho_id'              =>   $staff_record_id,
											'zoho_attachment_id'   =>   $zoho_attachment_id,
											'created'              =>    date('Y-m-d H:i:s'),
											'updated'              =>    date('Y-m-d H:i:s')
									)
								);
								
						$response = array('status'=>'sucess','message'=>$fname.' '.$lname.' has been successfully added.');		
						
					}
				
				}
			
		}
		
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response);
	
die;	
}

/* download staff CV */
add_action('wp_ajax_downlaod_staff_cv','downlaod_staff_cv');
function downlaod_staff_cv(){
	
	global $wpdb;
	
	$id = intval($_POST['ID']);
	
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	
	$Data   = $wpdb->get_row("SELECT resume FROM $Table WHERE id = '".$id."'",ARRAY_A);
	
	$file_path = ZOHO_PLUGIN_URL.'front/staffCV/'.$Data['resume'];
	
	echo json_encode(array('url'=>$file_path,'name'=>basename($file_path)));
die;	
}

/* Delete Staff by centre */
add_action('wp_ajax_delete_staff_recoard','delete_staff_recoard');
function delete_staff_recoard(){
	
	global $wpdb;
	
	$id = intval($_POST['ID']);
	
	$Table = $wpdb->prefix.'zoho_centre_staff_data';
	
	$Data   = $wpdb->get_row("SELECT resume,zoho_id,zoho_attachment_id FROM $Table WHERE id = '".$id."'",ARRAY_A);
	
	$zohoRecoardID = $Data['zoho_id'];
	
	$response = array();
	
	
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		
		$active_access_token = get_refresh_token();
	}
	
	if($active_access_token === 1){

		$DeleteData   = delete_zoho_data('Centre_Staff/'.$zohoRecoardID,'DELETE'); 
		
		if($DeleteData['body']['data'][0]['status'] == 'success'){
			
			$wpdb->delete(
					$wpdb->prefix.'zoho_centre_staff_data',
					array('id'=>$id),
					array('%d')
				);
				
			if(!empty($Data['resume']))	{
				
				$targetPath = ZOHO_PLUGIN_PATH.'front/staffCV/'.$Data['resume'];

				unlink($targetPath);	
			}
			
			$response = array('status'=>'sucess');	
			
			
		}else{
			
			$response = array('status'=>'fail','message'=>'Please try again. Something went wrong.');	
		}
		
	}
	
	echo json_encode($response);
die;	
}

/* Update staff under centre */
add_action('wp_ajax_update_staff','update_staff');
function update_staff(){
	
	global $wpdb,$current_user;
	
	$ID     = base64_decode(sanitize_text_field($_POST['staffid']));
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	
	$getStaffInfo = $wpdb->get_row($wpdb->prepare("SELECT resume,zoho_id,zoho_attachment_id FROM $Table WHERE id =%d",$ID),ARRAY_A);
	
	$response = $error = $zohoParam = array();
	
	if(empty($getStaffInfo)){
		
		
		array_push($error,"You are not authorized person for update this staff.");
		$response = array('status'=>'fail','message'=>$error);
		
		
	}else{
		
		$fname     = sanitize_text_field($_POST['fname']);
		$lname     = sanitize_text_field($_POST['lname']);
		$email     = sanitize_email($_POST['email']);
		$jobtitle  = sanitize_text_field($_POST['jobtitle']);
		
		$zoho_record_id = $getStaffInfo['zoho_id'];
		
		$file      = $_FILES['cv']['name']; 
		$temp      = $_FILES['cv']['tmp_name'];
		$keysize   = $_FILES['cv']['size'];
		
		$keysizeinMB = number_format($keysize / 1048576);
		
		
		$supported = array('pdf','docx','doc');
		$ext       = strtolower(pathinfo($file, PATHINFO_EXTENSION));
		
		
		
		if(empty($fname)){
			array_push($error,"First Name field is required.");
		}if(empty($lname)){
			array_push($error,"Last Name field is required.");
		}if(empty($email)){
			array_push($error,"Email field is required.");
		}if(empty($jobtitle)){
			array_push($error,"Job Title field is required.");
		}
		
		if(empty($error)){
			
			if(empty($file)){
			
				$zohoParam['Name']      = $fname.' '.$lname;
				$zohoParam['Email']     = $email;
				$zohoParam['Job_title'] = $jobtitle;
				
			}else{
				
				if(!in_array($ext, $supported)){
					
					array_push($error,"CV format is not valid.");
					$response = array('status'=>'fail','message'=>$error);
				
				}elseif($keysizeinMB > 100){
					
					array_push($error,"Your CV is too big OR is greater than 100MB.");
					$response = array('status'=>'fail','message'=>$error);
					
					
				}else{
					
					$zohoParam['Name']      = $fname.' '.$lname;
					$zohoParam['Email']     = $email;
					$zohoParam['Job_title'] = $jobtitle;
				}
			}
			
			$ZOHOStaffdata         = array();
			$ZOHOStaffdata[]       = $zohoParam;
			
			$active_access_token = 1;
			if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
			{
				
				$active_access_token = get_refresh_token();
			}
			
			if($active_access_token === 1){
		
				$paramsStaff       	  = array('data'=>$ZOHOStaffdata);
				$ZohoInsertStaffData   = update_zoho_data('Centre_Staff', $paramsStaff, $zoho_record_id , 'PUT'); 
				
				if($ZohoInsertStaffData['body']['data'][0]['status'] == 'success'){
				
					$staff_record_id =  $ZohoInsertStaffData['body']['data'][0]['details']['id'];
					
					$zoho_attachment_id = $resumefile = '';
					
					if(!empty($file)){
						
						if(!empty($getStaffInfo['resume']) && !empty($getStaffInfo['zoho_attachment_id'])){
							
							$DeleteAttachment   = delete_zoho_data('Centre_Staff/'.$staff_record_id.'/Attachments/'.$getStaffInfo['zoho_attachment_id'],'DELETE'); 
							
							$targetPath = ZOHO_PLUGIN_PATH.'front/staffCV/'.$getStaffInfo['resume'];
							unlink($targetPath); 
							
						}
						
						/* move file in folder */
						
						$targetPath = ZOHO_PLUGIN_PATH.'front/staffCV/'.time().$file;
						
						$resumefile = time().$file;
						
						move_uploaded_file($temp, $targetPath);
						
						$Attachparams = array('file'=>new \CURLFILE($targetPath));
						$SendAttachment = request_zoho_file_upload('Centre_Staff/'.$staff_record_id.'/Attachments', $Attachparams,'POST');
						
						if($SendAttachment['status'] == 1){
							
							$zoho_attachment_id = $SendAttachment['id'];
						}
						
					}	
					
					/* Insert staff entry in WP */
					
					$wpdb->update(
								$Table,
								array(
										
										'fname'   			   =>    $fname,
										'lname'   			   =>    $lname,
										'email'   			   =>    $email,
										'job_title'   		   =>    $jobtitle,
										'resume'               =>    $resumefile,
										'zoho_attachment_id'   =>   $zoho_attachment_id,
										'updated'              =>    date('Y-m-d H:i:s')
								),
								array('id'=>$ID)
							);
							
					$response = array('status'=>'sucess','message'=>$fname.' '.$lname.' has been successfully updated.');		
					
				}
			
			}
			
		}else{
			
			$response = array('status'=>'fail','message'=>$error);
		}
	
	}
	
	echo json_encode($response);
	
die;	
}

/* Add additional qualification for learners */
add_action('wp_ajax_add_additional_qualification','callback_add_additional_qualification');
function callback_add_additional_qualification(){

	global $wpdb,$current_user;
	$centeruserID = $current_user->ID;	
	
	$userID        = intval($_POST['user']);
	$qualification = intval($_POST['qualification']);
	$sdate         = $_POST['sdate'];
	$edate         = $_POST['edate'];
	
	$response = $error = $RegisterAdmissionZOHOParam = array();
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	
	
	if(empty($userID)){
		array_push($error,"Learner field is required.");
	}if(empty($qualification)){
		array_push($error,"Qualification field is required.");
	}if(empty($sdate)){
		array_push($error,"Start Date field is required.");
	}if(empty($edate)){
		array_push($error,"End Date field is required.");
	}
	
	if(empty($error)){
		
		$quali          = get_qualification_name_by_id($qualification);
		$username       = get_learner_name_by_id($userID);
		$zoho_record_id = get_learner_zohorecoardid_by_userid($userID);

		/* check learners already exists select qualification */
		
		$AlreadyExistsQualification = $wpdb->get_row($wpdb->prepare("SELECT id FROM $learnersadmissiontable WHERE lid = %d AND qualification_id = %s",$userID,$qualification),ARRAY_A);
		
		if(!empty($AlreadyExistsQualification)){
			
			array_push($error,$username." already exists in <b>".$quali."</b> qualification. Please double check and submit form.");
			$response = array('status'=>'fail','message'=>$error);
			
		}else{
			
			$active_access_token = 1;
			if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
			{
				$active_access_token = get_refresh_token();
			}
			
			if($active_access_token === 1){
				
				$RegisterAdmissionZOHOParam['Name']                   =  $username;
				$RegisterAdmissionZOHOParam['Start_Date']             = date('Y-m-d',strtotime($sdate));
				$RegisterAdmissionZOHOParam['End_Date']               = date('Y-m-d',strtotime($edate));			
				$RegisterAdmissionZOHOParam['Associated_Learner']     = array('id'=>$zoho_record_id);			
				$RegisterAdmissionZOHOParam['Learner_Qualification']  = array('id'=>$qualification);	
                $RegisterAdmissionZOHOParam['Payment']                =  "Pending";				
							
				$ZOHOLearningAdmissiondata         = array();
				$ZOHOLearningAdmissiondata[]       = $RegisterAdmissionZOHOParam;
				$paramsAdmission       	           = array('data'=>$ZOHOLearningAdmissiondata);	

				$DataAdmission                     = request_zoho_data('Learners_Admission', $paramsAdmission,'POST');
				
				if($DataAdmission['body']['data'][0]['status'] == 'success'){
					
					$ADDMISSION_record_id =  $DataAdmission['body']['data'][0]['details']['id'];
					
					$wpdb->insert(
									$learnersadmissiontable,
									array(
											'lid'                =>    $userID,
											'center_id'          =>    $centeruserID,
											'qualification_id'   =>    $qualification,
											'start'              =>    date('Y-m-d',strtotime($sdate)),
											'name'               =>    $username,
											'end'                =>    date('Y-m-d',strtotime($edate)),
											'zoho_recoard_id'    =>    $ADDMISSION_record_id,
											'learner_zoho_id'    =>    $zoho_record_id,
											'created'            =>    date('Y-m-d H:i:s'),
											'updated'            =>    date('Y-m-d H:i:s')
									)
								);
								
					$response = array('status'=>'sucess','message'=>$quali." qualification has been successfully registered for <b>".$username."</b>");			
								
				}else{
					
					array_push($error,"Something went wrong while send data in zoho. Please try again.");
					$response = array('status'=>'fail','message'=>$error);
				}		
			}else{
				
				array_push($error,"Something went wrong while send data in zoho. Please try again.");
				$response = array('status'=>'fail','message'=>$error);
			} 
		}
		
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response); 
die;	
}

/* download Invoice */
add_action('wp_ajax_downlaod_invoice','downlaod_invoice');
function downlaod_invoice(){
	
	global $wpdb;
	
	$id = intval($_POST['ID']);
	$Table       = $wpdb->prefix.'zoho_xero_invoice';
	$Data   = $wpdb->get_row("SELECT attachment FROM $Table WHERE id = '".$id."'",ARRAY_A);
	$file_path = ZOHO_PLUGIN_URL.'front/invoice/'.$Data['attachment'];
	echo json_encode(array('url'=>$file_path,'name'=>basename($file_path)));
die;	
}

/* Load Invoice details */

add_action('wp_ajax_get_invoice_full_details','get_invoice_full_details');
function get_invoice_full_details(){
	
	global $wpdb;
	
	
	$ID     = intval($_POST['InvoiceID']);
	$table  = $wpdb->prefix.'zoho_xero_invoice';
	$result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d",$ID),ARRAY_A);
	$result['zoho_invoice_created_date'] = date('d M Y',strtotime($result['zoho_invoice_created_date']));
	$result['zoho_invoice_due_date'] = date('d M Y',strtotime($result['zoho_invoice_due_date']));
	
	$discount = $result['invoice_discount'];
	$tax      = $result['invoice_tax'];
	
	$calDiscount = $result['zoho_invoice_amount'] * $discount / 100;
	
	
	$total       = $result['zoho_invoice_amount'] - $calDiscount;
	$calTax      = $total * $tax / 100;
	
	$grandTotal  = $total +  $calTax;
	
	$result['amount']      = number_format($result['zoho_invoice_amount'],2);
	$result['calDiscount'] = number_format($calDiscount,2);
	$result['caltax']      = number_format($calTax,2);
	$result['grandtotal']  = number_format($grandTotal,2);
	
	$result['invoice_type'] = ( $result['invoice_type'] == 'Full') ? 'Full Payment' : $result['invoice_type'];
	
	
	echo json_encode($result);	
die;	
}

/* resubmit result by centre */
add_action('wp_ajax_resubmit_unit_results','resubmit_unit_results');
function resubmit_unit_results(){
	
	global $wpdb;
	
	$id        = intval($_POST['ID']);
	$recoardID = intval($_POST['recoardID']);
	$value     = sanitize_text_field($_POST['updategradeval']);
	
	$table     = $wpdb->prefix.'zoho_learners_results_meta';
	
	$response = array();
	
	$RegisterZOHOParam[] = array('Grade_8'=>$value);
	
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		$active_access_token = get_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$ZOHOLearningdata         = array();
		$ZOHOLearningdata         = $RegisterZOHOParam;
		$params       	          = array('data'=>$ZOHOLearningdata);	

		$Data                     = update_zoho_data('Learner_Results', $params, $recoardID, 'PUT');
		
		if(count($Data['body']['data']) > 0){
			
			$wpdb->update($table,array('grade'=>$value,'result_resubmit'=>1),array('result_id'=>$id));
		
			$response = array('status'=>'sucess','message'=>'Result has been updated successfully.');
			
		}else{
			
			$response = array('status'=>'fail','message'=>'Something went wrong, please try again after sometime.');
		}
	}
	
	echo json_encode($response);
	
die;	
}

/* send assept request to zoho */
add_action('wp_ajax_accept_request','accept_request');
function accept_request(){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_eqa_results_request';
	
	$date        = sanitize_text_field($_POST['acceptdate']);
	$recoardID   = intval($_POST['requestid']);

	$acceptdate = date('Y/m/d',strtotime($date));

	// Calculating the difference in timestamps
     $diff = strtotime($acceptdate) - strtotime(date('Y/m/d'));	
	 $diff = abs(round($diff / 86400));

	$response = array();
	
	if($diff > 14){
		
		$response = array('status'=>'fail','message'=>'This date should not be more than 14 days in the future.');
		
		
	}else{
		
		$active_access_token = 1;
		if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
		{
			$active_access_token = get_refresh_token();
		}
		
		if($active_access_token === 1){
			
			$RegisterZOHOParam[] = array('Request_Status'=>'Accepted','Result_Complete_Date'=>date('Y-m-d',strtotime($date)));
			
			$ZOHOLearningdata         = array();
			$ZOHOLearningdata         = $RegisterZOHOParam;
			$params       	          = array('data'=>$ZOHOLearningdata);	

			$Data                     = update_zoho_data('EQA_Result_Request', $params, $recoardID, 'PUT');
			
			if(count($Data['body']['data']) > 0){
				
				$wpdb->update(
								$table,
								array(
										'request_status'		=> 'Accepted',
										'result_completed_date' => $acceptdate,
										'updated'				=> date('Y-m-d H:i:s')
									),
									array(
											'zoho_request_id'	=> $recoardID
										)
							);
			
				$response = array('status'=>'sucess','message'=>'Thank you for accepting request.');
				
			}else{
				
				$response = array('status'=>'fail','message'=>'Something went wrong, please try again after sometime.');
			}
		}
	}
	
	echo json_encode($response);
die;	
}

/* request reject by eqa */
add_action("wp_ajax_reject_request_by_eqa","reject_request_by_eqa");
function reject_request_by_eqa(){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'zoho_eqa_results_request';
	
	$recoardID   = intval($_POST['ID']);
	
	$active_access_token = 1;
		if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
		{
			$active_access_token = get_refresh_token();
		}
		
		if($active_access_token === 1){
			
			$RegisterZOHOParam[] = array('Request_Status'=>'Rejected');
			
			$ZOHOLearningdata         = array();
			$ZOHOLearningdata         = $RegisterZOHOParam;
			$params       	          = array('data'=>$ZOHOLearningdata);	

			$Data                     = update_zoho_data('EQA_Result_Request', $params, $recoardID, 'PUT');
			
			if(count($Data['body']['data']) > 0){
				
				$wpdb->update(
								$table,
								array(
										'request_status'		=> 'Rejected',
										'updated'				=> date('Y-m-d H:i:s')
									),
									array(
											'zoho_request_id'	=> $recoardID
										)
							);
			
				$response = array('status'=>'sucess','message'=>'Thank you for accepting request.');
				
			}else{
				
				$response = array('status'=>'fail','message'=>'Something went wrong, please try again after sometime.');
			}
		}
		
		echo json_encode($response);
	
die;	
}

/* get Learner`s list for EQA with qualification wise */
add_action('wp_ajax_get_learners_list_for_eqa','get_learners_list_for_eqa');
function get_learners_list_for_eqa(){
	
	global $wpdb;
	
	$id    = intval($_POST['ID']);
	$result_report_id  = $_POST['result_report_id'];
	$table = $wpdb->prefix.'zoho_eqa_results_request';
	
	$resultstable     = $wpdb->prefix.'learners_results';
	$resultsmetatable = $wpdb->prefix.'zoho_learners_results_meta';
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	$GetData = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d",$id),ARRAY_A);
	
	$qualification = explode(',',$GetData['zoho_qualification_id']);
	$asign_centre  = $GetData['asign_centre'];
	$learners_ids  = explode(',',$GetData['learners_ids']);
	
	$lIDs = $QIDs = "";
	
	foreach($learners_ids as $ids){
		$lIDs .= "'".$ids."'".',';
	}
	
	foreach($qualification as $qids){
		$QIDs .= "'".$qids."'".',';
	}
	
	$removeLastComma  = rtrim($lIDs,',');
	$removeLastCommaQ = rtrim($QIDs,',');
	
	$wpCentreID = get_user_id_by_zohoid($asign_centre);
	
	$getresults = $wpdb->get_results("SELECT id,qualification_id,name FROM $learnersadmissiontable WHERE center_id = '".$wpCentreID."' AND qualification_id IN(".$removeLastCommaQ.") AND learner_zoho_id IN(".$removeLastComma.")",ARRAY_A);
	
	$information = array();
	
	foreach($getresults as $data){
		
		$Qname = get_qualification_name_by_id($data['qualification_id']);
		
		$information[] = array('id'=>$data['id'],'name'=>$data['name'],'qname'=>$Qname,'rid'=>$result_report_id);
	}
	
	echo json_encode($information);
	
die;	
}

/* get action point content by id */
add_action('wp_ajax_get_centre_action_point_content','get_centre_action_point_content');
function get_centre_action_point_content(){
	
	global $wpdb;
	
	$Table = $wpdb->prefix.'zoho_centre_action_point';
	
	$id = intval($_POST['ID']);
	
	$content = $wpdb->get_row($wpdb->prepare("SELECT action_point_content FROM $Table WHERE id = %d",$id),ARRAY_A);
	
	echo json_encode(array('content'=>$content['action_point_content']));
	
die;	
}

/* centre upload Evidence */

add_action('wp_ajax_centre_upload_Evidence','centre_upload_Evidence');
function centre_upload_Evidence(){
	
	ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);
	
	global $wpdb;
	
	$Table = $wpdb->prefix.'zoho_centre_action_point';
	
	$id = intval($_POST['id']);
	
	$Getdata = $wpdb->get_row($wpdb->prepare("SELECT zoho_action_point_id FROM $Table WHERE id = %d",$id),ARRAY_A);
	
	if(empty($Getdata['zoho_action_point_id'])){
		
		$response = array('status' => 'fail','message' => 'Something went wrong. Please try again.');
		
	}else{
		
		$file      = $_FILES['evidence']['name']; 
		$temp      = $_FILES['evidence']['tmp_name'];
		$keysize   = $_FILES['evidence']['size'];
		
		$keysizeinMB = number_format($keysize / 1048576);
		
		
		$supported = array('pdf','docx','doc','jpg','jpeg','png');
		$ext       = strtolower(pathinfo($file, PATHINFO_EXTENSION));
		
		$response = $error = $zohoParam = array();
		
		if(empty($file)){
			
			$response = array('status' => 'fail','message' => 'Please enter evidence document.');
			
		}elseif(!in_array($ext, $supported)){
							
			$response = array('status' => 'fail','message' => 'Evidence document format is not valid.');				
							
		}else{
			
			$targetPath = ZOHO_PLUGIN_PATH.'front/evidence/'.time().$file;
							
			$Evidencefile = time().$file;
			
			move_uploaded_file($temp, $targetPath);
			
			$active_access_token = 1;
			if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
			{
				
				$active_access_token = get_refresh_token();
			}
			
			if($active_access_token === 1){
				
				$Attachparams = array('file'=>new \CURLFILE($targetPath));
				
				$SendAttachment = request_zoho_file_upload('Centre_Action_Points/'.$Getdata['zoho_action_point_id'].'/Attachments', $Attachparams,'POST');
				
				if($SendAttachment['status'] == 1){
					
					$zohoParam['Evidence_Document_Upload']      = true;
					
					
					$ZOHOStaffdata         = array();
					$ZOHOStaffdata[]       = $zohoParam;
			
					$paramsStaff       	  = array('data'=>$ZOHOStaffdata);
					$ZohoInsertStaffData   = update_zoho_data('Centre_Action_Points', $paramsStaff, $Getdata['zoho_action_point_id'] , 'PUT'); 
					
					$wpdb->update($Table,array('evidence'=>$Evidencefile),array('id'=>$id));
					
					$response = array('status' => 'sucess','message' => 'Evidence has been successfully saved.');
					
				}else{
					
					$response = array('status' => 'fail','message' => 'Evidence document does not saved. Please try again.');
				}
			}
			
		}
	
	}
	
	echo json_encode($response);
	
die;	
}

/* download centre Evidence */
add_action('wp_ajax_downlaod_centre_upload_evidence','downlaod_centre_upload_evidence');
function downlaod_centre_upload_evidence(){
	
	global $wpdb;
	
	$id = intval($_POST['ID']);
	
	$Table       = $wpdb->prefix.'zoho_centre_action_point';
	
	$Data   = $wpdb->get_row("SELECT evidence FROM $Table WHERE id = '".$id."'",ARRAY_A);
	
	$file_path = ZOHO_PLUGIN_URL.'front/evidence/'.$Data['evidence'];
	
	echo json_encode(array('url'=>$file_path,'name'=>basename($file_path)));
die;	
}

/* Add Learner report By EQA */
add_action('wp_ajax_get_learners_data_for_report','get_learners_data_for_report');
function get_learners_data_for_report(){
	
	global $wpdb;
	
	$requestid = intval($_POST['requestID']);
	
	$Table       = $wpdb->prefix.'zoho_eqa_results_request';
	
	$TableLearners       = $wpdb->prefix.'custom_learners';
	
	$TableQualifications  = $wpdb->prefix.'custom_qualification';
	
	$TableUnits  = $wpdb->prefix.'zoho_unit';
	
	$TableReport_submission_eqa_learners  = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	
	
	$getInfo     = $wpdb->get_row($wpdb->prepare("SELECT result_report_id,asign_centre,learners_ids,zoho_qualification_id FROM $Table WHERE id =%d",$requestid),ARRAY_A);
	
	
	$response = array();
	
	if(empty($getInfo)){
		
		$response = array('status' => 'fail', 'message' => 'You are not authorized to add Learner entry.');
		
	}else{
		
		$information = array('result_report_id' => $getInfo['result_report_id'], 'asign_centre' => $getInfo['asign_centre']);
		
		$learners_ids       = explode(',',$getInfo['learners_ids']);
		$qualification_ids  = explode(',',$getInfo['zoho_qualification_id']);
		
		$lIDs = $QIDs = "";
	
		foreach($learners_ids as $ids){
			$lIDs .= "'".$ids."'".',';
		}
		
		foreach($qualification_ids as $ids){
			$QIDs .= "'".$ids."'".',';
		}
		
		$removeLastComma   = rtrim($lIDs,',');
		$removeLastCommaQ  = rtrim($QIDs,',');
		
		$getLearners = $wpdb->get_results("SELECT zoho_recoard_id,name FROM $TableLearners WHERE zoho_recoard_id IN(".$removeLastComma.")",ARRAY_A);
		
		$getQs 		= $wpdb->get_results("SELECT zoho_record_id	,name FROM $TableQualifications WHERE zoho_record_id IN(".$removeLastCommaQ.")",ARRAY_A);
		
		$information['qualification'] = $getQs;
		
		$information['learner'] = $getLearners;
		
		$information['grade'] = array('Pass','Merit','Distinction','Fail');
		
		$response = array('status' => 'sucess' , 'data' => $information);
		
	}
	
	echo json_encode($response);
	
die;	
}

add_action('wp_ajax_get_related_units','get_related_units');
function get_related_units(){
	
	
	global $wpdb;
	
	$QID = intval($_POST['QID']);
	
	$Table = $wpdb->prefix.'zoho_relation_unit_qualification';
	
	$TableUnits = $wpdb->prefix.'zoho_unit';
	
	$response = array();
	
	$query  = "SELECT t1.unit_name,t1.zoho_unit_id FROM $TableUnits as t1 LEFT JOIN $Table as t2 ON t2.unit_id = t1.zoho_unit_id WHERE t2.quali_id = $QID ORDER BY t1.unit_name ASC";
	
	
	$getdata = $wpdb->get_results($query,ARRAY_A);
	
	if(empty($getdata)){
		
		$response = array('status' => 'fail' , 'message' => 'No units found in this qualification');
		
	}else{
		
		$response = array('status' => 'sucess' , 'data' => $getdata );
	}
	
	echo json_encode($response	);
	
die;	
}

/* Save entry By EQA for Learner result submit */
add_action("wp_ajax_save_eqa_submit_learner_report","save_eqa_submit_learner_report");
function save_eqa_submit_learner_report(){
	
	global $wpdb;
	
	$Table = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	
	$reportlearners 	 = intval($_POST['reportlearners']);
	$reportqualification = intval($_POST['reportqualification']);
	$reportunit 		 = intval($_POST['reportunit']);
	$grade 				 = sanitize_text_field($_POST['grade']);
	$judgement 			 = sanitize_text_field($_POST['judgement']);
	$feedback 			 = sanitize_text_field($_POST['feedback']);
	$centreID 			 = intval($_POST['centreID']);
	$ReportID 			 = intval($_POST['ReportID']);
	
	$response = $error  = array();
	
	if(empty($reportlearners)){
		array_push($error,"Learner field can`t empty.");
	}if(empty($reportqualification)){
		array_push($error,"Qualification field can`t empty.");
	}if(empty($reportunit)){
		array_push($error,"Unit Title field can`t empty.");
	}if(empty($grade)){
		array_push($error,"Grade field can`t empty.");
	}if(empty($judgement)){
		array_push($error,"EQA judgement field can`t empty.");
	}if(empty($feedback)){
		array_push($error,"Feedback field can`t empty.");
	}
	
	if(empty($error)){
		
		$checkAlreadyrecoardExists = $wpdb->get_row($wpdb->prepare("SELECT id FROM $Table WHERE qualification_id = %s AND learner_id = %s AND unit_id = %s AND zoho_report_submission_id = %s",$reportqualification,$reportlearners,$reportunit,$ReportID));
		
		if(!empty($checkAlreadyrecoardExists)){
			
			array_push($error,"You have already added entry with details. Please choose another data.");
			
			$response = array('status'=>'fail','message'=>$error);
			
		}else{
			
			$rpl = isset($_POST['rpl']) ? 1 : 0;
		
	
			$wpdb->insert(
			
							$Table,
							
							array(
							
										'RPL' 					=> $rpl,
										'qualification_id'		=> $reportqualification,
										'learner_id'			=> $reportlearners,
										'unit_id'				=> $reportunit,
										'grade'					=> $grade,
										'EQA_judgement'			=> $judgement,
										'feedback'				=> $feedback,
										'centre_id'				=> $centreID,
										'zoho_report_submission_id'		=> $ReportID,
										'is_sent'						=> 0,
										'created'        => date('Y-m-d H:i:s')
								 )
			
						 );
								 
			$response = array('status'=>'sucess','message'=>"Recoard has been sucessfully saved");
		}
		
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response);
	
die;	
}

/* Display  Learner report By EQA */
add_action('wp_ajax_update_learners_data_for_report','update_learners_data_for_report');
function update_learners_data_for_report(){
	
	global $wpdb;
	
	$requestid = intval($_POST['requestID']);
	
	$EditId = intval($_POST['EditId']);
	
	$Table       = $wpdb->prefix.'zoho_eqa_results_request';
	
	$TableLearners       = $wpdb->prefix.'custom_learners';
	
	$TableQualifications  = $wpdb->prefix.'custom_qualification';
	
	$TableUnits  = $wpdb->prefix.'zoho_unit';
	
	$TableReport_submission_eqa_learners  = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	
	
	$getInfo     = $wpdb->get_row($wpdb->prepare("SELECT result_report_id,asign_centre,learners_ids,zoho_qualification_id FROM $Table WHERE id =%d",$requestid),ARRAY_A);
	
	$getSubmitLD     = $wpdb->get_row($wpdb->prepare("SELECT * FROM $TableReport_submission_eqa_learners WHERE id =%d",$EditId),ARRAY_A);
	
	
	$response = array();
	
	if(empty($getInfo)){
		
		$response = array('status' => 'fail', 'message' => 'You are not authorized to add Learner entry.');
		
	}else{
		
		$information = array('result_report_id' => $getInfo['result_report_id'], 'asign_centre' => $getInfo['asign_centre']);
		
		$learners_ids       = explode(',',$getInfo['learners_ids']);
		$qualification_ids  = explode(',',$getInfo['zoho_qualification_id']);
		
		$lIDs = $QIDs = "";
	
		foreach($learners_ids as $ids){
			$lIDs .= "'".$ids."'".',';
		}
		
		foreach($qualification_ids as $ids){
			$QIDs .= "'".$ids."'".',';
		}
		
		$removeLastComma   = rtrim($lIDs,',');
		$removeLastCommaQ  = rtrim($QIDs,',');
		
		$getLearners = $wpdb->get_results("SELECT zoho_recoard_id,name FROM $TableLearners WHERE zoho_recoard_id IN(".$removeLastComma.")",ARRAY_A);
		
		$getQs 		= $wpdb->get_results("SELECT zoho_record_id	,name FROM $TableQualifications WHERE zoho_record_id IN(".$removeLastCommaQ.")",ARRAY_A);
		
		$information['qualification'] = $getQs;
		
		$information['learner'] = $getLearners;
		
		$information['grade'] = array('Pass','Merit','Distinction','Fail');
		
		$information['judgement'] = array('EQA agrees with decision','EQA does not agree with assessment decision');
		
		$information['updateData'] = $getSubmitLD;
		
		$UNits = get_related_units_by_qualificationID($getSubmitLD['qualification_id']);
		
		$information['units'] = $UNits['data'];
		
		$response = array('status' => 'sucess' , 'data' => $information);
		
	}
	
	echo json_encode($response);
	
die;	
}

/* Update entry By EQA for Learner result submit */
add_action("wp_ajax_update_eqa_submit_learner_report","update_eqa_submit_learner_report");
function update_eqa_submit_learner_report(){
	
	global $wpdb;
	
	$Table = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	
	$reportlearners 	 = intval($_POST['reportlearners']);
	$reportqualification = intval($_POST['reportqualification']);
	$reportunit 		 = intval($_POST['reportunit']);
	$grade 				 = sanitize_text_field($_POST['grade']);
	$judgement 			 = sanitize_text_field($_POST['judgement']);
	$feedback 			 = sanitize_text_field($_POST['feedback']);
	$centreID 			 = intval($_POST['centreID']);
	$ReportID 			 = intval($_POST['ReportID']);
	
	$updateID 			 = intval($_POST['updateID']);
	
	$response = $error  = array();
	
	if(empty($reportlearners)){
		array_push($error,"Learner field can`t empty.");
	}if(empty($reportqualification)){
		array_push($error,"Qualification field can`t empty.");
	}if(empty($reportunit)){
		array_push($error,"Unit Title field can`t empty.");
	}if(empty($grade)){
		array_push($error,"Grade field can`t empty.");
	}if(empty($judgement)){
		array_push($error,"EQA judgement field can`t empty.");
	}if(empty($feedback)){
		array_push($error,"Feedback field can`t empty.");
	}
	
	if(empty($error)){
		
		$rpl = isset($_POST['rpl']) ? 1 : 0;
		
	
		$wpdb->update(
		
						$Table,
						
						array(
						
									'RPL' 					=> $rpl,
									'qualification_id'		=> $reportqualification,
									'learner_id'			=> $reportlearners,
									'unit_id'				=> $reportunit,
									'grade'					=> $grade,
									'EQA_judgement'			=> $judgement,
									'feedback'				=> $feedback,
									'centre_id'				=> $centreID,
									'zoho_report_submission_id'		=> $ReportID,
									'is_sent'						=> 0,
									'created'        => date('Y-m-d H:i:s')
							 ),
							 array('id' => $updateID)
		
					 );
					 		 
		$response = array('status'=>'sucess','message'=>"Recoard has been sucessfully saved");
		
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response);
	
die;	
}

/* Delete learner entry by eqa */
add_action("wp_ajax_delete_learner_eqa_report","delete_learner_eqa_report");
function delete_learner_eqa_report(){
	
	global $wpdb;
	
	$deliD  = intval($_POST['deleid']);
	$Table  = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	$output = $wpdb->delete($Table,array('id'=>$deliD));
	
	$response = array();
	
	if( !is_wp_error( $output ) ){
		
		$response = array("message" => "Recoard has been sucessfully deleted.");
		
	}else{
		
		$response = array("message" => "Please try again.");
	}
	
	echo json_encode($response);
die;	
}

/* Send Learner report data by EQA */

add_action("wp_ajax_send_leareners_data","send_leareners_data");
function send_leareners_data(){
	
	ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
	
	global $wpdb;
	$Table  = $wpdb->prefix.'zoho_report_submission_eqa_learners';
	
	$ids = $_POST['ids'];
	
	$lIDs = "";
	
	
	
	$response = $ZOHOParam = array();
	
	foreach($ids as $id){
		$lIDs .= "'".$id."'".',';
	}
		
	$removeLastCommaQ  = rtrim($lIDs,',');
	
	$getLearners = $wpdb->get_results("SELECT * FROM $Table WHERE id IN(".$removeLastCommaQ.")",ARRAY_A);
	
	if(!empty($getLearners)){
		
		$reportID = array();
		
		foreach($getLearners as $data){
			
			if(!in_array($data['zoho_report_submission_id'],$reportID)){
				
				array_push($reportID,$data['zoho_report_submission_id']);
			}
			
			$rpl = $data['RPL'] > 0 ? true : false;
			
			$ZOHOParam[] = array(
													'Is_RPL_being_used_against_this_learner' => $rpl,
													'learners_Qualification'				 => array('id'=> $data['qualification_id']),
													'Learner_Name'                           => array('id'=> $data['learner_id']),
													'Unit'                           		 => array('id'=> $data['unit_id']),
													'Grade_based_on_EQA_judgement'           => $data['grade'],
													'EQA_judgement'           				 => $data['EQA_judgement'],
													'Feedback_Comments'           			 => $data['feedback'],
												);
		}
		
		$subformData = array('Learner_Sample'=>$ZOHOParam);
		
		$active_access_token = 1;
		if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
		{
			$active_access_token = get_refresh_token();
		}

		if($active_access_token === 1){
			
			
				$ZOHOdata          = array();
				$ZOHOLdata[]       = $subformData;
				$params       	   = array('data'=>$ZOHOLdata);
				
				$Data              = update_zoho_data('EQA_Report_Submission', $params, $reportID[0], 'PUT');
				
				if($Data['body']['data'][0]['status'] == 'success'){
					
					$query = $wpdb->query("Update $Table SET is_sent = 1 WHERE id IN(".$removeLastCommaQ.")");
				}
				
				$response = array("message" => "Recoard has been sucessfully submit.");
				
		}
		
		
	}else{
		
		$response = array("message" => "Please try again.");
	}
	
	echo json_encode($response);
die;	
}

/* see qualification list */
add_action("wp_ajax_export_qualification_list","export_qualification_list");
function export_qualification_list(){
	
	global $wpdb,$current_user;
	
	$Table   = $wpdb->prefix.'center_register_qualification';
	$Table2  = $wpdb->prefix.'custom_qualification';
	
	$query = "Select t2.name, t2.zoho_record_id FROM $Table2 as t2 LEFT JOIN $Table as t1 ON t2.zoho_record_id = t1.qualification_id WHERE t1.center_id = ".$current_user->ID;
	
	$getQualification = $wpdb->get_results($query,ARRAY_A);
	
	echo json_encode($getQualification);
die;	
}

/* export learners by csv */

add_action("wp_ajax_export_learners_csv","export_learners_csv");
function export_learners_csv(){
	
	global $wpdb;
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	$nonce =  sanitize_text_field($_POST['inzoho']);
	
	$keyname = $_FILES['exportlearners']['name'];
	$tmpName = $_FILES['exportlearners']['tmp_name'];
	$keysize = $_FILES['exportlearners']['size'];
	
	//echo '<pre>'; print_r($_FILES); die;
	
	$supported_image = array('csv');
	
	$ext = strtolower(pathinfo($keyname, PATHINFO_EXTENSION));
	
	$response = $error = array();
	
	if(!wp_verify_nonce( $nonce, 'fel' )){
		
		array_push($error,"The security code did not match. Please try again.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(!in_array($ext, $supported_image)){  
		
		array_push($error,"The file extension is not supported.");
		$response = array('status'=>'fail','message'=>$error);
		
	}else{
		
		 // count row number 
		$row = 0;
		// add you row number for skip 
		// hear we pass 1st row for skip in csv 
		$skip_row_number = array("1");
		$csv_data = array();
		
		 if ($keysize < 1) {
			 
			 array_push($error,"Please insert data in file.");
			 $response = array('status'=>'fail','message'=>$error);
			 
			 
		 }else{
		 
			if(($handle = fopen($tmpName, 'r')) !== FALSE) {
				
				// necessary if a large csv file
				set_time_limit(0);

				$row = 0;

				while(($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
					$row++;	
					// count total filed of csv row 
					$num = count($data);  
					// check row for skip row 	
					if (in_array($row, $skip_row_number))	
					{
						continue; 
						// skip row of csv
					}
					else
					{
						// print row number and total filed of csv
						$csv_data[] = $data;
						// add data in to array 
					}    
				}
				fclose($handle);
			}
			
			if(empty($csv_data) && count($csv_data) < 0){
				
				
				array_push($error,"Please insert data in file.");
				$response = array('status'=>'fail','message'=>$error);
				
				
			}else{
				
				/* First validate centre ID */
				
				$results 		= check_centre_ids($csv_data);
				
				$duplicateEmail = check_duplicate_export_emailid($csv_data);
				
				$alreadyReg = check_already_registers_learners($csv_data);
					
				
				if(!empty($results)){
					
					array_push($error,"Some Centre ID is not valid. Please double check and upload again.");
					$response = array('status'=>'fail','message'=>$error);
					
					
				}elseif($duplicateEmail == 1){
					
					array_push($error,"Some email are duplicates in learner details.");
					$response = array('status'=>'fail','message'=>$error);
					
					
				}elseif(!empty($alreadyReg)){
					
					$response = array('status'=>'fail','message'=>$alreadyReg);
					
				}else{
				
					$RegisterZOHOParam = $userLIDs = $RegisterAdmissionZOHOParam = $userLIDAdmissions = array();
					
					$Lname = $LstartDate = $Lenddate = $Lqualification = array();
					
					//echo '<pre>'; print_r($csv_data); die;
				
					foreach($csv_data as $row){
						
							$CentreID  	   = $row[0];
							$QID       	   = $row[1];
							$Funding       = $row[2];
							$sdate         = $row[3];
							$edate         = $row[4];
							$name          = $row[5];
							$dob           = $row[6];
							$gender        = $row[7];
							$Ethnicity     = $row[8];
							$email         = $row[9];
							$language      = $row[10];
						
							$validateID = validate_duplicateCenterID($CentreID);
							$cuserid = validate_duplicateCenterUserID($CentreID);
							
							/* Add Learners */
						
							$wpdb->insert(
										$learnerstable,
										array(
												'center_id'          =>    $CentreID,
												'center_user_id'     =>    $cuserid,
												'funding'            =>    $Funding,
												'name'               =>    $name,
												'dob'                =>    date('Y-m-d',strtotime($dob)),
												'gender'             =>    $gender,
												'ethnicity'          =>    $Ethnicity,
												'email'              =>    $email,
												'language'           =>    $language,
												'created'            =>    date('Y-m-d H:i:s'),
												'updated'            =>    date('Y-m-d H:i:s'),
												'registered_status'  =>    'Pending'
										)
									);
									
							$lastInserid = $wpdb->insert_id;	
							
							array_push($userLIDs,$lastInserid);
							
							array_push($Lname,$name);

							array_push($LstartDate,$sdate);
							
							array_push($Lenddate,$edate);
							
							array_push($Lqualification,$QID);
		

							
							$RegisterZOHOParam[] = array(
						
												'Centre_ID_Number' 		=> $CentreID,
												'Government_Funded'		=> $Funding,
												'Name'		            => $name,
												'Date_of_birth'		    => date('Y-m-d',strtotime($dob)),
												'Gender'		    	=> $gender,
												'Ethnicity'		    	=> $Ethnicity,
												'Email'		    	    => $email,
												'Assessment_Language'   => $language,
												'Associated_Center'     => array('id'=>$validateID),
												'Is_learners_registered_or_not' => 'Pending'
											);
							
					}
					
					$active_access_token = 1;
					if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
					{
						$active_access_token = get_refresh_token();
					}
					
					
					if($active_access_token === 1){
						
						$ZOHOLearningdata         = array();
						$ZOHOLearningdata         = $RegisterZOHOParam;
						$params       	          = array('data'=>$ZOHOLearningdata);	

						$Data                     = request_zoho_data('Learner_Registration', $params,'POST');
						
						
						if(count($Data['body']['data']) > 0){
							
							foreach($Data['body']['data'] as $key=>$recoards){
								
								$zoho_record_id =  $recoards['details']['id'];
								
								/* Update Zoho ID with Learners */
								
								$wpdb->update($learnerstable,array('zoho_recoard_id'=>$zoho_record_id),array('id'=>$userLIDs[$key]));
									
								/* Send admission data in zoho and created a entry in wp */	
								
								$wpdb->insert(
									$learnersadmissiontable,
									array(
											'lid'                =>    $userLIDs[$key],
											'center_id'          =>    $cuserid,
											'qualification_id'   =>    $Lqualification[$key],
											'start'              =>    date('Y-m-d',strtotime($LstartDate[$key])),
											'name'               =>    $Lname[$key],
											'learner_zoho_id'    =>	   $zoho_record_id,
											'end'                =>    date('Y-m-d',strtotime($Lenddate[$key])),
											'created'            =>    date('Y-m-d H:i:s'),
											'updated'            =>    date('Y-m-d H:i:s'),	
											
										)
								);
								
								$lastAddmissionInserid = $wpdb->insert_id;	
								
								//array_push($userLIDAdmissions,$lastAddmissionInserid);
								
								$RegisterAdmissionZOHOParam['Name']                   = $Lname[$key];
								$RegisterAdmissionZOHOParam['Start_Date']             = date('Y-m-d',strtotime($LstartDate[$key]));
								$RegisterAdmissionZOHOParam['End_Date']               = date('Y-m-d',strtotime($Lenddate[$key]));			
								$RegisterAdmissionZOHOParam['Associated_Learner']     = array('id'=>$zoho_record_id);			
								$RegisterAdmissionZOHOParam['Learner_Qualification']  = array('id'=>$Lqualification[$key]);
								$RegisterAdmissionZOHOParam['Payment']                =  'Pending';								
											
								$ZOHOLearningAdmissiondata         = array();
								$ZOHOLearningAdmissiondata[]         = $RegisterAdmissionZOHOParam;
								$paramsAdmission       	           = array('data'=>$ZOHOLearningAdmissiondata);	

								$DataAdmission                     = request_zoho_data('Learners_Admission', $paramsAdmission,'POST');
								
								if($DataAdmission['body']['data'][0]['status'] == 'success'){
									
									$ADDMISSION_record_id =  $DataAdmission['body']['data'][0]['details']['id'];
									
									$wpdb->update($learnersadmissiontable,array('zoho_recoard_id'=>$ADDMISSION_record_id),array('id'=>$lastAddmissionInserid));
								}		
								
							}
						
							$response = array('status'=>'sucess','message'=>'Data has been successfully imported.');
							
						}else{
							
							array_push($error,"Something went wrong. Please try again.");
							$response = array('status'=>'fail','message'=>$error);
						}
						
					}
					
					
				}
			}
		  
		 }
	}
	echo json_encode($response);
die;	
}

function check_centre_ids($data){
	
	$ststus = array();
	
	foreach($data as $row){
					
		$centerID  	   = $row[0];
		$validateID    = validate_duplicateCenterID($centerID);
		$cuserid 	   = validate_duplicateCenterUserID($centerID);
		
		 if(empty($validateID)){
			 
			 array_push($ststus,1);
		 }
	}
	
	return $ststus;
}

function check_duplicate_export_emailid($data){
	
	$emails = array();
	
	foreach($data as $row){
					
		$email  	   = $row[9];
		array_push($emails,$email);
	}
	
	$emailStatus = 0;
	
	if ( count( $emails ) !== count( array_unique( $emails ) ) ) {
		
		$emailStatus = 1;
	}
	
	return $emailStatus;
}

function check_already_registers_learners($data){
	
	global $wpdb;
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	$error = array();
	
	foreach($data as $row){
					
		$email  	   = $row[9];
		$Info = $wpdb->get_row($wpdb->prepare("SELECT email FROM $learnerstable WHERE email = %s",$email),ARRAY_A);
		
		if(!empty($Info)){
						
			array_push($error,'<b>'.$email.'</b> this email id already registered.');
		}
	}
	
	return $error;
}

/* check learner registered or not */
add_action('wp_ajax_check_learners_status','callback_check_learners_status');
add_action('wp_ajax_nopriv_check_learners_status','callback_check_learners_status');
function callback_check_learners_status(){
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	global $wpdb;
	
	$response = $error = array();
	
	$table = $wpdb->prefix.'custom_learners';
	$table2 = $wpdb->prefix.'custom_learners_admission';
	
	$email = sanitize_email($_POST['lemail']);
	$dob = sanitize_text_field($_POST['dob']);
	$nonce =  sanitize_text_field($_POST['lstatus']);
	
	if(!wp_verify_nonce( $nonce, 'plstatus' )){
		
		array_push($error,"The security code did not match. Please try again.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(empty($email)){  
		
		array_push($error,"Please enter a valid email address.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(empty($dob)){  
		
		array_push($error,"Please enter date of birth.");
		$response = array('status'=>'fail','message'=>$error);
		
	}else{
		
		 $convertDate = date('Y-m-d',strtotime($dob));
		
		$GetData = $wpdb->get_row($wpdb->prepare("SELECT name,registered_status,created,center_user_id FROM $table WHERE email = %s AND dob = %s",$email,$convertDate),ARRAY_A);
		
		if(empty($GetData)){
			
			array_push($error,"There is no learner registered with this email ID.");
			$response = array('status'=>'fail','message'=>$error);
			
		}else{
			
			$centreOrg = !empty(get_user_meta($GetData['center_user_id'],'organisation_name',true)) ? get_user_meta($GetData['center_user_id'],'organisation_name',true) : 'N/A';
			
			$LearnerInfo = array(
									'name'     		=> $GetData['name'],
									'rstatus'   		=> $GetData['registered_status'],
									'created'  		=> date('M d, Y',strtotime($GetData['created'])),
									'centre_name'	=> $centreOrg
								);
								
			$response = array('status'=>'sucess','message'=>$LearnerInfo);					
		}
	}
	
	echo json_encode($response);
die;	
}

/* check learner registered or not */
add_action('wp_ajax_check_learners_certificate_status','callback_check_learners_certificate_status');
add_action('wp_ajax_nopriv_check_learners_certificate_status','callback_check_learners_certificate_status');
function callback_check_learners_certificate_status(){
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	global $wpdb;
	
	$response = $error = array();
	
	$table = $wpdb->prefix.'custom_learners_admission';
	
	$qid 		= intval($_POST['qualification']);
	$credit 	= intval($_POST['credit']);
	$nonce 		=  sanitize_text_field($_POST['lcstatus']);
	$name 		=  sanitize_text_field($_POST['name']);
	
	if(!wp_verify_nonce( $nonce, 'plcstatus' )){
		
		array_push($error,"The security code did not match. Please try again.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(empty($name)){  
		
		array_push($error,"Name field is not empty.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(empty($qid)){  
		
		array_push($error,"The Qualification field is not empty.");
		$response = array('status'=>'fail','message'=>$error);
		
	}elseif(empty($credit)){  
		
		array_push($error,"The credit value field is not empty.");
		$response = array('status'=>'fail','message'=>$error);
		
	}else{
		
		$GetData = $wpdb->get_row($wpdb->prepare("SELECT updated,overall_grade,certification_id FROM $table WHERE name = %s AND qualification_id = %s AND credit_value = %s AND is_completed = %d",$name,$qid,$credit,1),ARRAY_A);
		
		if(empty($GetData)){
			
			array_push($error,"No learner certificates were found.");
			$response = array('status'=>'fail','message'=>$error);
			
		}else{
			
			$certificationInfo = array(
									'overall_grade'     	=> $GetData['overall_grade'],
									'certification_id'   	=> $GetData['certification_id'],
									'created'  				=> date('M d, Y',strtotime($GetData['updated'])),
								);
								
			$response = array('status'=>'sucess','message'=>$certificationInfo);	
		}
	}
	
	echo json_encode($response);
die;	
}
?>