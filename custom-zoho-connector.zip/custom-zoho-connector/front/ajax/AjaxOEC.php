<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$user = $current_user->ID;
	
	$Table       = $wpdb->prefix.'custom_learners_admission';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND (DATE(end) BETWEEN DATE(NOW()) AND DATE(NOW()) + INTERVAL 7 day) AND is_completed = 0 AND center_id = '".$user."'";

	
	$getData    = $wpdb->get_results("SELECT * FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	//echo $wpdb->last_query;
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();
	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$row){
			
			

			$recoards[$key] = array(
										
										'lname' => $row['name'],
										'qname' => get_qualification_name_by_id($row['qualification_id']),
										'sdate' => date('M d,Y', strtotime($row['start'])),
										'edate' => date('M d,Y', strtotime($row['end']))
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response); 
	
?>