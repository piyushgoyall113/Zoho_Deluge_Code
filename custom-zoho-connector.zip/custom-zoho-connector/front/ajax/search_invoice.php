<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$userID = $current_user->ID;
	
	$keyword = $_POST['search']['value'];
	
	$Table       = $wpdb->prefix.'zoho_xero_invoice';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND userid = $userID";
	
	if(!empty($keyword)){
	
		$where = " AND ( xero_invoice_no LIKE '%".$keyword."%')  AND userid = '".$userID."'";
		
	}
	
	$getData    = $wpdb->get_results("SELECT * FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();
	
	$currency = get_option('xero_currency');
	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$result){
			
			$ID            = $result['id'];
			$invoiceNumber = $result['xero_invoice_no'];
			$date          = date('d M Y',strtotime($result['zoho_invoice_created_date']));
			$duedate       = date('d M Y',strtotime($result['zoho_invoice_due_date']));
			$type          = $result['invoice_type'];
			$amount        = $result['zoho_invoice_amount'];
			$discount      = $result['invoice_discount'];
			$tax           = $result['invoice_tax'];
			$pname         = $result['zoho_product_name'];
			$status        = $result['payment_status'];
			$attachment    = $result['attachment'];
			$invoicename   = $result['zoho_product_name'];
			$xero_invoice_url   = $result['xero_invoice_url'];
			
			
			$calDiscount = $amount * $discount / 100;
			$total       = $amount - $calDiscount;
			$calTax      = $total * $tax / 100;
			$grandTotal  = $total +  $calTax;
			
			$invoicePdf = '';
			
			if(!empty($attachment)){
				
				$invoicePdf =  '<a href="javascript:void(0)" class="invoicedownloadmanually" data-id="'.$ID.'" title="Download Invoice">
				<i class="fa fa-file-pdf-o"></i></a>';
			}
			
			$classpaymentstatus = ($status == 'PAID') ? 'badge-success p-1' : 'badge-secondary p-1';
			
			$date1 = new DateTime($result['zoho_invoice_due_date']);
			$date2 = new DateTime(date('Y-m-d'));
			$interval = $date1->diff($date2);
			
			$statusOverDue = '';
			
			if($status != 'PAID'){
				
				if( strtotime(date('Y-m-d')) > strtotime($result['zoho_invoice_due_date']) )
				{
				
					if($interval->days > 0)
					{
						$statusOverDue = '<span style="color:red;">'.$interval->days.' days</span>';
					}
				}
			}
			
			$paymentlink = '';
			
			if($result['payment_status'] != 'PAID' && !empty($result['xero_invoice_url'])){
											
				$paymentlink  =  '<a href="'.$result['xero_invoice_url'].'" target="_blank" class="btn btn-info" style="text-decoration:none;padding: 2px;">Pay Invoice</a>';
				
			}
			
			$recoards[$key] = array(
										'number'      => $invoiceNumber,
										'invoicename' => $invoicename,
										'date'        => $date,
										'duedate'     => $duedate,
										'overdue'     => $statusOverDue,
										'type'        => $type,
										'total'  	  => $currency.' '.number_format($grandTotal,2),
										'status'      => '<span class="pstatus '.$classpaymentstatus.'">'.$status.'</span>',
										'action'      => '<a class="invoiceinfo" href="javascript:void(0)" title="View Invoice Details" data-id="'.$ID.'"><i class="fa-eye fa"></i></a>&nbsp;'.$invoicePdf,
										'paymentlink' => $paymentlink
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response);
	
?>	