<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$userID = $current_user->ID;
	
	$keyword = $_POST['search']['value'];
	
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND center_id = $userID";
	
	if(!empty($keyword)){
	
		$where = " AND ( fname LIKE '%".$keyword."%' OR lname LIKE '%".$keyword."%' OR email LIKE '%".$keyword."%' OR job_title LIKE '%".$keyword."%') AND center_id = $userID";
		
	}
	
	$getData    = $wpdb->get_results("SELECT * FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();
	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$row){
			
			$resume = 'N/A';
			
			if(!empty($row['resume'])){
				
				$resume = '<a href="javascript:void(0)" class="resumedownloadmanually" data-id="'.$row['id'].'" title="Download CV">View CV</a>';
			}
			
			$redirect    = site_url('staff-update').'/'.$row['id'];
			
			$recoards[$key] = array(
										'S.N'     => $k,
										'name'    => $row['fname'].' '.$row['lname'],
										'email'   => '<a href="mailto:'.$row['email'].'">'.$row['email'].'</a>',
										'job'     => $row['job_title'],
										'resume'  => $resume,
										'created' => date('d M, Y H:i a',strtotime($row['updated'])),
										'action'  => '<a class="staffeditinfo" href="'.$redirect.'" title="Edit Details" data-id="'.$row['id'].'"><i class="fas fa-edit"></i></a>&nbsp;<a class="deletestaff" href="javascript:void(0)" title="Remove Staff" data-id="'.$row['id'].'"><i class="fas fa-trash"></i></a>'
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response);
?>	