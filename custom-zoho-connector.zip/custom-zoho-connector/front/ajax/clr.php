<?php 

	include('../../../../../wp-load.php');

	global $wpdb,$current_user;
	
	$user = $current_user->ID;
	
	$userID = get_user_meta($user,'zoho_record_id',true);
	

	$Table       = $wpdb->prefix.'zoho_report_submission';
	
	// number of rows to show per page
	
	$offset = $_POST['start'];
	$length = $_POST['length'];
	
	$where = "AND centre_id = $userID";
	
	$getData    = $wpdb->get_results("SELECT id,eqa_name,created FROM $Table WHERE 1 $where ORDER BY id DESC LIMIT $offset,$length",ARRAY_A);
	
	//echo $wpdb->last_query;
	
	$TotalData  = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE 1 $where",ARRAY_A);
	$TotalData  = $TotalData['total'];
	
	$recoards = $test = array();

	
	if(!empty($getData)){
		
		$k = 1;
		foreach($getData as $key=>$row){
			
			$redirectUrl = site_url('view-full-report').'/'.$row['id'];
			
			$actionBtn = '<a class="viewinfoaction" href="'.$redirectUrl.'>" title="View Full Report"><i class="fa-eye fa"></i></a>';
			
			$recoards[$key] = array(
										
										'eqa_name'              => $row['eqa_name'],
										'created'    	   		=> date('M d, Y',strtotime($row['created'])),
										'action'                => $actionBtn
								   );
								
			$test[] = array_values($recoards[$key]);	

		 $k++;			
		}
	}

	$response = array('data'=>$test,'recordsTotal'=>$TotalData,'recordsFiltered'=>$TotalData);
	
	echo json_encode($response);  
	
?>