<?php 
global $wpdb;
$table = $wpdb->prefix.'custom_qualification';
$data  = $wpdb->get_results("SELECT zoho_record_id,name FROM $table ORDER BY id  ASC",ARRAY_A);
?>
<label style="margin-bottom: 15px;">Which ATHE qualifications are you looking to deliver <span class="wpforms-required-label">*</span></label>
<ul id="custom_quali" class="wpforms-field-required">
	<?php foreach($data as $listing){ ?>
	<li class="choice-428 depth-1">
		<input type="checkbox" name="wpforms[fields][cq][]" value="<?php echo $listing['zoho_record_id'];?>" required="required">
		<label class="wpforms-field-label-inline"><?php echo $listing['name'];?></label>
	</li>
	<?php } ?>
</ul>
<style>#custom_quali li{list-style:none !important;}</style>