<div class="container">
	<?php 
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	if(!in_array('applicant',$current_user->roles)){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
	}else{
		
		?>
			<form class="add_staff mt-5" id="add_staff" method="post" enctype="multipart/form-data">
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">First Name <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="fname" value="" autocomplete="off" maxlength="15"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput2">Last Name <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="lname" value="" autocomplete="off" maxlength="15"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput3">Email Address <span class="astrick">*</span></label>
							<input type="email" class="form-control" name="email" value="" autocomplete="off" maxlength="50"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput4">Job Title <span class="astrick">*</span></label>
							<input type="text" class="form-control" name="jobtitle" value="" autocomplete="off" maxlength="40"> 
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput4">Upload CV</label>
							<input type="file" class="form-control" name="cv" value="" autocomplete="off" style="border:none;"> 
							<em style="color:red;">Support format pdf, docx, doc</em><br>
							<em style="color:red;">Maximum allowed file size: 100 MB</em>
						</div>
					</div>
				</div>
				<input type="hidden" name="action" value="add_new_staff">
				<input type="submit" value="Add New" class="btn btn-primary disablebtn">
			</form>
			<div class="displayerror" style="margin-top:25px;"></div>
		<?php
	}
	?>
</div>