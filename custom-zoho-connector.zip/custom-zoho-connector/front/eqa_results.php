<div class="container">
<?php 
global $wpdb,$current_user,$wp_query;
$variables 	  = $wp_query->query_vars;
$ids          = $variables['ids'];

if(isset($variables['ids']) && empty($variables['ids'])){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
		
	}else{
		
		$wp_usermetatable = $wpdb->prefix.'usermeta';
		
		$decodeIDs    = base64_decode($ids);
		$explodeIDs   = explode("-",$decodeIDs);
		
		$centreZOHOID   = $explodeIDs[0];
		$LearnersZOHOID = $explodeIDs[1];
		
		$explodeLearnersZOHOID   = explode(",",$LearnersZOHOID);
		
		//echo '<pre>'; print_r($explodeLearnersZOHOID);
		
		$GetWPCentreID = get_user_id_by_zohoid($centreZOHOID);
		
		/* Get Learners WP IDs*/
		
		$learnersUserIDs = $wpdb->get_results("SELECT user_id FROM $wp_usermetatable WHERE `meta_key` LIKE 'zoho_record_id' AND `meta_value` IN ($LearnersZOHOID)",ARRAY_A);
?>
		<div class="table-responsivegg" style="margin-top:60px;">
			<div class="table-gfdg2">
				<table id="eqalearnersresults" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
					<thead>
					<tr>
						<th>S.N</th>
						<th>Name</th>
						<th>Email</th>
						<th>The Qualification</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php if(!empty($learnersUserIDs)){
							$i = 1;
							foreach($learnersUserIDs as $row){
								
								$info = get_userdata($row['user_id']);
								
								$qualification = get_user_meta($row['user_id'], '_learners_qualification',true);
								$quali         = get_qualification_name_by_id($qualification);
								
								?>
									<tr>
										<td><?php echo $i;?></td>
										<td><?php echo $info->data->display_name;?></td>
										<td><a class="text-link" href="mailto:<?php echo $info->data->user_emial;?>"><?php echo $info->data->user_email;?></a></td>
										<td><?php echo $quali;?></td>
										<td>
											<a class="viewresults" href="javascript:void(0)" title="View Results" data-id="<?php echo $row['user_id'];?>"><i class="fa fa-list-alt" aria-hidden="true"></i></a>
										</td>	
									</tr>
								<?php
								$i++;
							}
					} 
					?>
				</tbody>
				</table>
			</div>
	</div>
<?php 
	} 
?>
</div>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary morelearnersdetails" data-bs-toggle="modal" data-bs-target="#exampleModal" style="display:none;"></button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title morelearnersdetailsTitle" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close morelearnersdetailsPopupClose" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
      </div>
      <div class="modal-body morelearnersdetailsContent"></div>
    </div>
  </div>
</div>

<style>
.modal-backdrop.show {
    opacity: 0.5;
}
</style>

<script>
jQuery(document).ready(function () {
    jQuery('#eqalearnersresults').DataTable({
		dom: 'Bfrtip',
		buttons: [
			 'pageLength'
		],
		lengthMenu: [
					[10, 50, 100, 250, 500],
					[10, 50, 100, 250, 500],
				],
		"pageLength": 50
	});
});
</script>