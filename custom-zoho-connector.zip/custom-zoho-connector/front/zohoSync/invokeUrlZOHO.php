<?php 
require_once ZOHO_PLUGIN_PATH . 'xeroLib/vendor/autoload.php';
// Use this class to deserialize error caught
use XeroAPI\XeroPHP\AccountingObjectSerializer;

add_action('rest_api_init', function () {
	
	register_rest_route( 'atheportal/v1', 'UpdateCentreApplicationStatus/',array(
                'methods'  => 'POST',
                'callback' => 'UpdateCentreApplicationStatus_callbackv1'
    ));
	
	register_rest_route( 'atheportal/v1', 'XeroCreateContact/',array(
                'methods'  => 'POST',
                'callback' => 'XeroCreateContact_callbackv1'
    ));
	
	register_rest_route( 'atheportal/v1', 'XeroCreateInvoice/',array(
                'methods'  => 'POST',
                'callback' => 'XeroCreateInvoice_callbackv1'
    ));
	
	register_rest_route( 'atheportal/v1', 'XeroReceiveInvoiceResponse/',array(
                'methods'  => 'POST',
                'callback' => 'XeroReceiveInvoiceResponse_callbackv1'
    ));
	
	
	register_rest_route( 'atheportal/v1', 'XeroCreateLateFeesInvoice/',array(
                'methods'  => 'POST',
                'callback' => 'XeroCreateLateFeesInvoice_callbackv1'
    ));
	
	
});	

/* Update Centre Application Status From ZOHO */

function UpdateCentreApplicationStatus_callbackv1($request){
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	$recoard_id     = $decodeBody->recoard_id;
	$status         = $decodeBody->status;
	
	$userID  = get_user_id_by_zohoid($recoard_id);
	update_user_meta($userID,'Application_Status',$status);
die;	
}

/* create contact on Xero */
function XeroCreateContact_callbackv1($request){
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	$recoard_id   = $decodeBody->recoard_id;
	$name         = $decodeBody->name;
	$email        = $decodeBody->email;
	
	$address1        = $decodeBody->address1;
	$address2        = $decodeBody->address2;
	$city            = $decodeBody->city;
	$state           = $decodeBody->state;
	$country         = $decodeBody->country;
	$postalcode      = $decodeBody->postalcode;
	
	$userID  = get_user_id_by_zohoid($recoard_id);
	
	$userData = get_userdata($userID);
	
	$firstName = $userData->first_name;
	$lastName  = $userData->last_name;
	
	$active_access_token = 1;
	
	if(time() > get_option('wc_xero_access_token_expires_on')){
		
		$active_access_token = xero_refresh_token();
	}
	
	$response = array();
	
	if($active_access_token === 1){
		
		$access_token = get_option('wc_xero_access_token');
		
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token ); 

		$accountingApi = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);
		
		try {
			
				$address = new XeroAPI\XeroPHP\Models\Accounting\Address;
				
				$address->setAddressType("POBOX")
						->setAddressLine1($address1)
						->setAddressLine2($address2)
						->setCity($city)
						->setRegion($state)
						->setPostalCode($postalcode)
						->setCountry($country);
						
				$addressS = array();		

				array_push($addressS, $address);	
			
				$contact = new XeroAPI\XeroPHP\Models\Accounting\Contact;
				$contact->setName($name)
						->setFirstName($firstName)
						->setLastName($lastName)
						->setEmailAddress($email)
						->setAddresses($addressS);
				
				$arr_contacts = array();
				array_push($arr_contacts, $contact);
				$contacts = new XeroAPI\XeroPHP\Models\Accounting\Contacts;
				$contacts->setContacts($arr_contacts);

				$apiResponse = $accountingApi->createContacts($xeroTenantId,$contacts);
				
				$contactID = $apiResponse->getContacts()[0]->getContactId();
				
				$response = array('status'=>'sucess','contactID'=>$contactID);
				
			}catch (\XeroAPI\XeroPHP\ApiException $e) {
				
				$error = AccountingObjectSerializer::deserialize(
				  $e->getResponseBody(),
				  '\XeroAPI\XeroPHP\Models\Accounting\Error',
				  []
				);
				
			  $response = array('status'=>'fail','message'=>$error->getElements()[0]["validation_errors"][0]["message"]);
			
		}
	}
	
	echo json_encode($response);
	
die;	
}

/* Create invoice */
function XeroCreateInvoice_callbackv1($request){
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	$Zoho_invoice_id   = $decodeBody->invoice_recoard_id;
	$Zoho_recoard_id   = $decodeBody->recoard_id;
	$xero_contact_id   = $decodeBody->xero_contact_id;
	
	$invoice_created_date   = date('Y-m-d',strtotime($decodeBody->invoice_created_date));
	$invoice_due_date       = date('Y-m-d',strtotime($decodeBody->invoice_due_date));
	
	$invoice_amount   = $decodeBody->invoice_amount;
	$invoice_qty      = $decodeBody->invoice_qty;
	$productname      = $decodeBody->productname;
	
	$discount      = $decodeBody->discount;
	$tax           = $decodeBody->tax;
	
	$invoice_type  = $decodeBody->invoice_type;
	
	$TaxType     = $tax > 0 ? 'TAX001' : 'TAX002';
	
	$userID  = get_user_id_by_zohoid($Zoho_recoard_id);
	
	$dateValue    = new DateTime($invoice_created_date);
    $dueDateValue = new DateTime($invoice_due_date);
	
	$zoho_learner_id  			  = !empty($decodeBody->zoho_learner_id) ? $decodeBody->zoho_learner_id : '';
	$zoho_learner_addimission_id  = !empty($decodeBody->zoho_learner_addimission_id) ? $decodeBody->zoho_learner_addimission_id : '';
	
	$productCode = 'CRA';
	
	if(!empty($decodeBody->zoho_learner_id) && !empty($decodeBody->zoho_learner_addimission_id)){
		
		$productCode = 'LR';
	}
	
	$invoiceInfo = array(
							'userid'                      => $userID,
							'zoho_user_id'                => $Zoho_recoard_id,
							'zoho_learner_id'             => $zoho_learner_id,
							'zoho_learner_addimission_id' => $zoho_learner_addimission_id,
							'zoho_invoice_id'             => $Zoho_invoice_id,
							'zoho_xero_contact_id'        => $xero_contact_id,
							'zoho_product_name'           => $productname,
							'zoho_invoice_qty'            => $invoice_qty,
							'zoho_invoice_amount'         => $invoice_amount,
							'zoho_invoice_created_date'   => $invoice_created_date,
							'zoho_invoice_due_date'       => $invoice_due_date,
							'invoice_type'                => $invoice_type,
							'invoice_discount'            => $discount,
							'invoice_tax'                 => $tax
						);			
	
	$active_access_token = 1;
	
	if(time() > get_option('wc_xero_access_token_expires_on')){
		$active_access_token = xero_refresh_token();
	}
	
	$response = array();
	
	if($active_access_token === 1){
		
		$access_token = get_option('wc_xero_access_token');
		
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

		$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);
		
		
		
			$contact = new XeroAPI\XeroPHP\Models\Accounting\Contact;
			$contact->setContactID($xero_contact_id);
			
			$lineItem = new XeroAPI\XeroPHP\Models\Accounting\LineItem;
			$lineItem->setDescription($productname);
			$lineItem->setQuantity($invoice_qty);
			$lineItem->setUnitAmount($invoice_amount);
			if($discount > 0){
				$lineItem->setDiscountRate($discount);
			}
			$lineItem->setTaxType($TaxType);
			$lineItem->setItemCode($productCode);
			$lineItem->setAccountCode(200);
			
			$lineItems = [];
			array_push($lineItems, $lineItem);
			
			$invoice = new XeroAPI\XeroPHP\Models\Accounting\Invoice;
			$invoice->setType(XeroAPI\XeroPHP\Models\Accounting\Invoice::TYPE_ACCREC);
			$invoice->setContact($contact);
			$invoice->setDate($dateValue);
			$invoice->setDueDate($dueDateValue);
			$invoice->setLineItems($lineItems);
			$invoice->setReference($Zoho_invoice_id);
			$invoice->setStatus(XeroAPI\XeroPHP\Models\Accounting\Invoice::STATUS_AUTHORISED);
			
			$invoices = new XeroAPI\XeroPHP\Models\Accounting\Invoices;
			$arr_invoices = [];
			array_push($arr_invoices, $invoice);
			$invoices->setInvoices($arr_invoices);
			
			try {
				
				$result = $apiInstance->createInvoices($xeroTenantId, $invoices);
				
				$invoiceID     = $result->getInvoices()[0]->getInvoiceId();
				$invoiceNumber = $result->getInvoices()[0]->getInvoiceNumber();
				
				/* get xero online invoice url */
				
				$InvoiceUrl = get_xero_invoice_url($invoiceID);
				
				/* Created a new entry in wordpress for update payment status */
				
				$invoiceInfo['xero_invoice_no']   = $invoiceNumber;
				$invoiceInfo['xero_invoice_id']   = $invoiceID;
				$invoiceInfo['zoho_invoice_type'] = $productCode;
				$invoiceInfo['created']           = date('Y-m-d H:i:s');
				$invoiceInfo['payment_status']    = 'Pending';
				$invoiceInfo['xero_invoice_url']  = $InvoiceUrl;
				$invoiceInfo['late_fee']    	  = 0;
				
				$NewRecoard = create_invoice_recoard($invoiceInfo);
				
				/*  Email send to user for online payment */
				
				//$requestEmpty = new XeroAPI\XeroPHP\Models\Accounting\RequestEmpty;
				
				//$apiInstance->emailInvoice($xeroTenantId, $invoiceID, $requestEmpty); 
				
				$response = array('status'=>'sucess','invoiceID'=>$invoiceID,'invoiceNumber'=>$invoiceNumber,'refrenceID'=>$NewRecoard);
				
				//file_put_contents($path, print_r($response,true).PHP_EOL , FILE_APPEND | LOCK_EX);
				
			}catch (\XeroAPI\XeroPHP\ApiException $e) {
					
					$error = AccountingObjectSerializer::deserialize(
					  $e->getResponseBody(),
					  '\XeroAPI\XeroPHP\Models\Accounting\Error',
					  []
					);
					
				 $response = array('status'=>'fail','message'=>$error->getElements()[0]["validation_errors"][0]["message"]);
				 
				 //file_put_contents($path, print_r($error,true).PHP_EOL , FILE_APPEND | LOCK_EX);
				
			}
	}
	
	echo json_encode($response);
	
die;	
}

/* New Invoice Entry In WP table */
function create_invoice_recoard($data){
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	$wpdb->insert($table,$data);
	//file_put_contents($path, print_r($wpdb->last_query,true).PHP_EOL , FILE_APPEND | LOCK_EX);
	return $wpdb->insert_id;
}

/* Update Invoice Entry In WP table */
function update_invoice_payment($data){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	$wpdb->update($table,array('payment_status'=>$data['payment_status'],'xero_payment_id'=>$data['xero_payment_id']),array('zoho_invoice_id'=>$data['zoho_invoice_id']));
}

/* Get related user zoho recoard ID by Invoice In WP table */
function get_invoice_user_id($id){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	$RecoardID = $wpdb->get_row($wpdb->prepare("SELECT zoho_user_id FROM $table WHERE zoho_invoice_id = %s",$id),ARRAY_A); 
	return  $RecoardID['zoho_user_id'];
}

/* Update learners registered status after received payment */
function update_learners_registered_status_after_payment($Data){
	
	global $wpdb;
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	if($Data['late_fee'] == 0){
		
		//file_put_contents($path, print_r($Data,true).PHP_EOL , FILE_APPEND | LOCK_EX);
		
		$wpdb->update($learnerstable,array('registered_status'=>'Registered'),array('zoho_recoard_id'=>$Data['zoho_learner_id']));
		
		//file_put_contents($path, print_r($wpdb->last_query,true).PHP_EOL , FILE_APPEND | LOCK_EX);
	}
}

/* Receive response from Xero */
function XeroReceiveInvoiceResponse_callbackv1($request){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	// Get payload
	$rawPayload = $request->get_body();
	
	// ------------------------------------
	// Compute hashed signature key with our webhook key

	// Update your webhooks key here
	$webhookKey = get_option('xero_webhook_key');

	// Compute the payload with HMACSHA256 with base64 encoding
	$computedSignatureKey = base64_encode(
	  hash_hmac('sha256', $rawPayload, $webhookKey, true)
	);

	$all_headers    = $request->get_headers();
	
	$x_xero_signature = $all_headers['x_xero_signature'][0];
	
	// Signature key from Xero request
	$xeroSignatureKey = $x_xero_signature;
	
	// Response HTTP status code when:
	
	$isEqual = false;
	if (hash_equals($computedSignatureKey, $xeroSignatureKey)) {
	  $isEqual = true;
	  
	   http_response_code(200);
	  
	   $decodeBody     = json_decode($rawPayload);
	   
	   //file_put_contents($path, print_r($decodeBody,true).PHP_EOL , FILE_APPEND | LOCK_EX);
	   
	   if(!empty($decodeBody->events)){
		
			foreach($decodeBody->events as $EventData){
				
				 $resourceUrl    = $EventData->resourceUrl;
				 $resourceId     = $EventData->resourceId;
				 $eventCategory  = $EventData->eventCategory;
				 $eventType      = $EventData->eventType;
				 
				  if($eventCategory == 'INVOICE' && $eventType == 'UPDATE'){
					  
					  
						$active_access_token = 1;
			
						if(time() > get_option('wc_xero_access_token_expires_on')){
							
							$active_access_token = xero_refresh_token();
						}
						
						if($active_access_token === 1){
							
							$access_token = get_option('wc_xero_access_token');
							$xeroTenantId = get_option('wc_xero_TenantID');
							
							 $response = wp_remote_request( $resourceUrl, array(
										'method' => 'GET',
											'headers' => array(
												'Authorization'  => 'Bearer ' . $access_token,
												'Xero-Tenant-Id' => $xeroTenantId,
												'Accept'         => 'application/json',
												'Content-Type'   => 'application/json',
											)
								));
								
								if( !is_wp_error( $response ) ){
									
									$results = json_decode($response['body'], true);
									
									foreach($results['Invoices'] as $information){
										
									
										$paymentstatus = $information['Status'];
										$Reference     = $information['Reference'];
										$InvoiceNumver = $information['InvoiceNumber'];
										$InvoiceID     = $information['InvoiceID'];
										
										if($paymentstatus == 'PAID'){
											
											 $paymentID = $information['Payments'][0]['PaymentID'];
											 
											  /* update information in wp table */
											  
											  $AlreadyUpdateData = $wpdb->get_row($wpdb->prepare("SELECT zoho_learner_id,attachment,zoho_learner_addimission_id,late_fee,zoho_invoice_type FROM $table WHERE zoho_invoice_id = %s",$Reference),ARRAY_A);
											  
											  if(empty($AlreadyUpdateData['attachment'])){
									 
												 $UpdateData = array('zoho_invoice_id'=>$Reference,'payment_status'=>$paymentstatus,'xero_payment_id'=>$paymentID,'InvoiceNumver'=>$InvoiceNumver,'InvoiceID'=>$InvoiceID,'zoho_learner_id'=>$AlreadyUpdateData['zoho_learner_id'],'zoho_learner_addimission_id'=>$AlreadyUpdateData['zoho_learner_addimission_id'],'late_fee'=>$AlreadyUpdateData['late_fee'],'zoho_invoice_type'=>$AlreadyUpdateData['zoho_invoice_type']);
												 
												  update_invoice_payment($UpdateData); 
												  update_payment_information_in_zoho_invoce($UpdateData);
												  
												  update_learners_registered_status_after_payment($UpdateData); 
											  
											  }
										}
									}
								}
							
							
						}
					  
				  }
			}
		}
 
	} else {
	  http_response_code(401);
	}
die;
}

/* Create late fee invoice at Xero */
function XeroCreateLateFeesInvoice_callbackv1($request){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	//file_put_contents($path, print_r($request,true).PHP_EOL , FILE_APPEND | LOCK_EX);
	
	$body           = $request->get_body();
	$decodeBody     = json_decode($body);
	
	$Zoho_invoice_id   = $decodeBody->invoice_recoard_id;
	$Zoho_recoard_id   = $decodeBody->recoard_id;
	$xero_contact_id   = $decodeBody->xero_contact_id;
	
	$invoice_created_date   = date('Y-m-d',strtotime($decodeBody->invoice_created_date));
	$invoice_due_date       = date('Y-m-d',strtotime($decodeBody->invoice_due_date));
	
	$invoice_amount   = $decodeBody->invoice_amount;
	$invoice_qty      = $decodeBody->invoice_qty;
	$productname      = $decodeBody->productname;
	
	$invoice_amountXero  = $invoice_amount / $invoice_qty;
	
	$discount      = $decodeBody->discount;
	$tax           = $decodeBody->tax;
	
	$invoice_type  = $decodeBody->invoice_type;
	
	$TaxType     = $tax > 0 ? 'TAX001' : 'TAX002';
	
	$userID  = get_user_id_by_zohoid($Zoho_recoard_id);
	
	$dateValue    = new DateTime($invoice_created_date);
    $dueDateValue = new DateTime($invoice_due_date);
	
	$zoho_learner_id  			  = !empty($decodeBody->zoho_learner_id) ? $decodeBody->zoho_learner_id : '';
	$zoho_learner_addimission_id  = !empty($decodeBody->zoho_learner_addimission_id) ? $decodeBody->zoho_learner_addimission_id : '';
	
	$invoiceInfo = array(
							'userid'                      => $userID,
							'zoho_user_id'                => $Zoho_recoard_id,
							'zoho_learner_id'             => $zoho_learner_id,
							'zoho_learner_addimission_id' => $zoho_learner_addimission_id,
							'zoho_invoice_id'             => $Zoho_invoice_id,
							'zoho_xero_contact_id'        => $xero_contact_id,
							'zoho_product_name'           => $productname,
							'zoho_invoice_qty'            => $invoice_qty,
							'zoho_invoice_amount'         => $invoice_amount,
							'zoho_invoice_created_date'   => $invoice_created_date,
							'zoho_invoice_due_date'       => $invoice_due_date,
							'invoice_type'                => $invoice_type,
							'invoice_discount'            => $discount,
							'invoice_tax'                 => $tax
						);	
						
						$active_access_token = 1;
	
	if(time() > get_option('wc_xero_access_token_expires_on')){
		$active_access_token = xero_refresh_token();
	}
	
	$response = array();
	
	if($active_access_token === 1){
		
		$access_token = get_option('wc_xero_access_token');
		
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

		$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);
		
		
		
			$contact = new XeroAPI\XeroPHP\Models\Accounting\Contact;
			$contact->setContactID($xero_contact_id);
			
			$lineItem = new XeroAPI\XeroPHP\Models\Accounting\LineItem;
			$lineItem->setDescription($productname);
			$lineItem->setQuantity($invoice_qty);
			$lineItem->setUnitAmount($invoice_amountXero);
			if($discount > 0){
				$lineItem->setDiscountRate($discount);
			}
			$lineItem->setTaxType($TaxType);
			$lineItem->setItemCode('CRA');
			$lineItem->setAccountCode(200);
			
			$lineItems = [];
			array_push($lineItems, $lineItem);
			
			$invoice = new XeroAPI\XeroPHP\Models\Accounting\Invoice;
			$invoice->setType(XeroAPI\XeroPHP\Models\Accounting\Invoice::TYPE_ACCREC);
			$invoice->setContact($contact);
			$invoice->setDate($dateValue);
			$invoice->setDueDate($dueDateValue);
			$invoice->setLineItems($lineItems);
			$invoice->setReference($Zoho_invoice_id);
			$invoice->setStatus(XeroAPI\XeroPHP\Models\Accounting\Invoice::STATUS_AUTHORISED);
			
			$invoices = new XeroAPI\XeroPHP\Models\Accounting\Invoices;
			$arr_invoices = [];
			array_push($arr_invoices, $invoice);
			$invoices->setInvoices($arr_invoices);
			
			try {
				
				$result = $apiInstance->createInvoices($xeroTenantId, $invoices);
				
				$invoiceID     = $result->getInvoices()[0]->getInvoiceId();
				$invoiceNumber = $result->getInvoices()[0]->getInvoiceNumber();
				
				/* Created a new entry in wordpress for update payment status */
				
				$invoiceInfo['xero_invoice_no']   = $invoiceNumber;
				$invoiceInfo['xero_invoice_id']   = $invoiceID;
				$invoiceInfo['zoho_invoice_type'] = 'CAI';
				$invoiceInfo['created']           = date('Y-m-d H:i:s');
				$invoiceInfo['payment_status']    = 'Pending';
				$invoiceInfo['late_fee']    	  = 1;
				
				$NewRecoard = create_invoice_recoard($invoiceInfo);
				
				/*  Email send to user for online payment */
				
				$requestEmpty = new XeroAPI\XeroPHP\Models\Accounting\RequestEmpty;
				
				$apiInstance->emailInvoice($xeroTenantId, $invoiceID, $requestEmpty);
				
				$response = array('status'=>'sucess','invoiceID'=>$invoiceID,'invoiceNumber'=>$invoiceNumber,'refrenceID'=>$NewRecoard);
				
			}catch (\XeroAPI\XeroPHP\ApiException $e) {
					
					$error = AccountingObjectSerializer::deserialize(
					  $e->getResponseBody(),
					  '\XeroAPI\XeroPHP\Models\Accounting\Error',
					  []
					);
					
				 $response = array('status'=>'fail','message'=>$error->getElements()[0]["validation_errors"][0]["message"]);
				
			}
	}
	
	echo json_encode($response);

die;
}
?>