<?php 
if(!is_user_logged_in()){
	wp_redirect(site_url('log-in'));
	exit;
}
?>

<div class="container panellearners centredashbordpanel">
	<div class="vertical-tab" role="tabpanel">
		<div class="row">
			<div class="col-lg-3 col-md-4">
				<div class="centredashbordpanel_Tabs">
					<!-- Nav tabs -->
					<?php include ZOHO_PLUGIN_PATH.'front/partials/nav.php';?>
				</div>
			</div>
			<div class="col-lg-9 col-md-8">
				<div class="centredashbordpanel_Tabs_Data h-100">
					<!-- Tab panes -->
					<div class="tab-content tabs h-100">
						<?php include ZOHO_PLUGIN_PATH.'front/partials/actionpoints.php';?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary morelearnersdetails" data-bs-toggle="modal" data-bs-target="#exampleModal" data-backdrop="static" data-keyboard="false"style="display:none;"></button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title morelearnersdetailsTitle" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close morelearnersdetailsPopupClose" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
      </div>
      <div class="modal-body morelearnersdetailsContent"></div>
    </div>
  </div>
</div>

<style>
.modal-backdrop.show {
    opacity: 0.5;
}
</style>