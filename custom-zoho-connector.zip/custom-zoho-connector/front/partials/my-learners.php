<?php 
global $wpdb,$current_user;
$userID   = $current_user->ID;
$resultsTable = $wpdb->prefix.'learners_results';
$initialUsers = get_respective_centre_learners_tenusers();
$totalLearners = get_respective_centre_learners();

$table = $wpdb->prefix.'center_register_qualification';
$table2 = $wpdb->prefix.'custom_qualification';

$where = "AND center_id = $userID";

$data = array();
if(in_array('applicant',$current_user->roles)){
	
	$userID   = $current_user->ID;
	
	$query = "SELECT t1.qualification_id as zoho_record_id,t2.name as name FROM $table as t1 Left JOIN $table2 as t2 ON t1.qualification_id = t2.zoho_record_id WHERE 1 $where ORDER BY t1.id DESC";
	
	$data  = $wpdb->get_results($query,ARRAY_A);
}
?>
<div class="panellearners">
	<div class="qualifilter mt-4">				
		<h6>Filter BY Qualification</h6>	
		<div class="row">
			<div class="col-md-12">
				<div class="form-group searchBarSelect">
					<select class="filter_Qualification commanselect2">								
						<option value="">Select Qualification</option>								
						<?php if(!empty($data)){foreach($data as $listing){ ?>
						<option value="<?php echo $listing['zoho_record_id'];?>"><?php echo $listing['name'];?></option>
						<?php }} ?>						
					</select>	
				</div>
				<div class="form-group">
					<div class="filter_n_clear_filter d-flex flex-wrap align-items-center justify-content-between">
						<a href="javascript:void(0);" class="clearQualificationfilter" style="text-decoration:underline !important;">Clear filter</a>
						<input type="button" id="Qualification_btn_filter" value="Filter" class="btn btn-primary">
					</div>
				</div>
			</div>
		</div>			
	</div>
	<div class="filterbydaterange mt-4">
		<h6>Filter B/W Start And End Date</h6>
		<div class="row">
			<div class="col-md-6">
				<div class="form-group">
					<input type="text" readonly id="search_start" class="learnersstartDate w-100" placeholder="Start date" />
				</div>
			</div>
			<div class="col-md-6">
				<div class="form-group">
					<input type="text" readonly id="search_end" class="learnersendDate w-100" placeholder="End date" />
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<div class="filter_n_clear_filter d-flex flex-wrap align-items-center justify-content-between">
						<a href="javascript:void(0);" class="cleardatefilter" style="text-decoration:underline !important;">Clear filter</a>
						<input type="button" id="btn_search" value="Filter" class="btn btn-primary">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="actionButton">
		<ul class="list-unstyled m-0 p-0 d-flex flex-wrap mt-4">
			<li>
				<a href="<?php echo site_url()?>/register-learners" class="btn btn-primary add_learners">Add New Learners</a>
			</li>	
		<?php 
			if($totalLearners > 0){
				?>
					<li>
						<a href="<?php echo site_url()?>/add-qualification/" class="btn btn-primary add_learners add_qualification">Additional Learners Qualification</a>
					</li>
					<li>
						<a href="<?php echo site_url()?>/submit-results/" class="btn btn-primary add_learners">Submit Results</a>
					</li>
				<?php
			}else{
				?>
					<li>
						<a href="javascript:void(0)" class="btn btn-primary add_learners" disabled>Submit Results</a>
					</li>
				<?php
			}
		?>
		
		<li>
				<a href="<?php echo site_url()?>/import-learners" class="btn btn-primary add_learners">Import Learners</a>
		</li>
		
		</ul>
	</div>
	<div class="mt-4">
		<div class="table-gfdg2 data-table-responsive">
			<table id="dashboardlearners" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;">
				<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Email</th>
					<th>The Qualification</th>
					<th>Status</th>
					<th>Qualification</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				
					if(!empty($initialUsers)){
						$i = 1;
						foreach($initialUsers as $info){
							$redirect    = site_url('learner-update').'/'.$info['ID'];
							
							$classpaymentstatus = $info['status'] == 'Pending' ? 'badge-secondary p-1' : 'badge-success p-1';
							
							$QA  = $info['is_completed'] == 1 ? 'Completed' : 'Pending';
							$QAC = $info['is_completed'] == 1 ? 'badge-secondary p-1' : 'badge-warning p-1';
							
							$certificateLogo = "";
							
							if($info['is_completed'] == 1){
								
								if($info['overall_grade'] == 'Pass'){
									
									$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-p.png">';
									
								}elseif($info['overall_grade'] == 'Merit'){
									
									$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-m.png">';
									
								}elseif($info['overall_grade'] == 'Distinction'){
									
									$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-d.png">';
								}else{
									
									$certificateLogo = '<img src="'.ZOHO_PLUGIN_URL.'assets/images/badge-f.png">';
								}
							}
							
							?>
								<tr>
									<td><?php echo '#'.$info['LID'];?></td>
									<td><?php echo $certificateLogo;?><?php echo $info['name'];?></td>
									<td><a class="text-link" href="mailto:<?php echo $info['email'];?>"><?php echo $info['email'];?></a></td>
									<td><?php echo $info['qualification'];?></td>
									<td><span class="pstatus <?php echo $classpaymentstatus;?>"><?php echo $info['status'];?></span></td>
									<td><span class="qstatus <?php echo $QAC;?>"><?php echo $QA;?></span></td>
									<td>
										<a class="viewinfo" href="javascript:void(0)" title="View Details" data-user="<?php echo $info['LID'];?>" data-id="<?php echo $info['ID'];?>"><i class="fa-eye fa"></i></a>&nbsp;
										
										<?php 
										if($info['is_completed'] != 1)
										{
										?>
											<a class="editinfo" href="<?php echo $redirect;?>" title="Edit Details" data-id="<?php echo $info['ID'];?>"><i class="fas fa-edit"></i></a>&nbsp;
										<?php } ?>
										
										<a class="viewresults" href="javascript:void(0)" title="View Results" data-id="<?php echo $info['ID'];?>"><i class="fa fa-list-alt" aria-hidden="true"></i></a>&nbsp;
									</td>
								</tr>
							<?php
							$i++;
						}
					}
				?>
			</tbody>
			</table>
		</div>
	</div>
</div>