<?php $center_learnersreport = get_center_learnersreport();
?>
<div class="container panelactionspoints">

	<div class="table-responsivegg mt-4">
		<div class="table-gfdg2">
			<table id="dashboardclr" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
				<thead>
				<tr>
					<th>Report Submit By</th>
					<th>Create Time</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				
					if(!empty($center_learnersreport)){
						
						foreach($center_learnersreport as $row){
							
							$redirectUrl = site_url('view-full-report').'/'.$row['id'];
							
							?>
								<tr>
									<td><?php echo $row['eqa_name'];?></td>
									
									<td><?php echo date('M d, Y',strtotime($row['created']));?></td>
									<td>
										<a class="viewinfoaction" href="<?php echo $redirectUrl;?>" title="View Full Report"><i class="fa-eye fa"></i></a>&nbsp;
										
										
									</td>
									
								</tr>
							<?php
						}
					}
				?>
			</tbody>
			</table>
		</div>
	</div>
</div>