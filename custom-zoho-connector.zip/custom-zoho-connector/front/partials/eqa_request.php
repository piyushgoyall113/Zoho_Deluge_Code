<?php 
$data = get_respective_eqa_request();
//echo '<pre>'; print_r($data);
?>
<div class="qualifilter mt-4">				
		<h6>Filter BY Status</h6>	
		<div class="row">
			<div class="col-md-12">
				<div class="form-group searchBarSelect">
					<select class="filter_status commanselect2">								
						<option value="">Select Status</option>								
						<option value="New">New</option>
						<option value="Accepted">Accepted</option>
						<option value="Rejected">Rejected</option>	
						<option value="No response">No response</option>
					</select>	
				</div>
				<div class="form-group">
					<div class="filter_n_clear_filter d-flex flex-wrap align-items-center justify-content-between">
						<a href="javascript:void(0);" class="clearstatusfilter" style="text-decoration:underline !important;">Clear filter</a>
						<input type="button" id="status_btn_filter" value="Filter" class="btn btn-primary">
					</div>
				</div>
			</div>
		</div>			
	</div>
<div class="table-responsivegg" style="margin-top:60px;">
	<div class="displayerrorinner" style="margin-top:25px;"></div>
	<div class="table-gfdg2">
		<table id="dashboardEQANewRequest" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
			<thead>
			<tr>
				<th>Request No</th>
				<th>Total Learners</th>
				<th>Contact Name</th>
				<th>Contact Email</th>
				<th>Status</th>
				<th>Resuls Submit Date</th>
				<th>Date</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				if(!empty($data)){
					$i = 1;
					foreach($data as $row){
						
						$style = '';
						
						if($row['status'] == 'New'){
							$style = 'style="color:#fff;background-color: #138496;padding: 5px;"';
						}elseif($row['status'] == 'Accepted'){
							$style = 'style="color:#fff;background-color: #28a745;padding: 5px;"';
						}elseif($row['status'] == 'Rejected'){
							$style = 'style="color:#fff;background-color: #dc3545;padding: 5px;"';
						}elseif($row['status'] == 'No response'){
							$style = 'style="color:#fff;background-color: #ffc107;padding: 5px;"';
						}
						
						if(!empty($row['result_completed_date'])){
							
							$changesubmitDate = date('M d, Y',strtotime(str_replace('/', '-', $row['result_completed_date'])));
						}else{
						
							$changesubmitDate = '';
						}
						
						
						
						$UrlDate = date('d-M-Y',strtotime(str_replace('/', '-', $row['result_completed_date'])));
						
						$EQAData = get_userdata($row['EQAWPID']);
						
						$name = explode(" ",$EQAData->first_name);
						
						$zohoFormUrl = "https://forms.zohopublic.com/atheltd/form/LearnerModerationReport/formperma/1ZQgpQwKpoNeAL_XtBqKPHkODUqqaPbI1QrvO4ilFj0?centrename=".$row['centre_name']."&centerid=".$row['zoho_centre_id']."&eqaid=".$row['zoho_eqaprofile_id']."&requestid=".$row['zoho_request_id']."&fname=".$name[0]."&lname=".$name[1]."&email=".$EQAData->user_email."&date=".$UrlDate;
						
						$redirectUrl = site_url('submit-learners-report').'/'.$row['ID'];
						
						?>
							<tr>
								<td><?php echo $row['zoho_request_no'];?></td>
								<td><?php echo $row['learners'];?></td>
								<td><?php echo $row['centre_name'];?></td>
								<td><a href="mailto:<?php echo $row['centre_email'];?>"><?php echo $row['centre_email'];?></a></td>
								<td><span <?php echo $style;?>><?php echo $row['status'];?></span></td>
								<td><?php echo $changesubmitDate;?></a></td>
								<td><?php echo $row['registered'];?></a></td>
								<td>
									<?php 
										if($row['status'] == 'New'){
									?>
									<button type="button" class="btn btn-success requestAccept" style="padding: 4px;" data-id="<?php echo $row['zoho_request_id'];?>">Accept</button>&nbsp;&nbsp;
									<button type="button" class="btn btn-danger requestReject" style="padding: 4px;" data-id="<?php echo $row['zoho_request_id'];?>">Reject</button>
									
									<?php }elseif($row['status'] == 'Accepted'){
										?>
											<a class="eqaviewresults" href="javascript:void(0)" title="View learners" data-id="<?php echo $row['ID'];?>" data-rid="<?php echo $row['result_report_id'];?>"><i class="fa-eye fa" aria-hidden="true"></i></a>	
											
											
											<?php
												
												if(empty($row['result_report_id'])){
											
											?>
											
											<a class="eqaviewresultsreport" href="<?php echo $zohoFormUrl;?>" target="_blank" title="Submit Report"><i class="fa fa-list-alt" aria-hidden="true"></i></a>
											
									<?php 		}else{
													
													echo '&nbsp;<a class="reportsubmitted" href="javascript:void(0)"  title="Report Submitted"><i class="fa fa-ban" aria-hidden="true"></i></a>&nbsp; <a class="" href="'.$redirectUrl.'" title="Submit Learners Report">Submit Learners Report</a>';
													
												}
									}?>
								</td>
							</tr>
						<?php
						$i++;	
					}
				}
			?>
		</tbody>
		</table>
	</div>
</div>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary morelearnersdetails" data-bs-toggle="modal" data-bs-target="#exampleModal" style="display:none;" data-backdrop="static" data-keyboard="false"></button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title morelearnersdetailsTitle" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close morelearnersdetailsPopupClose" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
      </div>
      <div class="modal-body morelearnersdetailsContent"></div>
    </div>
  </div>
</div>


<!-- Button trigger modal -->
<button type="button" class="btn btn-primary eqaacesslearnersresults" data-bs-toggle="modal" data-bs-target="#eqalr" style="display:none;" data-backdrop="static" data-keyboard="false"></button>

<!-- Modal -->
<div class="modal fade" id="eqalr" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title eqaacesslearnersresultsTitle" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close eqaacesslearnersresultsPopupClose" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
      </div>
      <div class="modal-body eqaacesslearnersresultsContent"></div>
    </div>
  </div>
</div>

<style>
.modal-backdrop.show {
    opacity: 0.5;
}
</style>