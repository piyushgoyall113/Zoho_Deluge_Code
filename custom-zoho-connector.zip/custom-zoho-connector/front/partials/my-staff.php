<?php $center_staff = center_staff();?>
<div class="container panelstaff">
	<div class="actionButton">
		<ul class="list-unstyled m-0 p-0 d-flex flex-wrap mt-4">
			<li>
				<a href="<?php echo site_url()?>/add-new-staff" class="btn btn-primary add_learners">Add New Staff</a>
			</li>
		</ul>
	</div>

	<div class="table-responsivegg mt-4">
		<div class="table-gfdg2">
			<table id="dashboardcenterstaff" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
				<thead>
				<tr>
					<th>S.N</th>
					<th>Name</th>
					<th>Email</th>
					<th>Job Title</th>
					<th>CV</th>
					<th>Updated Time</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					if(!empty($center_staff)){
						$i = 1;
						foreach($center_staff as $row){
							
							$redirect    = site_url('staff-update').'/'.$row['id'];
							
							?>
								<tr>
									<td><?php echo $i;?></td>
									<td><?php echo $row['fname'].' '.$row['lname'];?></td>
									<td><a href="mailto:<?php echo $row['email'];?>"><?php echo $row['email'];?></a></td>
									<td><?php echo $row['job_title'];?></td>
									<td>
										<?php if(!empty($row['resume'])){
												echo '<a href="javascript:void(0)" class="resumedownloadmanually" data-id="'.$row['id'].'" title="Download CV">View CV</a>';
										}else{
											echo 'N/A';
										}?>
									</td>
									<td><?php echo date('d M, Y H:i a',strtotime($row['updated']));?></td>
									<td>
									
										<a class="staffeditinfo" href="<?php echo $redirect;?>" title="Edit Details" data-id="<?php echo $row['id'];?>"><i class="fas fa-edit"></i></a>&nbsp;
										 <a class="deletestaff" href="javascript:void(0)" title="Remove Staff" data-id="<?php echo $row['id'];?>">
										 <i class="fas fa-trash"></i></a>
									</td>
									
								</tr>
							<?php
							$i++;	
						}
					}
				?>
			</tbody>
			</table>
		</div>
	</div>
</div>