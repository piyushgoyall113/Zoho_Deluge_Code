<?php $center_actionspoints = get_respective_cap();
?>
<div class="container panelactionspoints">

	<div class="qualifilter mt-4">				
		<h6>Filter BY Status</h6>	
		<div class="row">
			<div class="col-md-12">
				<div class="form-group searchBarSelect">
					<select class="filter_apstatus commanselect2">								
						<option value="">Select Status</option>								
						<option value="Pending">Pending</option>
						<option value="Addressed">Addressed</option>
					</select>	
				</div>
				<div class="form-group">
					<div class="filter_n_clear_filter d-flex flex-wrap align-items-center justify-content-between">
						<a href="javascript:void(0);" class="clearapstatusfilter" style="text-decoration:underline !important;">Clear filter</a>
						<input type="button" id="apstatus_btn_filter" value="Filter" class="btn btn-primary">
					</div>
				</div>
			</div>
		</div>			
	</div>

	<div class="table-responsivegg mt-4">
		<div class="table-gfdg2">
			<table id="dashboardcenteractionpoints" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
				<thead>
				<tr>
					<th>Responsibility</th>
					<th>Priority</th>
					<th>Deadline</th>
					<th>Status</th>
					<th>Prior to submitting further results</th>
					<th>Evidence</th>
					<th>Create Time</th>
					<th>Update Time</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				
					$currentTime = strtotime(date('Y-m-d'));
				
					if(!empty($center_actionspoints)){
						
						foreach($center_actionspoints as $row){
							
							$status = '<span class="pstatus badge-warning p-1" style="color:#fff;">'.$row['status'].'</span>';
							
							if($row['status'] != 'Pending'){
								
								$status = '<span class="pstatus badge-success p-1" style="color:#fff;">'.$row['status'].'</span>';
							}
							
							$Deadlinetime = strtotime($row['deadline']);
							
							//$highlight = $currentTime > $Deadlinetime ? '<span class="highlightdeadline"><img src="'.ZOHO_PLUGIN_URL.'assets/images/overdue.png"></span>' : '';
							
							if($row['status'] == 'Pending'){
								
								$highlightStyle = $currentTime > $Deadlinetime ? 'pstatus badge-danger p-1' : '';
								
								$highlight = $currentTime > $Deadlinetime ? '<span class="highlightdeadline"><img src="'.ZOHO_PLUGIN_URL.'assets/images/overdue.png"></span>' : '';
							}
							?>
								<tr>
									<td><?php echo $row['responsibility'];?></td>
									<td><?php echo $row['priority'];?></td>
									<td><?php echo '<span class="'.$highlightStyle.'">'.date('M d, Y',strtotime($row['deadline'])).'</span>'.$highlight;?></td>
									<td><?php echo $status;?></td>
									<td><?php if($row['prior_to_submitting_further_results'] == 1){ echo "True";}else{ echo "false";}?></td>
									<td><?php 
											
											if(!empty($row['evidence'])){
												
												echo '<a class="downloadevidence" href="javascript:void(0)" title="Download Evidence"  data-id="'.$row['id'].'?>"><i class="fa fa-download" aria-hidden="true"></i></a>';
											}else{
												
												echo 'N/A';
											}
										?></td>
									<td><?php echo date('M d, Y',strtotime($row['created']));?></td>
									<td><?php echo date('M d, Y',strtotime($row['updated']));?></td>
									<td>
										<a class="viewinfoaction" href="javascript:void(0)" title="View Action Content"  data-id="<?php echo $row['id'];?>"><i class="fa-eye fa"></i></a>&nbsp;
										
										<?php if($row['responsibility'] == 'Centre' && empty($row['evidence'])){?>
										
											<a class="uploadEvidence" href="javascript:void(0)" title="Upload Evidence ( only one time)"  data-id="<?php echo $row['id'];?>"><i class="fa fa-upload" aria-hidden="true"></i></a>
										
										<?php 
										} ?>
									</td>
									
								</tr>
							<?php
						}
					}
				?>
			</tbody>
			</table>
		</div>
	</div>
</div>