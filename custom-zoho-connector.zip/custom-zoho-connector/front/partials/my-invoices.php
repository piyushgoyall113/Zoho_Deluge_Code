<?php 
$invoices = get_initial_respective_centre_invoices();
//echo '<pre>'; print_r($invoices);
$currency = get_option('xero_currency');
?>
<div class="table-responsivegg" style="margin-top:60px;">
	<div class="table-gfdg2">
		<table id="dashboardcenterinvoices" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
			<thead>
			<tr>
				<th>Invoice ID</th>
				<th>Invoice Name</th>
				<th>Start Date</th>
				<th>Due Date</th>
				<th>Overdue by</th>
				<th>Type</th>
				<th>Amount</th>
				<th>Status</th>
				<th>Action</th>
				<th>Payment</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				if(!empty($invoices)){
					$i = 1;
					foreach($invoices as $invoice){
						
						$discount = $invoice['discount'];
						$tax      = $invoice['tax'];
						
						$calDiscount = $invoice['amount'] * $discount / 100;
						$total       = $invoice['amount'] - $calDiscount;
						$calTax      = $total * $tax / 100;
						$grandTotal  = $total +  $calTax;
						
						$classpaymentstatus = $invoice['status'] == 'PAID' ? 'badge-success p-1' : 'badge-secondary p-1';
						
						
						$date1 = new DateTime($invoice['duedate']);
						$date2 = new DateTime(date('Y-m-d'));
						$interval = $date1->diff($date2);
						
						$statusOverDue = '';
						
						if($invoice['status'] != 'PAID'){
							
							if( strtotime(date('Y-m-d')) > strtotime($invoice['duedate']) )
							{
							
								if($interval->days > 0)
								{
									$statusOverDue = '<span style="color:red;">'.$interval->days.' days</span>';
								}
							}
						}
						?>
							<tr>
								<td><?php echo $invoice['invoiceNumber'];?></td>
								<td><?php echo $invoice['invoicename'];?></td>
								<td><?php echo $invoice['date'];?></td>
								<td><?php echo $invoice['duedate'];?></a></td>
								<td><?php echo $statusOverDue;?></a></td>
								<td><?php echo $invoice['type'];?></td>
								<td><?php echo $currency.' '.number_format($grandTotal,2);?></td>
								<td><span class="pstatus <?php echo $classpaymentstatus;?>"><?php echo $invoice['status'];?></span></td>
								<td>
									<a class="invoiceinfo" href="javascript:void(0)" title="View Invoice Details" data-id="<?php echo $invoice['ID'];?>">
									<i class="fa-eye fa"></i></a>&nbsp;
									<?php if(!empty($invoice['attachment'])){
											echo '<a href="javascript:void(0)" class="invoicedownloadmanually" data-id="'.$invoice['ID'].'" title="Download Invoice"><i class="fa fa-file-pdf-o"></i></a>';
									}?>
								</td>
								<td>
									<?php 
										if($invoice['status'] != 'PAID' && !empty($invoice['payurl'])){
											
											echo '<a href="'.$invoice['payurl'].'" target="_blank" class="btn btn-info" style="text-decoration:none;padding: 2px;">Pay Invoice</a>';
											
										}
									?>
								</td>
							</tr>
						<?php
						$i++;	
					}
				}
			?>
		</tbody>
		</table>
	</div>
</div>