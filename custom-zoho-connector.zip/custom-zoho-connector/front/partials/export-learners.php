<div class="downloadexportlearnerscsv">
	<ul>
		<li><i class="fas fa-arrow-alt-circle-right"></i><a href="javascript:void(0);" class="dlscsv">Download sample Learners CSV</a></li>
		<li><i class="fas fa-arrow-alt-circle-right"></i><a href="javascript:void(0);" class="qualificationlist">View Qualification List</a></li>
		<li><i class="fas fa-arrow-alt-circle-right"></i><a href="javascript:void(0);" class="fundinglist">View Funding List</a></li>
		<li><i class="fas fa-arrow-alt-circle-right"></i><a href="javascript:void(0);" class="ethnicitylist">View Ethnicity list</a></li>
	</ul>
	
	
	<div class="displayrelationContent"></div>
	
	<form id="export_learners" class="export_learners" method="post">
		
		<label for="images" class="drop-container">
		  <span class="drop-title">Drop files here</span>
		  or
		  <input type="file" id="images" name="exportlearners">
		</label>
		
		<div class="supportCSV">
			<em>The system only supports CSV files.</em><br/>
			<em>The system only supports date format like Y-m-d.</em>
		</div>
		
		
		<input type="hidden" name="action" value="export_learners_csv">
		<?php wp_nonce_field( 'fel', 'inzoho' ); ?>
		<input type="submit" value="Upload" class="btn btn-primary disablebtn">
		
		
	
	</form>
	
	<div class="displayerror" style="margin-top:25px;"></div>
	
</div>