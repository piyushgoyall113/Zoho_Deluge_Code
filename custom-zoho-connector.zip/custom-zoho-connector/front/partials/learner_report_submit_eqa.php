<div class="container">
<?php 
	global $wpdb,$current_user,$wp_query;
	$variables 	  = $wp_query->query_vars;
	$ViewID 	  = $variables['reportID'];
	if(!in_array('eqa',$current_user->roles)){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
	}elseif(isset($variables['reportID']) && empty($variables['reportID'])){
		
		echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
		
	}else{
		
		$Table       = $wpdb->prefix.'zoho_eqa_results_request';
		$getInfo     = $wpdb->get_row($wpdb->prepare("SELECT zoho_request_no,id,result_report_id FROM $Table WHERE id =%d",$ViewID),ARRAY_A);
		
		if(empty($getInfo)){
			
			echo '<div class="row">
					<p class="mt-3">You are not authorized access this page.</p>
				</div>';
		}else{
			
			?>
			
			<div class="row">
			
				<div class="col-md-4"><b>Request NO :</b> <span class="value badge p-2 badge-success"><?php echo $getInfo['zoho_request_no']; ?></span></div>
				
			
			</div>
			
			<div class="actionButton">
				<ul class="list-unstyled m-0 p-0 d-flex flex-wrap mt-4">
					<li>
						<a href="javascript:void(0)" class="btn btn-primary add_entry actionbtn" data-id="<?php echo $getInfo['id'];?>">Add Entry</a>
					</li>	
				</ul>
			</div>
			
			<?php
			
			$Table2       = $wpdb->prefix.'zoho_report_submission_eqa_learners';
			
			$getInfolearners     = $wpdb->get_results($wpdb->prepare("SELECT * FROM $Table2 WHERE zoho_report_submission_id =%s ORDER BY id ASC",$getInfo['result_report_id']),ARRAY_A);
			
			if(!empty($getInfolearners)){
				
				?>
				
				<div class="row mt-3">
					<div class="col-md-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">
							<input type="checkbox" name="selectAll" id="select_all">&nbsp;&nbsp;Select All</label>
							<a href="javascript:void(0)" class="btn btn-primary submitlreport actionbtn">Submit Report</a>
						</div>
					</div>
				</div>
				
				<?php
				
				echo '<div class="row mt-3">';
				
				foreach($getInfolearners as $data){
					
					$rpl = $data['RPL'] > 0 ? 'True' : 'False';
					
					$quali = get_qualification_name_by_id($data['qualification_id']);
					
					$username = get_learner_name_by_zohoid($data['learner_id']);
					
					?>
					
						<div class="col-md-12 rowfadout-<?php echo $data['id'];?>">
							<div class="card bg-light mb-3 customcard">
							
								<?php if($data['is_sent'] != 1){?>
							
									<input type="checkbox" name="checkboxList" class="checkboxList" value="<?php echo $data['id'];?>" />
							
								<?php } ?>
							
							  <div class="card-body">
								<div class="row">
									<div class="col-md-5"><label for="exampleFormControlInput1">Is RPL being used against this learner</label></div>
									<div class="col-md-7"><label class="learnersvalue"><?php echo $rpl;?></label></div>
								  </div>
								<div class="row">
									<div class="col-md-5"><label for="exampleFormControlInput1">Qualification</label></div>
									<div class="col-md-7"><label class="learnersvalue"><?php echo $quali;?></label></div>
								</div>
								<div class="row">
									<div class="col-md-5"><label for="exampleFormControlInput1">Learner Name</label></div>
									<div class="col-md-7"><label class="learnersvalue"><?php echo $username;?></label></div>
								</div>
								
								<?php if($data['is_sent'] != 1){?>
								
									<div class="overlapebtn">
										
										<a href="javascript:void(0)" class="editreportl" data-id="<?php echo $data['id'];?>" data-request="<?php echo $getInfo['id'];?>"><i class="fas fa-edit"></i></a>
										<a href="javascript:void(0)" class="editreportd" data-id="<?php echo $data['id'];?>" data-request="<?php echo $getInfo['id'];?>"><i class="fas fa-trash"></i></a>
										
									</div>
									
								<?php } ?>
								
								</div>
							</div>
						</div>
					
					<?php
				}
				
				echo '</div>';
			}
		}
	}
	?>
</div>

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary morelearnersdetails" data-bs-toggle="modal" data-bs-target="#exampleModal" data-backdrop="static" data-keyboard="false"style="display:none;"></button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title morelearnersdetailsTitle" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close morelearnersdetailsPopupClose" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
      </div>
      <div class="modal-body morelearnersdetailsContent"></div>
    </div>
  </div>
</div>

<style>
.modal-backdrop.show {
    opacity: 0.5;
}
</style>