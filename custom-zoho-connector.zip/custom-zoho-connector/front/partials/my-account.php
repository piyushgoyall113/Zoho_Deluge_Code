<?php 
global $wpdb,$current_user;
$userID            = $current_user->ID;
$userInfo 		   = get_userdata($userID);
$applicationStatus = application_status($userID);
$centreID = !empty(get_user_meta($userID,'centre_id_number',true)) ? get_user_meta($userID,'centre_id_number',true) : 'N/A';
$centreOrg = !empty(get_user_meta($userID,'organisation_name',true)) ? get_user_meta($userID,'organisation_name',true) : 'N/A';
?>
<h3>Welcome - <?php echo $userInfo->first_name.' '.$userInfo->last_name;?></h3>

<?php if(in_array('applicant',$current_user->roles)){?>

<div class="row">
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Account Status: </b></span>
			<span class="value badge <?php echo $applicationStatus['class'];?> p-2"><?php echo $applicationStatus['status'];?></span>
		</div>
	</div>
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Centre ID: </b></span>
			<span class="value badge  p-2"><?php echo $centreID ;?></span>
		</div>
	</div>
</div>


<div class="row mt-5">
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>The name of your Organization: </b></span>
			<span class="value badge  p-2"><?php echo $centreOrg ;?></span>
		</div>
	</div>
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Email: </b></span>
			<span class="value badge  p-2"><?php echo $userInfo->user_email ;?></span>
		</div>
	</div>
</div>
<h3 class="mt-5" style="color:#e95d4c;text-transform: capitalize;">Qualification Withdrawals</h3>

<?php $comingDate = certification_end_date_comingup($userID);?>

<div class="table-responsivegg">
	<div class="table-gfdg2">
		<table id="dashboardwarm" class="table table-striped table-bordered nowrap display dataTable" style="width:100%;" cellspacing="10">
			<thead>
			<tr>
				<th>Learner Name</th>
				<th>Learner Qualification</th>
				<th>Start Date</th>
				<th>End Date</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				if(!empty($comingDate)){
					
					foreach($comingDate as $row){
						?>
							<tr>
								<td><?php echo $row['lname'];?></td>
								<td><?php echo $row['qname'];?></td>
								<td><?php echo $row['sdate'];?></td>
								<td><?php echo $row['edate'];?></td>
							</tr>
						<?php
					}
				}
			?>
		</tbody>
		</table>
	</div>
</div>

<?php }elseif(in_array('eqa',$current_user->roles)){
	
	
		$eqaStatus = get_user_meta($userID,'_EQA_Status',true);
		
		$eqaStatusClass = $eqaratingClass = '';
		
		if($eqaStatus == 'Onboarding'){
			$eqaStatusClass = 'eqa-Onboarding';
		}elseif($eqaStatus == 'Active'){
			$eqaStatusClass = 'eqa-Active';
		}else{
			$eqaStatusClass = 'eqa-Inactive';
		}
		
		$eqarating = !empty(get_user_meta($userID,'_EQA_Rating',true)) ? get_user_meta($userID,'_EQA_Rating',true) : 'N/A';
		
		if($eqarating == 'Green'){
			$eqaratingClass = 'badge-success';
		}elseif($eqarating == 'Red'){
			$eqaratingClass = 'badge-danger';
		}elseif($eqarating == 'Amber'){
			$eqaratingClass = 'badge-orange';
		}else{
			$eqaratingClass = '';
		}
		
		$eqaPhone = !empty(get_user_meta($userID,'_EQA_phone',true)) ? get_user_meta($userID,'_EQA_phone',true) : 'N/A';
		
		$contractStartDate = !empty(get_user_meta($userID,'_EQA_ContractStartDate',true)) ? date('d M, Y',strtotime(get_user_meta($userID,'_EQA_ContractStartDate',true) )): 'N/A';
		
		$contractEndDate = !empty(get_user_meta($userID,'_EQA_ContractEndDate',true)) ? date('d M, Y',strtotime(get_user_meta($userID,'_EQA_ContractEndDate',true) )) : 'N/A';
		
		$sectorSkills = !empty(get_user_meta($userID,'_EQA_Skills',true)) ? str_replace(';',', ',get_user_meta($userID,'_EQA_Skills',true)) : 'N/A';
		$levels       = !empty(get_user_meta($userID,'_EQA_Levels',true)) ? str_replace(';',', ',get_user_meta($userID,'_EQA_Levels',true)) : 'N/A';
		$task         = !empty(get_user_meta($userID,'_EQA_Task',true))   ? str_replace(';',', ',get_user_meta($userID,'_EQA_Task',true))     : 'N/A';
	
	?>

<div class="row">
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Account Status: </b></span>
			<span class="value badge p-2 <?php echo $eqaStatusClass;?>"><?php echo $eqaStatus;?></span>
		</div>
	</div>
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Email: </b></span>
			<span class="value badge  p-2"><?php echo $userInfo->user_email ;?></span>
		</div>
	</div>
	
</div>

<div class="row mt-3">
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Contract Start Date: </b></span>
			<span class="value badge  p-2"><?php echo $contractStartDate ;?></span>
		</div>
	</div>
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Contract End Date: </b></span>
			<span class="value badge  p-2"><?php echo $contractEndDate ;?></span>
		</div>
	</div>
</div>


<div class="row mt-3">
	
	<div class="col-md-6">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Phone: </b></span>
			<span class="value badge  p-2"><?php echo $eqaPhone ;?></span>
		</div>
	</div>
</div>

<hr>

<div class="row mt-3 skillset">
	<h2>Skill Sets For Work</h2>
</div>

<div class="row">
	
	<div class="col-md-12">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Sector Skills: </b></span>
			<span class="value badge skaillsetval p-2"><?php echo $sectorSkills ;?></span>
		</div>
	</div>
</div>

<div class="row mt-3">
	
	<div class="col-md-12">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Task Types: </b></span>
			<span class="value badge  p-2 skaillsetval"><?php echo $task ;?></span>
		</div>
	</div>
</div>

<div class="row mt-3">
	
	<div class="col-md-12">
		<div class="account_status d-flex flex-wrap align-items-center">
			<span class="label mr-2"><b>Levels: </b></span>
			<span class="value badge  p-2 skaillsetval"><?php echo $levels ;?></span>
		</div>
	</div>
</div>



<?php } ?>