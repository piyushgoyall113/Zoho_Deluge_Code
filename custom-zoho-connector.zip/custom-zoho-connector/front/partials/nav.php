<?php 
global $wpdb,$current_user,$post;
$ID = $post->ID;
$userID            = $current_user->ID;
$applicationStatus = application_status($userID);
?>
<ul class="nav nav-tabs customzohopanel m-0" role="tablist">

	<?php if(in_array('applicant',$current_user->roles)){?>

			<li class="<?php if($ID == '20952'){ echo "active";}?>">
				<a href="<?php echo site_url()?>/my-dashboard" title="Dashboard">  
					<span><i class="fa-home fa"></i></span> Dashboard
				</a>
			</li>
			
			<?php if($applicationStatus['status'] == 'Registered'){?>
			
				<li class="<?php if($ID == '20900' || $ID == '20999'){ echo "active";}?>">
					<a href="<?php echo site_url()?>/manage-learners" title="My Learners"> 
						<span><i class="fas fa-user-graduate"></i></span> Learners 
					</a>
				</li>
				<li class="<?php if($ID == '20925'){ echo "active";}?>">
					<a href="<?php echo site_url()?>/manage-staff" title="My Staff"> 
						<span><i class="fas fa-users-cog"></i></span> All Staff 
					</a>
				</li>
				
				<li class="<?php if($ID == '20980'){ echo "active";}?>">
					<a href="<?php echo site_url()?>/action-points" title="Action Points" class="d-flex align-items-center justify-content-between"> 
						<span><span><i class="fas fa-tasks"></i></span> Action Points </span> <span class="countnotify"><?php $new = count_centre_pending_AP(); echo $new;?></span>
					</a>
				</li>
				
				<li class="<?php if($ID == '20985'){ echo "active";}?>">
					<a href="<?php echo site_url()?>/learners-report" title="Learners Report"> 
						<span><i class="fas fa-tasks"></i></span> Learners Report
					</a>
				</li>
				
			<?php } ?>
			
			<li class="<?php if($ID == '20960'){ echo "active";}?>">
				<a href="<?php echo site_url()?>/manage-invoice" title="My Invoices"> 
					<span><i class="fas fa-receipt"></i></span> Invoices
				</a>
			</li>
	
		<?php }elseif(in_array('eqa',$current_user->roles)){?>
				
			<li class="<?php if($ID == '20952'){ echo "active";}?>">
				<a href="<?php echo site_url()?>/my-dashboard" title="Dashboard">  
					<span><i class="fa-home fa"></i></span> Dashboard
				</a>
			</li>
			
			<li class="<?php if($ID == '20974'){ echo "active";}?>">
				<a href="<?php echo site_url()?>/eqa-request" title="Request" class="d-flex align-items-center justify-content-between">  
					<span><span><i class="fa-chart-bar fa"></i></span>All Request</span> <span class="countnotify"><?php $new = count_eqa_new_request(); echo $new;?></span>
				</a>
			</li>
				
		<?php } ?>
	
			<li class="panelout">
				<a href="<?php echo wp_logout_url( home_url()); ?>" title="Logout"> <span><i class="fas fa-sign-out-alt"></i></span> Log Out
				</a>
			</li>
</ul>
				