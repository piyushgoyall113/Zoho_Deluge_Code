<div class="container outerselect2panel mt-5">
<?php 
global $wpdb,$current_user;
$userID   = $current_user->ID;
$where = "AND center_id = $userID";

$data = array();
if(!in_array('applicant',$current_user->roles)){
	
	echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
}else{
	$learnerstable	= $wpdb->prefix.'custom_learners';
	$GetAllLearners = $wpdb->get_results($wpdb->prepare("SELECT id,name FROM $learnerstable WHERE center_user_id = %d ORDER BY name",$current_user->ID),ARRAY_A);
	
	$table = $wpdb->prefix.'center_register_qualification';
    $table2 = $wpdb->prefix.'custom_qualification';
	
	$query = "SELECT t1.qualification_id as zoho_record_id,t2.name as name FROM $table as t1 Left JOIN $table2 as t2 ON t1.qualification_id = t2.zoho_record_id WHERE 1 $where ORDER BY t1.id DESC";
	
	$data  = $wpdb->get_results($query,ARRAY_A);
	?>
		<div class="row">
			<div class="col-md-12">
				<form class="custom_learner_add_qualification" id="custom_learner_add_qualification" method="post">
					 <div class="form-group">
						<label for="exampleInputEmail1" style="display:block;">Select Learner<span class="astrick">*</span></label>
						<select class="form-control commanselect2" name="user">
						  <option value="">-Select-</option>
						  <?php foreach($GetAllLearners as $listing){ ?>
							<option value="<?php echo $listing['id'];?>"><?php echo $listing['name'];?></option>
						  <?php } ?>
						</select>
					</div>
					 <div class="form-group">
						<label for="exampleInputEmail1" style="display:block;">The Qualification <span class="astrick">*</span></label>
						<select class="form-control commanselect2" name="qualification">
						  <option value="">-Select-</option>
						  <?php foreach($data as $listing){ ?>
							<option value="<?php echo $listing['zoho_record_id'];?>"><?php echo $listing['name'];?></option>
						  <?php } ?>
						</select>
					 </div>
					 <div class="form-group">
						<label for="exampleFormControlInput1">Start Date <span class="astrick">*</span></label>
						<input type="text" class="form-control" name="sdate" value="" id="sdate" autocomplete="off">
					  </div>
					  <div class="form-group">
						<label for="exampleFormControlInput1">End Date <span class="astrick">*</span></label>
						<input type="text" class="form-control" name="edate" id="edate" value="" autocomplete="off">
					  </div>
					  <input type="hidden" name="action" value="add_additional_qualification">
					  <input type="submit" value="Add Additional Qualification" class="btn btn-primary disablebtn">
				</form>
			</div>
		</div>	
		<div class="displayerror" style="margin-top:25px;"></div>
<?php
}
?>
</div>