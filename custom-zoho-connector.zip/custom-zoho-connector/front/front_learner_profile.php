<?php 
global $wpdb,$wp_query; 
$variables 	  = $wp_query->query_vars;
$userID 	  = $variables['userid'];

$table = $wpdb->prefix.'custom_qualification';
$data  = $wpdb->get_results("SELECT zoho_record_id,name FROM $table ORDER BY id  ASC",ARRAY_A);

$funding   = funding();
$Ethnicity = Ethnicity();

$learnerstable 			= $wpdb->prefix.'custom_learners';
$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
?>
<div class="container">
<?php 
if(isset($variables['userid']) && empty($variables['userid'])){
	
	echo '<div class="row">
			<p class="mt-3">You are not authorized access this page.</p>
		</div>';
}else{
	
	$result = $wpdb->get_row("SELECT t1.*,t2.funding,t2.dob,t2.gender,t2.ethnicity,t2.email,t2.language FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE ( t1.id = $userID)");
	
	$name          = $result->name;
	$email   	   = $result->email;
	$dob           = $result->dob;
	$gender        = $result->gender;
	$ethnicity     = $result->ethnicity;
	$language      = $result->language;
	$qualification = $result->qualification_id;
	$registered    = date('Y-m-d',strtotime($result->updated)); 
	$startdate     = $result->start;
	$enddate       = $result->end;
	$userfunding       = $result->funding;
	?>
	<form class="update_learners_details mt-5" id="update_learners_details" method="post">
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Name <span class="astrick">*</span></label>
					<input type="text" class="form-control" name="learners_name" value="<?php echo $name;?>" autocomplete="off"> 
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput2">Email <span class="astrick">*</span></label>
					<input type="email" class="form-control" name="learners_email" value="<?php echo $email;?>" autocomplete="off" disabled>
					<em>Email ID can not be changed.</em>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput3">The Qualification <span class="astrick">*</span></label>
					<select class="form-control commanselect2" name="qualification" disabled>
					  <option value="">-Select-</option>
					  <?php foreach($data as $listing){ ?>
						<option value="<?php echo $listing['zoho_record_id'];?>" <?php if($listing['zoho_record_id'] == $qualification){ echo 'selected';}?>><?php echo $listing['name'];?></option>
					  <?php } ?>
					</select>
					<em>The Qualification can not be changed.</em>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <div class="form-group">
					<label for="exampleFormControlInput5">DOB <span class="astrick">*</span></label>
					<input type="text" class="form-control" name="dob" value="<?php if(!empty($dob)){ echo date('m/d/Y',strtotime($dob));}?>" id="commandatepicker" autocomplete="off">
				  </div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <div class="form-group">
					<label for="exampleFormControlInput6">Gender <span class="astrick">*</span></label>
					<select class="form-control" name="gender">
					  <option value="">-Select-</option>
					  <option value="Male" <?php if($gender == 'Male'){ echo 'selected';}?>>Male</option>
					  <option value="Female" <?php if($gender == 'Female'){ echo 'selected';}?>>Female</option>
					</select>
				  </div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput3">Funding <span class="astrick">*</span></label>
					<select class="form-control" name="funding">
					  <option value="">-Select-</option>
					 <?php foreach($funding as $val){ ?>
						<option value="<?php echo $val;?>" <?php if($val == $userfunding){ echo 'selected';}?>><?php echo $val;?></option>
					  <?php } ?>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput3">Ethnicity <span class="astrick">*</span></label>
					<select class="form-control" name="ethnicity">
					  <option value="">-Select-</option>
					  <?php foreach($Ethnicity as $valE){ ?>
						<option value="<?php echo $valE;?>" <?php if($valE == $ethnicity){ echo 'selected';}?>><?php echo $valE;?></option>
					  <?php } ?>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <div class="form-group">
					<label for="exampleFormControlInput4">Start Date</label>
					<input type="text" class="form-control" name="sdate" value="<?php if(!empty($startdate)){ echo date('m/d/Y',strtotime($startdate));}?>" id="sdated" autocomplete="off" disabled>
				  </div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				 <div class="form-group">
					<label for="exampleFormControlInput7">End Date</label>
					<input type="text" class="form-control" name="edate" value="<?php if(!empty($enddate)){ echo date('m/d/Y',strtotime($enddate));}?>" id="edated" autocomplete="off" disabled>
				  </div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Assessment Language<span class="astrick">*</span></label>
					<input type="text" class="form-control" name="learners_language" value="<?php echo $language;?>" autocomplete="off"> 
				</div>
			</div>
		</div>
		<input type="hidden" name="action" value="update_learners_profile_data">
		<input type="hidden" name="ld" value="<?php echo base64_encode($userID);?>">
		<input type="submit" value="Update Profile" class="btn btn-primary disablebtn">
	</form>
	<div class="displayerror" style="margin-top:25px;"></div>
	<?php
}
?>
</div>