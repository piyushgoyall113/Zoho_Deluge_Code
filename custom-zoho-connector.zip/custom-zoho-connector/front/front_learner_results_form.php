<?php 
global $wpdb,$current_user;

$table  = $wpdb->prefix.'center_register_qualification';
$table2 = $wpdb->prefix.'custom_qualification';


$centreID = $checkSign = '';
$disable = 'disabled';

$data = array();
if(in_array('applicant',$current_user->caps)){
	
	
	
	$userID   = $current_user->ID;
	$centreID = get_user_meta($userID, 'centre_id_number',true);
	
	$checkSign = '<i class="fa fa-check"></i>';
	
	$disable = '';
	
	$where = "AND center_id = $userID";
	
	$query = "SELECT t1.qualification_id as zoho_record_id,t2.name as name FROM $table as t1 Left JOIN $table2 as t2 ON t1.qualification_id = t2.zoho_record_id WHERE 1 $where ORDER BY t1.id DESC";
	
	$data  = $wpdb->get_results($query,ARRAY_A);
}
?>
<div class="container">
   <form class="custom_learner_results" id="custom_learner_results" method="post" enctype="multipart/form-data">
      <div class="row">
         <div class="col-md-12">
            <div class="form-group position-relative statuscenterid_outer">
               <label for="exampleFormControlInput1">Your Centre ID Number <span class="astrick">*</span></label>
               <input type="text" class="form-control checkcenterid" name="cenername" value="<?php echo $centreID;?>" autocomplete="off" required>
				<span class="statuscenterid"><?php echo $checkSign;?></span> 
             </div>
         </div>
      </div>
	  
	  <div class="row">
		 <div class="col-md-12">
			<div class="form-group"><label for="exampleInputEmail1">The Qualification<span class="astrick">*</span></label>
				<select class="form-control getlearners" name="qualification" required>
					<option value="">-Select-</option>
					<?php foreach($data as $listing){ ?>
						<option value="<?php echo $listing['zoho_record_id'];?>"><?php echo $listing['name'];?></option>
					<?php } ?>
				</select>
				<em class="mb-5 qcreditval"></em>
			</div>
			
		 </div>
	  </div>
	  
	  <div class="row">
		 <div class="col-md-12">
			<div class="form-group"><label for="exampleInputEmail1">Link To Learner Work ( OneDrive/Dropbox...)<span class="astrick">*</span></label>
				<input type="text" class="form-control" name="cenerdriveurl" value="" autocomplete="off" required>
			</div>
		 </div>
	  </div>
	  
	  <div class="row">
		 <div class="col-md-12">
			<div class="uploadresultsouter"></div>
		 </div>
	  </div>
	  
	  <input type="hidden" name="qualificationcredits" class="qualificationcredits" value="">
      <input type="hidden" name="action" value="send_zoho_learner_results">
      <input type="submit" value="Submit" class="btn btn-primary disablebtn" <?php echo $disable;?>>
   </form>
   <div class="displayerror" style="margin-top:25px;"></div>
</div>