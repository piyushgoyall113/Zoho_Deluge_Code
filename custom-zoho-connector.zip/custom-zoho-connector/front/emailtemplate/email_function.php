<?php 
/* email header */
function email_header(){
	
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	$image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
	
	$header = '<div class="warp" style="max-width:700px; margin:0 auto;border: 1px solid #7399cb;">
				<table bgcolor="#7399cb" width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="font-family:Arial, Helvetica, sans-serif; font-size:15px; color:#221f1f"  class="deviceWidth">
					<tr>
						<td align="center" valign="middle">
							<table width="100%" border="0" cellspacing="0" cellpadding="0" class="deviceWidth">
							<tr>
								<td bgcolor="#fff" align="center">
									<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="centertext">
									<tr>
										<td>
											<table width="100%" border="0" align="left"  cellpadding="0" cellspacing="0" class="deviceWidth centertext" style="border-bottom:1px solid #7399cb;">
											<tr>
												<td align="center">
													<a href="'.site_url().'"><img src="'.$image[0].'" style="padding:15px 0px 15px 15px;width:40%;"/></a>
												</td>
											</tr>
											</table>
										</td>
									</tr>';
	
	return $header;
}


/* email footer */
function email_footer(){
	
	$footer = '</table>
				</td>
			</tr>
			</table>
		</td>
	</tr>
</table>
</div>';

return $footer;
}

function eqa_welcomeEmail($data){
	
	$mailheader = email_header();
	$mailfooter = email_footer();

	$body  = $mailheader;
	
	$body .= '<tr>
						<td align="center" valign="top">
							<table width="90%" border="0" cellspacing="0" cellpadding="0" class="deviceWidth3">
							<tr>
								<td height="30">&nbsp;</td>
							</tr>
							<tr>
								<td>
									<table cellpadding="5" cellspacing="5">
										<tr>
											<td colspan="2">Dear <b>'.$data['name'].'</b>,<br><br><p>Please find your login details to the ATHE EQA Hub below.</p></td>
										</tr>
										
										<tr>
											<td width="150">
												<b>Username:</b>
											</td>
											<td>
												'.$data['username'].'
											</td>
										</tr>
										<tr>
											<td>
												<b>Password:</b>
											</td>
											<td>
												'.$data['password'].'
											</td>
										</tr>
										
										<tr>
											<td height="15"> </td>
										</tr>
										
										<tr>
											<td colspan="2"><a href="'.site_url().'/log-in" style="font-family:arial;font-size: 16px; border: 0;  outline: none;  background-color:  #7399cb;  color: #fff;  display: inline-block;    border-radius: 5px;  padding: 8px 30px;  line-height: normal; cursor:  pointer; text-decoration: none; font-weight: bold; letter-spacing: 0.5px;">Login Here</a></</td>
										</tr>
										
										<tr>
											<td colspan="2">
												<br>Best regards,<br>ATHE
											</td>							
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height="30"> </td>
							</tr>
							</table>
						</td>
					</tr>';
					
	$body    .= $mailfooter; 

    // Always set content-type when sending HTML email
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	// More headers
	$headers .= 'From: ATHE <support@athe.co.uk>' . "\r\n";
	
	//mail('eqa@yopmail.com','Welcome to ATHE',$body,$headers);
	
	mail($data['username'],'Welcome to ATHE',$body,$headers);
}
?>