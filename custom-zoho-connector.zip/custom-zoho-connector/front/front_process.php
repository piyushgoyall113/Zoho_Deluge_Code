<?php
require_once ZOHO_PLUGIN_PATH . 'xeroLib/vendor/autoload.php';
// Use this class to deserialize error caught
use XeroAPI\XeroPHP\AccountingObjectSerializer;

 
/* Register Learners by center */
add_action('wp_ajax_sens_zoho_learner','callback_sens_zoho_learner');
function callback_sens_zoho_learner(){
	
	/*ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);*/

	
	global $wpdb;
	
	$centerID      = sanitize_text_field($_POST['cenername']);
	$qualification = sanitize_text_field($_POST['qualification']);
	$funding       = sanitize_text_field($_POST['funding']);
	$sdate         = $_POST['sdate'];
	$edate         = $_POST['edate'];
	
	$totalLearner       = intval($_POST['totalrows']);
	
	$response = $error = array();
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	if(empty($centerID)){
		array_push($error,"Centre ID Number field is required.");
	}if(empty($qualification)){
		array_push($error,"Qualification field is required.");
	}if(empty($sdate)){
		array_push($error,"Start Date field is required.");
	}if(empty($edate)){
		array_push($error,"End Date field is required.");
	}if($totalLearner < 1){
		array_push($error,"At least one learner details is required.");
	}
	
	
	if(empty($error)){
		
		 $validateID = validate_duplicateCenterID($centerID);
		 
		 $cuserid = validate_duplicateCenterUserID($centerID);
		 
		 if(empty($validateID)){
			 
			 array_push($error,"Your center ID is not valid.");
			 $response = array('status'=>'fail','message'=>$error);
			 
		 }else{
			 
			 $learner       = isset($_POST['learner']);
			 
			 $emailArray = $uniqueArray = array();
			 
			 $name      = $_POST['learner']['name'];
			 $date      = $_POST['learner']['date'];
			 $gender    = $_POST['learner']['gender'];
			 $ethnicity = $_POST['learner']['ethnicity'];
			 $emails    = $_POST['learner']['email'];
			 $language  = $_POST['learner']['language'];
			 
			 if ( count( $emails ) !== count( array_unique( $emails ) ) ) 
			 {
					  array_push($error,"Some email are duplicates in Learner Details.");
					  $response = array('status'=>'fail','message'=>$error);
					 
			}else{
				
				foreach($emails as $email){
					
					/* Check already learner exists or not */
					
					$Info = $wpdb->get_row($wpdb->prepare("SELECT email FROM $learnerstable WHERE email = %s",$email),ARRAY_A);
					
					if(!empty($Info)){
						
						array_push($error,'<b>'.$email.'</b> this email id already registered.');
					}
				}
				
				if(!empty($error)){
					
					$response = array('status'=>'fail','message'=>$error);
					
					
				}else{
					
					
					$RegisterZOHOParam = $userLIDs = $RegisterAdmissionZOHOParam = $userLIDAdmissions = array();
					
					foreach($name as $key=>$val){
						
						/* Add Learners */
						
						$wpdb->insert(
									$learnerstable,
									array(
											'center_id'          =>    $centerID,
											'center_user_id'     =>    $cuserid,
											'funding'            =>    $funding,
											'name'               =>    $val,
											'dob'                =>    date('Y-m-d',strtotime($date[$key])),
											'gender'             =>    $gender[$key],
											'ethnicity'          =>    $ethnicity[$key],
											'email'              =>    $emails[$key],
											'language'           =>    $language[$key],
											'created'            =>    date('Y-m-d H:i:s'),
											'updated'            =>    date('Y-m-d H:i:s'),
											'registered_status'  =>    'Pending'
									)
								);
								
						$lastInserid = $wpdb->insert_id;	
						
						array_push($userLIDs,$lastInserid);
						
						$RegisterZOHOParam[] = array(
						
												'Centre_ID_Number' 		=> $centerID,
												'Government_Funded'		=> $funding,
												'Name'		            => $val,
												'Date_of_birth'		    => date('Y-m-d',strtotime($date[$key])),
												'Gender'		    	=> $gender[$key],
												'Ethnicity'		    	=> $ethnicity[$key],
												'Email'		    	    => $emails[$key],
												'Assessment_Language'   => $language[$key],
												'Associated_Center'     => array('id'=>$validateID),
												'Is_learners_registered_or_not' => 'Pending'
											);
						
					}
					
					$active_access_token = 1;
					if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
					{
						$active_access_token = get_refresh_token();
					}
					
					if($active_access_token === 1){
						
						$ZOHOLearningdata         = array();
						$ZOHOLearningdata         = $RegisterZOHOParam;
						$params       	          = array('data'=>$ZOHOLearningdata);	

						$Data                     = request_zoho_data('Learner_Registration', $params,'POST');
						
						
						if(count($Data['body']['data']) > 0){
							
							foreach($Data['body']['data'] as $key=>$recoards){
								
								$zoho_record_id =  $recoards['details']['id'];
								
								/* Update Zoho ID with Learners */
								
								$wpdb->update($learnerstable,array('zoho_recoard_id'=>$zoho_record_id),array('id'=>$userLIDs[$key]));
									
								/* Send admission data in zoho and created a entry in wp */	
								
								$wpdb->insert(
									$learnersadmissiontable,
									array(
											'lid'                =>    $userLIDs[$key],
											'center_id'          =>    $cuserid,
											'qualification_id'   =>    $qualification,
											'start'              =>    date('Y-m-d',strtotime($sdate)),
											'name'               =>    $name[$key],
											'learner_zoho_id'    =>	   $zoho_record_id,
											'end'                =>    date('Y-m-d',strtotime($edate)),
											'created'            =>    date('Y-m-d H:i:s'),
											'updated'            =>    date('Y-m-d H:i:s'),	
											
										)
								);
								
								$lastAddmissionInserid = $wpdb->insert_id;	
								
								//array_push($userLIDAdmissions,$lastAddmissionInserid);
								
								$RegisterAdmissionZOHOParam['Name']                   =  $name[$key];
								$RegisterAdmissionZOHOParam['Start_Date']             = date('Y-m-d',strtotime($sdate));
								$RegisterAdmissionZOHOParam['End_Date']               = date('Y-m-d',strtotime($edate));			
								$RegisterAdmissionZOHOParam['Associated_Learner']     = array('id'=>$zoho_record_id);			
								$RegisterAdmissionZOHOParam['Learner_Qualification']  = array('id'=>$qualification);
								$RegisterAdmissionZOHOParam['Payment']                =  'Pending';								
											
								$ZOHOLearningAdmissiondata         = array();
								$ZOHOLearningAdmissiondata[]         = $RegisterAdmissionZOHOParam;
								$paramsAdmission       	           = array('data'=>$ZOHOLearningAdmissiondata);	

								$DataAdmission                     = request_zoho_data('Learners_Admission', $paramsAdmission,'POST');
								
								if($DataAdmission['body']['data'][0]['status'] == 'success'){
									
									$ADDMISSION_record_id =  $DataAdmission['body']['data'][0]['details']['id'];
									
									$wpdb->update($learnersadmissiontable,array('zoho_recoard_id'=>$ADDMISSION_record_id),array('id'=>$lastAddmissionInserid));
								}		
								
							}
						
							$response = array('status'=>'sucess','message'=>'Data has been successfully saved.');
							
						}else{
							
							array_push($error,"Something went wrong. Please try again.");
							$response = array('status'=>'fail','message'=>$error);
						}
						
					}
				
				}
			}
			
		}
		
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response);

die;	
}

/* check duplicate center ID */
function validate_duplicateCenterID($id){
	
	global $wpdb;
	
	$userID = $wpdb->get_row("SELECT user_id FROM $wpdb->usermeta WHERE (meta_key = 'centre_id_number' AND meta_value = '". $id ."')");
	$zohocenterRegID = '';
	
	if(!empty($userID)){
		$zohocenterRegID = get_user_meta( $userID->user_id, 'zoho_record_id', true);
	}
	return $zohocenterRegID;
}


/* check  center ID */
function validate_duplicateCenterUserID($id){
	
	global $wpdb;
	
	$userCID = 0;
	
	$userID = $wpdb->get_row("SELECT user_id FROM $wpdb->usermeta WHERE (meta_key = 'centre_id_number' AND meta_value = '". $id ."')");
	$zohocenterRegID = '';
	
	if(!empty($userID)){
		$userCID =  $userID->user_id;
	}
	return $userCID;
}

/**
 * Action that fires during form entry processing after initial field validation.
 *
 * @link   https://wpforms.com/developers/wpforms_process/
 *
 * @param  array  $fields    Sanitized entry field. values/properties.
 * @param  array  $entry     Original $_POST global.
 * @param  array  $form_data Form data and settings.
 */
 
function wpf_dev_process( $fields, $entry, $form_data ) {
      
    // Optional, you can limit to specific forms. Below, we restrict output to
    // form #1214.
    if ( absint( $form_data[ 'id' ] ) !== 1214 ) {
        return $fields;
    }
	
    // check the field ID 4 to see if it's empty and if it is, run the error    
		if(!empty( $fields[168][ 'value' ]) ) 
        {
            
			  $validate = validate_duplicateCenterUserID($fields[168][ 'value' ]);	

			  if($validate > 0){	
			  

				wpforms()->process->errors[ $form_data[ 'id' ] ] [ '168' ] = esc_html__( 'Your Centre ID Number already exists.', 'plugin-domain' );
			  }
          
        }
    }
add_action( 'wpforms_process', 'wpf_dev_process', 10, 3 );

/* Frontend varify center id */

add_action('wp_ajax_varify_centerid','callback_varify_centerid');
function callback_varify_centerid(){
	
	global $wpdb;
	
	$centerID      = sanitize_text_field($_POST['id']);
	$validate      = validate_duplicateCenterUserID($centerID);	
	
	$table     = $wpdb->prefix.'custom_qualification';
	$unitdata  = $wpdb->get_results("SELECT zoho_record_id,name FROM $table ORDER BY id  ASC",ARRAY_A);
	
	$zohocenterRegID = 0;
	
	$zohoLearnerUser = array();
	
	if($validate > 0){
		
		$zohocenterRegID = get_user_meta( $validate, 'zoho_record_id', true); 
		
		$args = array(
			'role'       => 'learner',
			'meta_query' => array(
				array(
					'key'     => 'centre_id_number',
					'value'   => $centerID,
					'compare' => '=',
				)
			)
		);
		 
		$q = new WP_User_Query( $args );
		
		$learners = $q->get_results();
		
		if(!empty($learners)){
			
			foreach($learners as $data){
				
				$lID     = $data->ID;
				$name    = $data->data->display_name;
				$uerdata = array('id'=>$lID,'name'=>$name);
				array_push($zohoLearnerUser,$uerdata);
			}
		}
	}
	
	echo json_encode(array('userCID'=>$validate,'zohocenterRegID'=>$zohocenterRegID,'zohoLearnerUser'=>$zohoLearnerUser,'qualifications'=>$unitdata));
	
die;	
}

/* Center upload learners results */

// Function to check if at least one element is not blank
function hasNonBlankElement($array) {
    foreach ($array as $element) {
        if (!empty($element)) {
            return true;
        }
    }
    return false;
}

// Function to check for duplicate values in an array
function hasDuplicates($array) {
    $countValues = array_count_values($array);
    foreach ($countValues as $count) {
        if ($count > 1) {
            return true;
        }
    }
    return false;
}

add_action('wp_ajax_send_zoho_learner_results','callback_send_zoho_learner_results');
function callback_send_zoho_learner_results(){
	
	global $wpdb;
	
	$resultstable     = $wpdb->prefix.'learners_results';
	$resultsmetatable = $wpdb->prefix.'zoho_learners_results_meta';
	
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	
	$centerID        = sanitize_text_field($_POST['cenername']);
	
	$totalLearner    = intval($_POST['totalrows']);
	
	$validate      = validate_duplicateCenterUserID($centerID);
	
	$center_zoho_id = get_user_meta( $validate, 'zoho_record_id', true); 
	
	
	$qualification        = sanitize_text_field($_POST['qualification']);
	
	$qualificationName    = get_qualification_name_by_id($qualification);
	
	$response = $error = array();
	
	$totalunits = intval($_POST['totalunits']);
	
	$units = $RegisterZOHOParam  = array();
	
	$user          = $_POST['results']['user'];
	
	//$files          = $_FILES['results']['name']['file'];
	//$filesTemp      = $_FILES['results']['tmp_name']['file'];
	
	$driveUrl        = $_POST['cenerdriveurl'];
	
	if($totalLearner < 1){
		array_push($error,"At least one learner details is required.");
	}
	
	if(empty($error)){
		
		if ( count( $user ) !== count( array_unique( $user ) ) ) 
		 {
				  array_push($error,"Some learner are duplicates in Learner Details.");
				  $response = array('status'=>'fail','message'=>$error);
				 
		}elseif(empty($driveUrl)){
			
			
			array_push($error,"Please enter a valid URL for link to learner work.");
			$response = array('status'=>'fail','message'=>$error);
			
		}elseif(!wp_http_validate_url($driveUrl)){
			
			
			array_push($error,"Please enter a valid URL for link to learner work.");
			$response = array('status'=>'fail','message'=>$error);
			
		}else{
			
					foreach($user as $key=>$val){
				
						for($i=1;$i<=$totalunits;$i++){
							
							$units[$val]['Unit'][]  = $_POST['results']['unit'.$i][$key];
							$units[$val]['Grade'][] = $_POST['results']['grade'.$i][$key];
							
						}
					}
					
					$uniterror = $unitduplicateerror = array();
					
					foreach($units as $key => $value){
						
						// Check if at least one element is not blank
						if (hasNonBlankElement($value['Unit'])) {
							array_push($uniterror,1);
						} else {
							array_push($uniterror,0);
						}
						
						
						
						// Check for duplicates
						if (hasDuplicates(array_filter($value['Unit']))) {
							array_push($unitduplicateerror,0);
						} else {
							array_push($unitduplicateerror,1);
						}
						
						
					}
					
					
					if (in_array(0, $uniterror)){
						
						array_push($error,"Please ensure that at least one unit is selected.");
						$response = array('status'=>'fail','message'=>$error);
						
					}elseif (in_array(0, $unitduplicateerror)){
						
						array_push($error,"Please ensure that there are duplicate units were found.");
						$response = array('status'=>'fail','message'=>$error);
						
					}else{
						
						$unitsFinal = array();
						
						foreach($user as $key3 => $val3){
		
							for($i=1;$i<=$totalunits;$i++){
								
								if($_POST['results']['unit'.$i][$key3] != ''){
								
									$unitsFinal[$val3]['Unit'][]  = $_POST['results']['unit'.$i][$key3];
									$unitsFinal[$val3]['Grade'][] = $_POST['results']['grade'.$i][$key3];
								}
								
							}
							
							/* Insert data in wp table */
									
								$wpdb->insert(
														$resultstable,
														array(
																'center_id'               =>    $validate,
																'qualification_id'        =>    $qualification,
																'learner_addimission_id'  =>    $val3,
																'created'                 =>    date('Y-m-d H:i:s')
														)
													);
													
								$lastResultsid = $wpdb->insert_id;	
								
								$unitsFinal[$val3]['lastResultsid'] = $lastResultsid;
							
						}
						
						
						$resultsEntries = array();
						
						foreach($unitsFinal as $key1=>$val1){
								  
								  $GetLearnersInfo = $wpdb->get_row("SELECT t2.zoho_recoard_id, t1.name FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE ( t1.id = $key1)");
								  
								  $Unit  = $val1['Unit'];
								  $Grade = $val1['Grade'];
								  $i = 1;
								  foreach($Unit as $key3=>$val3){
									  
									  $RegisterZOHOParam[] = array(
																	'Name'        => $GetLearnersInfo->name,
																	'Learner'     => array('id'=>$GetLearnersInfo->zoho_recoard_id),
																	'Center'      => array('id'=>$center_zoho_id),
																	'Unit'        => array('id'=>$val3), 
																	'Qualification' => array('id'=>$qualification), 
																	'Grade_8'     => $Grade[$key3],
																	'Result_Status' => 'Pending'
																);
											
									

										
										
										$resultsEntries[] = array('lastResultsid'=>$val1['lastResultsid'],'unit'=>$val3,'grade'=>$Grade[$key3]);
										
										$i++;							
								  }
							  }
							  
							  
							  $InvoiceArray = array('centreZohoID'=>$center_zoho_id,'ZohoproductID'=>2126173000004006028,'ZohoProductName'=>'Centre Recognition Application','userID'=>$validate,'qty'=>count($RegisterZOHOParam));
							  
							  $HighPerformancestatus = get_user_meta($validate,'High_Performing_Status',true);
							  
							  
							  $itemsdesc = '';
							  $xeroLineitems = array();
							  
							  foreach($RegisterZOHOParam as $invoiceDetails)
							  {
								  
								  $itemsdesc .= $qualificationName.' - '.$invoiceDetails['Name'].PHP_EOL.PHP_EOL;
								  
								  $xeroLineitems[] = array('qname'=>$qualificationName,'learner'=>$invoiceDetails['Name']);
							  }
							  
							  $InvoiceArray['itemDesc'] =  $itemsdesc;
							  
							  $InvoiceArray['xeroLineitems'] = $xeroLineitems;
							  
							$active_access_token = 1;
							if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
							{
								$active_access_token = get_refresh_token();
							}
						
							if($active_access_token === 1){
								
								$ZOHOLearningdata         = array();
								$ZOHOLearningdata         = $RegisterZOHOParam;
								$params       	          = array('data'=>$ZOHOLearningdata);	

								$Data                     = request_zoho_data('Learner_Results', $params,'POST');
								
								$zohoRecoardIDs = array();
								
								if(count($Data['body']['data']) > 0){
									
									foreach($Data['body']['data'] as $keyz => $recoards){
												
										$zoho_results_id =  $recoards['details']['id'];
										
										
										array_push($zohoRecoardIDs,$zoho_results_id);
										
										/* Results meta save in wordpress table */	
									
										$wpdb->insert(
														$resultsmetatable,
														array(
																'result_id'          =>    $resultsEntries[$keyz]['lastResultsid'],
																'unit'   			 =>    $resultsEntries[$keyz]['unit'],
																'grade'              =>    $resultsEntries[$keyz]['grade'],
																'zoho_result_id'     =>    $zoho_results_id
														)
													);
													
										
												 
									}
											
									if(!empty($zohoRecoardIDs)){
										
										
											
											if(!empty($driveUrl)){
												
												$Attachparams = array('attachmentUrl'=>$driveUrl);	
												$SendAttachment = request_zoho_attachmentData('Center_Registration/'.$center_zoho_id.'/Attachments', $Attachparams,'POST');
											}
											
											 /* sent invoice to ZPOHO */
											 
											 if(count($InvoiceArray['xeroLineitems']) <= 3 && $HighPerformancestatus != 1){
											 
												$CreateInvoice_ZOHO_Xero = create_invoice_for_results_submit($InvoiceArray);
											 }
											
											$response = array('status'=>'sucess','message'=>'Data has been successfully saved.');
										}	
										
										
										
									}else{
										
										array_push($error,"Something went wrong. Please try again.");
										$response = array('status'=>'fail','message'=>$error);
									}
									
								}
						
					}
			
			}
	}else{
		
		$response = array('status'=>'fail','message'=>$error);
	}
	
	echo json_encode($response);
	
die;	
}

/* get unit as per qualification seleted  */

add_action('wp_ajax_fetch_unit','fetch_unit');
function fetch_unit(){
	
	global $wpdb;
	
	$resultstable     = $wpdb->prefix.'learners_results';
	$resultsmetatable = $wpdb->prefix.'zoho_learners_results_meta';
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	$qualificationstable 			= $wpdb->prefix.'custom_qualification';
	
	$id      = intval($_POST['id']);
	
	/* get qualification credit value */
	
	$creditvalue = $wpdb->get_row($wpdb->prepare("SELECT total_credits FROM $qualificationstable WHERE zoho_record_id = %s",$id),ARRAY_A);
	
	$creditvalue =  !empty($creditvalue) ? $creditvalue['total_credits'] : 'N/A';
	
	$centerID      = sanitize_text_field($_POST['centerid']);
	$validate      = validate_duplicateCenterUserID($centerID);	
	
	$table          = $wpdb->prefix.'zoho_unit';
	$tablerelation  = $wpdb->prefix.'zoho_relation_unit_qualification';
	
	$query = "SELECT t2.unit_name,t1.unit_id,t1.type FROM $tablerelation as t1 Left JOIN $table as t2 ON t1.unit_id  = t2.zoho_unit_id  WHERE quali_id = '".$id."'";
	
	$data  = $wpdb->get_results($query,ARRAY_A);
	
	$response = $zohoLearnerUser = array();
	
	if(!empty($data)){
		
		$required = $optional = array();
		
		foreach($data as $val){
			
			if($val['type'] == 'Mandatory'){
				$required[] = array('id'=>$val['unit_id'],'name'=>$val['unit_name']);
			}
			
			if($val['type'] == 'Optional'){
				$optional[] = array('id'=>$val['unit_id'],'name'=>$val['unit_name']);
			}
		}
		
		$final = array(
						'required' => $required,
						'optional' => $optional
						);
						
						
		$querylearners = "SELECT t2.registered_status,t1.id,t1.name FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid  = t2.id  WHERE t1.center_id = '".$validate."' AND t1.qualification_id = '".$id."' AND t2.registered_status = 'Registered'";	
		
		
		$learners = $wpdb->get_results($querylearners,ARRAY_A);
		
		if(!empty($learners)){
			
			foreach($learners as $userdata){
				
				$getresults = $wpdb->get_row($wpdb->prepare("SELECT learner_addimission_id FROM $resultstable WHERE learner_addimission_id = %d",$userdata['id']),ARRAY_A);
				
				if(empty($getresults)){
				
					$lID     = $userdata['id'];
					$name    = $userdata['name'];
					$uerdata = array('id'=>$lID,'name'=>$name);
					array_push($zohoLearnerUser,$uerdata);
				}
			}
			
			$response = array('status'=>'sucess','message'=>$final,'zohoLearnerUser'=>$zohoLearnerUser,'totalunit'=>count($data),'qcreditval'=>$creditvalue);
			
		}else{
			
			
			$response = array('status'=>'fail','message'=>'No registered learners found in selected qualification. Please select other qualification.');
		}				
						
	}else{
		
		$response = array('status'=>'fail','message'=>'No units found in selected qualification. Please select other qualification.');
	}
	
	
	echo json_encode($response);
	
die;	
}

/* update learners profile */

add_action('wp_ajax_update_learners_profile_data','update_learners_profile_data');
function update_learners_profile_data(){
	
	global $wpdb;
	
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	
	$userLID       = intval(base64_decode($_POST['ld']));
	
	$funding       = sanitize_text_field($_POST['funding']);
	$name          = sanitize_text_field($_POST['learners_name']);
	$gender        = sanitize_text_field($_POST['gender']);
	$language      = sanitize_text_field($_POST['learners_language']);
	$ethnicity     = sanitize_text_field($_POST['ethnicity']);
	//$sdate         = $_POST['sdate'];
	$dob           = $_POST['dob'];
	//$edate         = $_POST['edate'];
	
	$response = $error = array();
	
	$Userinfo = $wpdb->get_row("SELECT t1.zoho_recoard_id as zoho_adminissionID,t2.id as userid,t2.zoho_recoard_id as zoho_profileID FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE ( t1.id = $userLID)",ARRAY_A);
	
	if(empty($Userinfo)){
		
		array_push($error,"Learner is not valid.");
		$response = array('status'=>'fail','message'=>$error);
		
	}else{
	
		if(empty($name)){
			array_push($error,"Name field is required.");
		}if(empty($dob)){
			array_push($error,"DOB field is required.");
		}if(empty($gender)){
			array_push($error,"Gender field is required.");
		}if(empty($funding)){
			array_push($error,"Funding field is required.");
		}if(empty($ethnicity)){
			array_push($error,"Ethnicity field is required.");
		}/*if(empty($sdate)){
			array_push($error,"Start date field is required.");
		}if(empty($edate)){
			array_push($error,"End Date field is required.");
		}*/if(empty($language)){
			array_push($error,"Assessment language field is required.");
		}
		
		if(empty($error)){
			
			$admissionID = $Userinfo['zoho_adminissionID'];
			
			if(empty($Userinfo['zoho_profileID'])){
				
				array_push($error,"Learner is not valid.");
				$response = array('status'=>'fail','message'=>$error);
				
			}else{
				
				/* Update profile */
				
				$wpdb->update($learnerstable,
								array('name'=>$name,'dob'=>date('Y-m-d',strtotime($dob)),'gender'=>$gender,'funding'=>$funding,'ethnicity'=>$ethnicity,'language'=>$language,'updated'=>date('Y-m-d H:i:s')),
								array('id'=>$Userinfo['userid']));
				
				
				$UpdateZOHOParam[] = array(
												
												'Government_Funded'		=> $funding,
												'Name'		            => $name,
												'Date_of_birth'		    => date('Y-m-d',strtotime($dob)),
												'Gender'		    	=> $gender,
												'Ethnicity'		    	=> $ethnicity,
												'Assessment_Language'   => $language
											);
											
				$active_access_token = 1;
				if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
				{
					$active_access_token = get_refresh_token();
				}
				
				if($active_access_token === 1){ 
					
					$ZOHOLearningdata         = array();
					$ZOHOLearningdata         = $UpdateZOHOParam;
					$params       	          = array('data'=>$ZOHOLearningdata);	

					$Data                     = update_zoho_data('Learner_Registration', $params, $Userinfo['zoho_profileID'], 'PUT');
					
					if(count($Data['body']['data']) > 0){
						
						/* Update addmission data */
						
						$wpdb->update($learnersadmissiontable,
								//array('name'=>$name,'start'=>date('Y-m-d',strtotime($sdate)),'end'=>date('Y-m-d',strtotime($edate)),'updated'=>date('Y-m-d H:i:s')),
								
								array('name'=>$name,'updated'=>date('Y-m-d H:i:s')),
								
								array('id'=>$userLID));
								
						$UpdateAddZOHOParam[] = array(
												
												'Name'		            => $name,
												//'Start_Date'		    => date('Y-m-d',strtotime($sdate)),
												//'End_Date'		        => date('Y-m-d',strtotime($edate)),
											);	

						$ZOHOLearningAdddata         = array();
						$ZOHOLearningAdddata         = $UpdateAddZOHOParam;
						$paramsAdd       	         = array('data'=>$ZOHOLearningAdddata);	

						$UpdateAdd                   = update_zoho_data('Learners_Admission', $paramsAdd, $admissionID, 'PUT');

						$response = array('status'=>'sucess','message'=>'Data has been successfully updated.');
						
					}else{
						
						array_push($error,"Something went wrong. Please try again.");
						$response = array('status'=>'fail','message'=>$error);
					}
					
				}
			}
			
		}else{
			
			$response = array('status'=>'fail','message'=>$error);
		}
	
	}
	
	echo json_encode($response);
	
die;	
}

/* Get EQA email ID FROM Centre ZOHO ID */
function associate_eqa_with_centre($zohoRecoardID){
	
	$EQAemailID = '';
 
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		$active_access_token = get_refresh_token();
	}

	if($active_access_token === 1){

		$gData  = get_zoho_data('Center_Registration', $zohoRecoardID, 'GET');
		
		if(count($gData['body']['data']) > 0){
			
			$Assign_EQA = $gData['body']['data'][0]['Assign_EQA'];
			
			if(!empty($Assign_EQA)){
				
				$EQAID = $Assign_EQA['id'];
				$EQAname = $Assign_EQA['name'];
				
				
				$gEQAData  = get_zoho_data('EQAs', $EQAID, 'GET');
				
				if(count($gEQAData['body']['data']) > 0){
					
					$$emailID = $gEQAData['body']['data'][0]['Email'];
				}
				
			}
			
		}

	}
	
	return $EQAemailID;
}

/* Results submit invoice create into zoho */
function create_invoice_for_results_submit($InvoiceData){
	
	global $wpdb;
	
	$response = array();
	
	/*ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);*/
	
	$WpCentreID 			= $InvoiceData['userID'];
	$xero_contact_id 		= get_user_meta($WpCentreID,'xero_contact_id',true);
	$HighPerformingStatus 	= get_user_meta($WpCentreID,'High_Performing_Status',true);
	$tax 					= get_user_meta($WpCentreID,'tax',true);
	$Address_Line_1 		= get_user_meta($WpCentreID,'Address_Line_1',true);
	$Address_Line_2 		= get_user_meta($WpCentreID,'Address_Line_2',true);
	$City 					= get_user_meta($WpCentreID,'City',true);
	$state 					= get_user_meta($WpCentreID,'state',true);
	$country 				= get_user_meta($WpCentreID,'country',true);
	$zipcode 				= get_user_meta($WpCentreID,'zipcode',true);
	$zohoOwner 				= get_user_meta($WpCentreID,'zohoOwner',true);
	
	$address = '';
	
	if(!empty($Address_Line_1)){
		$address .= $Address_Line_1;
	}if(!empty($Address_Line_2)){
		$address .= ', '.$Address_Line_2;
	}
	
	$taxAmount = 0;
	
	if($tax == 'We are a United Kingdom based commercial provider that is not government funded'){
		
		$taxAmount = 20;
	}
	
	$TaxType     = $taxAmount > 0 ? 'TAX001' : 'TAX002';
	
	$invoiveAmount = 150;
	
	$product_items = $lineitem = $taxlist = array();
	
	$product_id 	= $InvoiceData['ZohoproductID'];
	$product_name   = $InvoiceData['ZohoProductName'];
	$product_qty    = $InvoiceData['qty'];
	$listprice      = $invoiveAmount / $product_qty;

	
	$product = array('id'=>$product_id,'name'=>$product_name);
	
	$lineitem[] = array('product'=>$product,'product_description'=>$InvoiceData['itemDesc'],'quantity'=>$product_qty,'net_total'=>$listprice,'total'=>$listprice,'list_price'=>$listprice);
	
	$Date = date('Y-m-d');
	
	$taxlist[] = array('percentage'=>$taxAmount,'name'=>'Vat');
	
	
	$Zohoparam[] = array(
							'Product_Details' => $lineitem,
							'Subject'         => 'Learners Submission Results',
							'Status'          => 'Created',
							'Billing_Street'  => $address,
							'Billing_City'    => $City,
							'Billing_State'   => $state,
							'Billing_Code'    => $zipcode,
							'Billing_Country' => $country,
							'Owner'           => $zohoOwner,
							'Centre_Name'     => $InvoiceData['centreZohoID'],
							'Due_Date'        => date('Y-m-d', strtotime($Date. ' + 28 days')),
							'Invoice_Date'    => date('Y-m-d'),
							'$line_tax'       => $taxlist
						);
						
						
	$active_access_token = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		$active_access_token = get_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$ZOHOLearningdata         = array();
		$ZOHOLearningdata         = $Zohoparam;
		$params       	          = array('data'=>$ZOHOLearningdata);	

		$Data                     = request_zoho_data('Invoices', $params,'POST');
		
		if(count($Data['body']['data']) > 0){
			
			$ZoHOInvoiceID = $Data['body']['data'][0]['details']['id'];
			
			
				/* Send Invoice to Xero */
	
				$XeroinvoiceInfo = array(
			
									'userid'                      => $WpCentreID,
									'zoho_user_id'                => $InvoiceData['centreZohoID'],
									'zoho_learner_id'             => "",
									'zoho_learner_addimission_id' => "",
									'zoho_invoice_id'             => $ZoHOInvoiceID,
									'zoho_xero_contact_id'        => $xero_contact_id,
									'zoho_product_name'           => "Learners Submission Results",
									'zoho_invoice_qty'            => $product_qty,
									'zoho_invoice_amount'         => $invoiveAmount,
									'zoho_invoice_created_date'   => date('Y-m-d'),
									'zoho_invoice_due_date'       => date('Y-m-d', strtotime($Date. ' + 28 days')),
									'invoice_type'                => "Full",
									'invoice_discount'            => 0,
									'invoice_tax'                 => $taxAmount
								);

			$Xeroactive_access_token = 1;
			
			if(time() > get_option('wc_xero_access_token_expires_on')){
				
				$Xeroactive_access_token = xero_refresh_token();
			}

			if($Xeroactive_access_token === 1){
				
				$access_token = get_option('wc_xero_access_token');
				
				$xeroTenantId = get_option('wc_xero_TenantID');
				
				// Configure OAuth2 access token for authorization: OAuth2
				$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

				$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
					new GuzzleHttp\Client(),
					$config
				);
				
				$contact = new XeroAPI\XeroPHP\Models\Accounting\Contact;
				$contact->setContactID($xero_contact_id);
				
				
				
				
				$lineItems = [];
				
				foreach($InvoiceData['xeroLineitems'] as $xerolineItem){
					
					$lineItem = new XeroAPI\XeroPHP\Models\Accounting\LineItem;
					
					$productname = 'Learners Submission Results - '.$xerolineItem['qname'].' - '.$xerolineItem['learner'];
					 
					$lineItem->setDescription($productname);
					$lineItem->setQuantity(1);
					$lineItem->setUnitAmount($listprice);
					$lineItem->setTaxType($TaxType);
					$lineItem->setItemCode('CRA');
					$lineItem->setAccountCode(200);
					
					array_push($lineItems, $lineItem);
				}
				
				$invoice = new XeroAPI\XeroPHP\Models\Accounting\Invoice;
				$invoice->setType(XeroAPI\XeroPHP\Models\Accounting\Invoice::TYPE_ACCREC);
				$invoice->setContact($contact);
				$invoice->setDate(date('Y-m-d'));
				$invoice->setDueDate(date('Y-m-d', strtotime($Date. ' + 28 days')));
				$invoice->setLineItems($lineItems);
				$invoice->setReference($ZoHOInvoiceID);
				$invoice->setStatus(XeroAPI\XeroPHP\Models\Accounting\Invoice::STATUS_AUTHORISED);
				
				$invoices = new XeroAPI\XeroPHP\Models\Accounting\Invoices;
				$arr_invoices = [];
				array_push($arr_invoices, $invoice);
				$invoices->setInvoices($arr_invoices);
				
				try {
						
						$result = $apiInstance->createInvoices($xeroTenantId, $invoices);
						
						
						$invoiceID     = $result->getInvoices()[0]->getInvoiceId();
						$invoiceNumber = $result->getInvoices()[0]->getInvoiceNumber();
						
						/* Created a new entry in wordpress for update payment status */
						
						$XeroinvoiceInfo['xero_invoice_no']   = $invoiceNumber;
						$XeroinvoiceInfo['xero_invoice_id']   = $invoiceID;
						$XeroinvoiceInfo['zoho_invoice_type'] = 'CRIL';
						$XeroinvoiceInfo['created']           = date('Y-m-d H:i:s');
						$XeroinvoiceInfo['payment_status']    = 'Pending';
						$XeroinvoiceInfo['late_fee']    	  = 0;
						
						$NewRecoard = create_invoice_recoard($XeroinvoiceInfo);
						
						/*  Email send to user for online payment */
						
						//$requestEmpty = new XeroAPI\XeroPHP\Models\Accounting\RequestEmpty;
						
						//$apiInstance->emailInvoice($xeroTenantId, $invoiceID, $requestEmpty);
						
						/* Update ZOHO Invoice */
						
						$UpdateZoHoInvoice = array('invoiceID'=>$invoiceID,'invoiceNumber'=>$invoiceNumber,'recoard_id'=>$ZoHOInvoiceID);
						
						ZOHOInvoiceUpdate($UpdateZoHoInvoice);
						
						$response = array('status'=>'sucess');
						
						
					}catch (\XeroAPI\XeroPHP\ApiException $e) {
							
							$error = AccountingObjectSerializer::deserialize(
							  $e->getResponseBody(),
							  '\XeroAPI\XeroPHP\Models\Accounting\Error',
							  []
							);
							
							$response = array('status'=>'fail');
						
					}
			}

		}
	}

	return $response;	
}

/* Update zoho invoice recoard */
function ZOHOInvoiceUpdate($UpdateZoHoInvoice){
	
		$UpdateAddZOHOParam[] = array(
												
								'Xero_Invoice_ID'		=> $UpdateZoHoInvoice['invoiceID'],
								'Xero_Invoice_Number'	=> $UpdateZoHoInvoice['invoiceNumber'],
								'Send_Xero'		        => true,
							);	

		$ZOHOLearningAdddata         = array();
		$ZOHOLearningAdddata         = $UpdateAddZOHOParam;
		$paramsAdd       	         = array('data'=>$ZOHOLearningAdddata);	

		$UpdateData                   = update_zoho_data('Invoices', $paramsAdd, $UpdateZoHoInvoice['recoard_id'], 'PUT');
}

/* get unit credit score */
add_action('wp_ajax_get_unit_score','get_unit_score');
function get_unit_score(){
	
	global $wpdb;
	
	$UnitTable = $wpdb->prefix.'zoho_unit';
	
	$id = array_filter(array_unique($_POST['record_val']));
	
	$totalCredit = 0;
	
	if(!empty($id)){
		
		$lIDs = "";
	
		foreach($id as $ids){
			$lIDs .= "'".$ids."'".',';
		}
		
		$removeLastComma  = rtrim($lIDs,',');
		
		$GetData = $wpdb->get_results("SELECT unit_credit_value as credit FROM $UnitTable WHERE zoho_unit_id IN (".$removeLastComma.")",ARRAY_A);

		

		 if(!empty($GetData)){
			 
			 foreach($GetData as $tc){
				 
				 $totalCredit += $tc['credit'];
			 }
		 }
		 
	}
	
	echo $totalCredit;
die;	
}
?>