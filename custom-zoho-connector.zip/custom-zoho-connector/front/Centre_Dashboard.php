<?php 
if(!is_user_logged_in()){
	wp_redirect(site_url('log-in'));
	exit;
}
?>
<div class="container centredashbordpanel">
	<div class="vertical-tab" role="tabpanel">
		<div class="row">
			<div class="col-lg-3 col-md-4">
				<div class="centredashbordpanel_Tabs">
					<!-- Nav tabs -->
					<?php include ZOHO_PLUGIN_PATH.'front/partials/nav.php';?>
				</div>
			</div>
			<div class="col-lg-9 col-md-8">
				<div class="centredashbordpanel_Tabs_Data h-100">
					<!-- Tab panes -->
					<div class="tab-content tabs h-100">
						<?php include ZOHO_PLUGIN_PATH.'front/partials/my-account.php';?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>