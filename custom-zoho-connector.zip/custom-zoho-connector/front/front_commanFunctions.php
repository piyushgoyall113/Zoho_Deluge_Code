<?php 
/* get respective centre learners */
function get_respective_centre_learners(){
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $learnersadmissiontable WHERE center_id = ".$userID);
	return $GetData->total > 0 ? $GetData->total : 0;
}

/* Respective centre Initial get 10 learners */

function get_respective_centre_learners_tenusers(){
	
	global $wpdb,$current_user;
	$learnersadmissiontable = $wpdb->prefix.'custom_learners_admission';
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$userID   = $current_user->ID;
	$information = array();
	
	$GetData = $wpdb->get_results("SELECT t1.*,t2.email,t2.registered_status FROM $learnersadmissiontable as t1 Left JOIN $learnerstable as t2 ON t1.lid = t2.id WHERE ( t1.center_id = $userID) ORDER BY t1.id DESC LIMIT 0,50");
	
	if(!empty($GetData)){
		
		foreach($GetData as $result){
			
			$ID           = $result->id;
			$LID          = $result->lid;
			$name         = $result->name;
			$email   	  = $result->email;
			$registered   = date('Y-m-d',strtotime($result->updated));
			
			$qualification = $result->qualification_id;
			
			$quali = get_qualification_name_by_id($qualification);
			
			$information[] = array(
										
										'ID'            => $ID,
										'LID'           => $LID,
										'name' 			=> $name,
										'email' 		=> $email,
										'qualification' => $quali,
										'registered'    => $registered,
										'status'    	 => $result->registered_status,
										'overall_grade'  => $result->overall_grade,
										'is_completed'  => $result->is_completed
									);
		}
	}
		
		
	 return $information;	
	
}

/* Get qualification name by id */

function get_qualification_name_by_id($zoho_record_id){
	
	global $wpdb;
	$table = $wpdb->prefix.'custom_qualification';
	
	$data  = $wpdb->get_row("SELECT name FROM $table WHERE zoho_record_id = '".$zoho_record_id."'");
	
	return $data->name;
}

/* Get unit name by id */

function get_unit_name_by_id($zoho_record_id){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_unit';
	
	$data  = $wpdb->get_row("SELECT unit_name FROM $table WHERE zoho_unit_id = '".$zoho_record_id."'");
	
	return $data->unit_name;
}

/* funding Array */

function funding(){
	
	return array('16 -19','Adult Learner Loans (ALL)','Adult Education Budget (AEB)','Free Courses for Jobs','European Social Fund (ESF)');
}

/* Ethnicity Array */

function Ethnicity(){
	
	return array('Indian','Pakistani','Bangladeshi','Chinese','Any other Asian background','Caribbean','African','Any other Black, Black British, or Caribbean background','White and Black Caribbean','White and Black African','White and Asian','Any other Mixed or multiple ethnic background','English, Welsh, Scottish, Northern Irish or British','Irish','Gypsy or Irish Traveller','Roma','Any other White background','Arab','Any other ethnic group');
}

/* get total no of center staff */
function total_center_staff(){
	
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	$TotalData   = $wpdb->get_row("SELECT count(*) as total FROM $Table WHERE center_id = $userID",ARRAY_A);
	
	return $TotalData['total'];
}


/* get initial ten center staff */
function center_staff(){
	
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	
	$Table       = $wpdb->prefix.'zoho_centre_staff_data';
	$staffData   = $wpdb->get_results("SELECT * FROM $Table WHERE center_id = '".$userID."' ORDER BY id DESC LIMIT 0,10",ARRAY_A);
	
    return $staffData;
}

/* get user id by zoho recoard ID */
function get_user_id_by_zohoid($id){
	
	global $wpdb;
	
	$userCID = 0;
	
	$userID = $wpdb->get_row("SELECT user_id FROM $wpdb->usermeta WHERE (meta_key = 'zoho_record_id' AND meta_value = '". $id ."')");
	$zohocenterRegID = '';
	
	if(!empty($userID)){
		$userCID =  $userID->user_id;
	}
	return $userCID;
}

/* get learner name by id */
function get_learner_name_by_id($userID){
	
	global $wpdb;
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnername            = $wpdb->get_row($wpdb->prepare("SELECT name FROM $learnerstable WHERE id = %d",$userID),ARRAY_A);
	return $learnername['name'];
}

/* get learner name by zoho id */
function get_learner_name_by_zohoid($ZOHOID){
	
	global $wpdb;
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnername            = $wpdb->get_row($wpdb->prepare("SELECT name FROM $learnerstable WHERE zoho_recoard_id = %s",$ZOHOID),ARRAY_A);
	return $learnername['name'];
}

/* get learner zoho recoard id by user id */
function get_learner_zohorecoardid_by_userid($userID){
	
	global $wpdb;
	$learnerstable 			= $wpdb->prefix.'custom_learners';
	$learnerZohoID          = $wpdb->get_row($wpdb->prepare("SELECT zoho_recoard_id FROM $learnerstable WHERE id = %d",$userID),ARRAY_A);
	return $learnerZohoID['zoho_recoard_id'];
}

/* user application status */
function application_status($userid){
	
	$applicationStatus = get_user_meta($userid,"Application_Status",true);
	
	$class = $text = '';
	switch ($applicationStatus){
		
		case "Pending":
			$class = "status-pending badge-warning";
			$text  = "Under Process"; 
		break;
		case "Approved":
			$class = "status-approved badge-success";
			$text  = "Verified"; 
		break;
		case "Rejected":
			$class = "status-rejected badge-danger";
			$text  = "Rejected"; 
		break;
		case "Registered":
			$class = "status-registered badge-success";
			$text  = "Registered"; 
		break;
		case "EQA Approved":
			$class = "status-approved badge-success";
			$text  = "Verified"; 
		break;
	  default:
		$class = "status-default badge-secondary";
		$text  = $applicationStatus; 
	}
	
	return array('status'=>$text,'class'=>$class);
	
}

/* get respective centre invoice */
function get_respective_centre_invoice(){
	global $wpdb,$current_user;
	$userID   = $current_user->ID;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE userid = ".$userID);
	return $GetData->total > 0 ? $GetData->total : 0;
}

/* Respective centre Initial get 50 invoices */

function get_initial_respective_centre_invoices(){
	
	global $wpdb,$current_user;
	
	$table       = $wpdb->prefix.'zoho_xero_invoice';
	$userID      = $current_user->ID;
	$information = array();
	
	$GetData = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE userid = %d ORDER BY id DESC LIMIT 0,50",$userID));
	
	if(!empty($GetData)){
		
		foreach($GetData as $result){
			
			$ID            = $result->id;
			$invoiceNumber = $result->xero_invoice_no;
			$date          = date('d M Y',strtotime($result->zoho_invoice_created_date));
			$duedate       = date('d M Y',strtotime($result->zoho_invoice_due_date));
			$type          = $result->invoice_type;
			$amount        = $result->zoho_invoice_amount;
			$discount      = $result->invoice_discount;
			$tax           = $result->invoice_tax;
			$pname         = $result->zoho_product_name;
			$status        = $result->payment_status;
			$attachment    = $result->attachment;
			$invoicename   = $result->zoho_product_name;
			$payurl        = $result->xero_invoice_url;
			
			$information[] = array(
										
										'ID'                 => $ID,
										'invoiceNumber'      => $invoiceNumber,
										'date' 			     => $date,
										'duedate' 		     => $duedate,
										'type' 				 => $type,
										'amount'    		 => $amount,
										'discount'    		 => $discount,
										'tax'    			 => $tax,
										'pname'    			 => $pname,
										'status'    		 => $status,
										'attachment'         => $attachment,
										'invoicename'        => $invoicename,
										'payurl'             => $payurl
									);
		}
	}
		
		
	 return $information;	
	
}

/* Generate random password for user create */

function EQArandomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

/* EQA Panel comman functions */

/* count new request */
function count_eqa_new_request(){
	
	global $wpdb,$current_user,$post;
	$userID  = $current_user->ID;
	
	$count = 0;
	
	if(in_array('eqa',$current_user->roles)){
		
		$table = $wpdb->prefix.'zoho_eqa_results_request';
		
		$EQAZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
		
		$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE zoho_eqaprofile_id = '".$EQAZohoProfileID."' AND request_status = 'New' ");
		
		$count =  $GetData->total > 0 ? $GetData->total : 0;
	}
	
	return $count;
}

function count_eqa_all_request(){
	
	global $wpdb,$current_user,$post;
	$userID  = $current_user->ID;
	
	$count = 0;
	
	if(in_array('eqa',$current_user->roles)){
		
		$table = $wpdb->prefix.'zoho_eqa_results_request';
		
		$EQAZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
		
		$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE zoho_eqaprofile_id = '".$EQAZohoProfileID."' ");
		
		$count =  $GetData->total > 0 ? $GetData->total : 0;
	}
	
	return $count;
}

/* Get initial 50 new request */

function get_respective_eqa_request(){
	
	global $wpdb,$current_user;
	
	$table = $wpdb->prefix.'zoho_eqa_results_request';
	
	$userID   = $current_user->ID;
	
	$EQAZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
	
	$information = array();
	
	$GetData = $wpdb->get_results("SELECT * FROM $table WHERE zoho_eqaprofile_id = '".$EQAZohoProfileID."' ORDER BY id DESC ");
	
	if(!empty($GetData)){
		
		foreach($GetData as $result){
			
			$ID           			  = $result->id;
			$zoho_request_no          = $result->zoho_request_no;
			$zoho_request_id          = $result->zoho_request_id;
			$asign_centre   	  	  = $result->asign_centre;
			$learners   	  	  	  = count(explode(',',$result->learners_ids));
			$registered   			  = date('M d, Y',strtotime($result->updated));
			
			 $centreID = get_user_id_by_zohoid($asign_centre);
			
			$centreData = get_userdata($centreID);
			
			$EQAWPdata = get_user_id_by_zohoid($result->zoho_eqaprofile_id);
			
			$information[] = array(
										
										'ID'            	     => $ID,
										'zoho_request_no'        => $zoho_request_no,
										'zoho_request_id' 	     => $zoho_request_id,
										'centre_name' 		     => $centreData->first_name,
										'centre_email' 		     => $centreData->user_email,
										'learners' 			     => $learners,
										'registered'    	     => $registered,
										'status'    	       	 => $result->request_status,
										'result_completed_date'  => $result->result_completed_date,
										'zoho_eqaprofile_id'     => $result->zoho_eqaprofile_id,
										'zoho_centre_id'         => $asign_centre,
										'EQAWPID'                => $EQAWPdata,
										'result_report_id'       => $result->result_report_id
									);
		}
	}
		
		
	 return $information;	
	
}

/* Get initial 50 centre action points */


function count_centreActionspoints(){
	
	global $wpdb,$current_user,$post;
	$userID  = $current_user->ID;
	
	$count = 0;
	
	$table = $wpdb->prefix.'zoho_centre_action_point';
		
	$CentreZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
		
	$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE zoho_centre_id = '".$CentreZohoProfileID."' ");
		
	$count =  $GetData->total > 0 ? $GetData->total : 0;
	
	
	return $count;
}

function get_respective_cap(){

global $wpdb,$current_user;
	
	$table = $wpdb->prefix.'zoho_centre_action_point';
	
	$userID   = $current_user->ID;
	
	$CentreZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
	
	$information = array();
	
	$GetData = $wpdb->get_results("SELECT * FROM $table WHERE zoho_centre_id = '".$CentreZohoProfileID."' ORDER BY id DESC",ARRAY_A);
	
	return $GetData;
}

/* count all pending action points */
function count_centre_pending_AP(){
	
	global $wpdb,$current_user,$post;
	$userID  = $current_user->ID;
	
	
	$table = $wpdb->prefix.'zoho_centre_action_point';
	
	$zoho_centre_id = get_user_meta($userID,'zoho_record_id',true);
	
	$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE zoho_centre_id = '".$zoho_centre_id."' AND status = 'Pending' ");
	
	$count =  $GetData->total > 0 ? $GetData->total : 0;
	

	return $count;
}

function count_learnersreport(){
	
	global $wpdb,$current_user,$post;
	$userID  = $current_user->ID;
	
	$count = 0;
	
	$table = $wpdb->prefix.'zoho_report_submission';
		
	$CentreZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
		
	$GetData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE centre_id = '".$CentreZohoProfileID."' ");
		
	$count =  $GetData->total > 0 ? $GetData->total : 0;
	
	
	return $count;
}

function get_center_learnersreport(){
	
	global $wpdb,$current_user;
	
	$table = $wpdb->prefix.'zoho_report_submission';
	
	$userID   = $current_user->ID;
	
	$CentreZohoProfileID = get_user_meta($userID,'zoho_record_id',true);
	
	$information = array();
	
	$GetData = $wpdb->get_results("SELECT id,eqa_name,created FROM $table WHERE centre_id = '".$CentreZohoProfileID."' ORDER BY id DESC",ARRAY_A);
	
	return $GetData;
}

/* Get unit by qualification ID */
function get_related_units_by_qualificationID($QID){
	
	
	global $wpdb;
	
	$Table = $wpdb->prefix.'zoho_relation_unit_qualification';
	
	$TableUnits = $wpdb->prefix.'zoho_unit';
	
	$response = array();
	
	$query  = "SELECT t1.unit_name,t1.zoho_unit_id FROM $TableUnits as t1 LEFT JOIN $Table as t2 ON t2.unit_id = t1.zoho_unit_id WHERE t2.quali_id = $QID ORDER BY t1.unit_name ASC";
	
	
	$getdata = $wpdb->get_results($query,ARRAY_A);
	
	if(empty($getdata)){
		
		$response = array('status' => 'fail');
		
	}else{
		
		$response = array('status' => 'sucess' , 'data' => $getdata );
	}
	
	return $response;
		
}

/* display certification end date is coming up at centre dashboard */
function certification_end_date_comingup($centreID){
	
	global $wpdb;
	
	$table = $wpdb->prefix.'custom_learners_admission';
	
	$getData = $wpdb->get_results("SELECT * FROM $table WHERE (DATE(end) BETWEEN DATE(NOW()) AND DATE(NOW()) + INTERVAL 3 MONTH) AND is_completed = 0 AND center_id = '".$centreID."' ORDER BY end asc LIMIT 0,50",ARRAY_A);
	
	$information = array();
	
	if(!empty($getData)){
		
		foreach($getData as $data){
			
			$information[] = array(
										'lname' => $data['name'],
										'qname' => get_qualification_name_by_id($data['qualification_id']),
										'sdate' => date('M d,Y', strtotime($data['start'])),
										'edate' => date('M d,Y', strtotime($data['end']))
									);
			
		}
	}
	
	return $information;
}

/* get total record for Operational end date is coming up */
function get_operational_enddate(){
	
	global $wpdb,$current_user;
	
	$userID   = $current_user->ID;
	
	$table = $wpdb->prefix.'custom_learners_admission';
	
	$getData = $wpdb->get_row("SELECT COUNT(*) as total FROM $table WHERE (DATE(end) BETWEEN DATE(NOW()) AND DATE(NOW()) + INTERVAL 3 MONTH) AND is_completed = 0 AND center_id = '".$userID."'");
	
	
	return $getData->total > 0 ? $getData->total : 0;
}
?>