<?php 
global $wpdb;
$table = $wpdb->prefix.'custom_qualification';
$data  = $wpdb->get_results("SELECT zoho_record_id,name FROM $table ORDER BY id  ASC",ARRAY_A);
?>
<div class="container">
	<form class="check_learners_certificate_status mt-5" id="check_learners_certificate_status" method="post">
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Enter your name <span class="astrick">*</span></label>
					<input type="text" class="form-control" name="name" value="" autocomplete="off" onkeyup="nospaces(this)"> 
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Select qualification <span class="astrick">*</span></label>
					 <select class="form-control commanselect2" name="qualification">
					  <option value="">-Select-</option>
					  <?php foreach($data as $listing){ ?>
						<option value="<?php echo $listing['zoho_record_id'];?>"><?php echo $listing['name'];?></option>
					  <?php } ?>
					</select>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label for="exampleFormControlInput1">Enter your credit value <span class="astrick">*</span></label>
					<input type="text" class="form-control" name="credit" value="" autocomplete="off" onkeypress="return validateNumber(event)"> 
				</div>
			</div>
		</div>
		<input type="hidden" name="action" value="check_learners_certificate_status">
			<?php wp_nonce_field( 'plcstatus', 'lcstatus' ); ?>
		<input type="submit" value="Submit" class="btn btn-primary disablebtn">
	</form>
	<div class="displayerror" style="margin-top:25px;"></div>
	<div class="displaycontent" style="margin-top:25px;"></div>
</div>