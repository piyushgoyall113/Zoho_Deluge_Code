jQuery( function($) {
	
	$('body').on('clcik','.morelearnersdetails',function(){
  		$('.morelearnersdetails').modal({
    		backdrop: 'static',
    		keyboard: false
		});
	});
	
	$( "body" ).on('click','.results-resubmit > a',function(){
		
		$( ".updateresult" ).toggle();
	});
	
	var usersoptions =  unitsOptions = totalunits = '';
    
	$( "#sdate" ).datepicker({ 
	
		dateFormat: 'mm/dd/yy',
		showOn: "button",
		buttonImage: rwbObj.pluginurl+"/assets/css/images/calendar.gif",
		buttonImageOnly: true,
		buttonText: "Select date",
		changeMonth: true,
		changeYear: true,
		yearRange: "1970:+nn"
		
	});
	$( "#edate" ).datepicker({ dateFormat: 'mm/dd/yy',showOn: "button",
		buttonImage: rwbObj.pluginurl+"/assets/css/images/calendar.gif",
		buttonImageOnly: true,changeMonth: true,changeYear: true,yearRange: "1970:+nn" 
		
	});
	
	$( "#commandatepicker" ).datepicker({ dateFormat: 'mm/dd/yy',showOn: "button",
		buttonImage: rwbObj.pluginurl+"/assets/css/images/calendar.gif",
		buttonImageOnly: true,changeMonth: true,changeYear: true,yearRange: "1970:+nn" 
		
	});
	
	$(".learnersendDate").datepicker({
		dateFormat: 'yy-mm-dd',
		changeMonth: true,
		changeYear: true,
		yearRange: "1970:+nn"
	});
	
	$(".learnersstartDate").datepicker({
		dateFormat: 'yy-mm-dd',
		changeMonth: true,
		changeYear: true,
		yearRange: "1970:+nn",
		//maxDate: new Date(),
		onSelect: function (date) {

			var selectedDate = new Date(date);
			var msecsInADay = 86400000;
			var endDate = new Date(selectedDate.getTime() + msecsInADay);
			$(".learnersendDate").datepicker("option", "minDate", endDate);

		}
	});

	
	// Initialize Select2
	jQuery('.commanselect2').select2();
	
	// Initialize Select2
	jQuery('.getlearners').select2();
		
		
	/* Add more entry */
	
	jQuery('body').on('click','.add_more_entry',function(){
		
		var totalrows = jQuery('.totalrows').val();
		totalrows     = parseInt(totalrows) + parseInt(1);
		
		var Ethnicity = '<option value="Indian">Indian</option><option value="Pakistani">Pakistani</option><option value="Bangladeshi">Bangladeshi</option><option value="Chinese">Chinese</option><option value="Any other Asian background">Any other Asian background</option><option value="Caribbean">Caribbean</option><option value="African">African</option><option value="Any other Black, Black British, or Caribbean background">Any other Black, Black British, or Caribbean background</option><option value="White and Black Caribbean">White and Black Caribbean</option><option value="White and Black African">White and Black African</option><option value="White and Asian">White and Asian</option><option value="Any other Mixed or multiple ethnic background">Any other Mixed or multiple ethnic background</option><option value="English, Welsh, Scottish, Northern Irish or British">English, Welsh, Scottish, Northern Irish or British</option><option value="Irish">Irish</option><option value="Gypsy or Irish Traveller">Gypsy or Irish Traveller</option><option value="Roma">Roma</option><option value="Any other White background">Any other White background</option><option value="Arab">Arab</option><option value="Any other ethnic group">Any other ethnic group</option>';
		
		if(totalrows <= 10){
		
			var Html = '<div class="row align-items-end del-'+totalrows+'"><a href="javascript:void(0)" class="remove_more_entry" data-id="'+totalrows+'" title="Remove Entry"><i class="fa fa-window-close" aria-hidden="true"></i></a><div class="col-md-2"><div class="form-group"><label for="exampleFormControlInput1">Name<span class="astrick">*</span></label><input type="text" class="form-control" name="learner[name][]" value="" autocomplete="off" required maxlength="30"></div></div><div class="col-md-2"><div class="form-group"><label for="exampleFormControlInput1">DOB<span class="astrick">*</span></label><input type="text" class="form-control datepickercomman" name="learner[date][]" value="" autocomplete="off" required></div></div><div class="col-md-2"><div class="form-group"><label for="exampleInputPassword1">Gender</label><select class="form-control" name="learner[gender][]"><option value="">-Select-</option><option value="Male">Male</option><option value="Female">Female</option></select></div></div><div class="col-md-2"><div class="form-group"><label for="exampleInputPassword1">Ethnicity</label><select class="form-control" name="learner[ethnicity][]"><option value="">-Select-</option>'+Ethnicity+'</select></div></div><div class="col-md-2"><div class="form-group"><label for="exampleFormControlInput1">Email<span class="astrick">*</span></label><input type="email" class="form-control" name="learner[email][]" value="" autocomplete="off" required> </div></div><div class="col-md-2"><div class="form-group"><label for="exampleFormControlInput1">Assessment Language<span class="astrick">*</span></label><input type="text" class="form-control" name="learner[language][]" value="" autocomplete="off" required=""> </div></div><script> jQuery( ".datepickercomman" ).datepicker({dateFormat: "mm/dd/yy", showOn: "button", buttonImageOnly: true,buttonText: "Select date",buttonImage: rwbObj.pluginurl+"/assets/css/images/calendar.gif",changeMonth: true,changeYear: true,maxDate: new Date(new Date().getFullYear(), 11, 31),yearRange: "1970:+nn"});</script></div>';
				
			jQuery('.addmorelearnerdetailsreapter').append(Html);
			jQuery('.totalrows').val(totalrows);
		
		}
		
	});


	jQuery('body').on('click','.remove_more_entry',function(){	
	
		var currentDataID = jQuery(this).attr('data-id');
		
		jQuery(".del-" + currentDataID).remove();
		var totalchilds = jQuery('.totalrows').val();
		
		var totalchild = parseInt(totalchilds) - 1;
		
        jQuery(".totalrows").val(totalchild);
	
	});
	
	
	jQuery('form#custom_learner_reg').on('submit', function (e) {
		
		var Rdata = new FormData(this);
		jQuery('.disablebtn').prop('disabled', true);
		jQuery('.displayerror').html('');
		jQuery('.loader').css('display','flex');
		jQuery.ajax({
			type: 'POST',
			dataType: 'json',
			url: rwbObj.ajaxurl,
			data: Rdata,
			success: function (data) {
				jQuery('.loader').css('display','none');
				jQuery('.disablebtn').prop('disabled', false);
				if (data.status == 'fail') {
					var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
					jQuery(data.message).each(function (index, value) {
						errorhtml += '<li>' + value + '</li>';
					});
					errorhtml += '</ul></div>';
					jQuery('.displayerror').html(errorhtml).addClass('error');
				} else {
					
					var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
					jQuery('#custom_learner_reg')[0].reset();
					jQuery('.displayerror').html(sucesshtml).addClass('sucess');
					
					setTimeout(function () {
						jQuery('.displayerror').html("").removeClass('sucess');
						location.reload();
					}, 2000);
				}
			},
			cache: false,
			contentType: false,
			processData: false
		});
		e.preventDefault();
	});
	
	/* Results submit */
	
	jQuery('body').on('keyup','.checkcenterid', function (e) {
		
		var id = jQuery(this).val();
		
		if(id.length >= 3){
			
			jQuery('.statuscenterid').html('<img src="'+rwbObj.pluginurl+'assets/images/loader.gif" alt="loader" width="40px">');
			jQuery('.disablebtn').prop('disabled', true);
			jQuery('.displayerror').html('');
			
			jQuery('.uploadresultsouter').html("");
			
			usersoptions =  unitsOptions = '';
			
				jQuery.ajax({
					
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "varify_centerid", id: id },
					success: function (data) {
						if (data.userCID < 1) {
							jQuery('.statuscenterid').html('<i class="fa fa-window-close" aria-hidden="true"></i>');
						} else {
							
							
							jQuery('.disablebtn').prop('disabled', false);
							jQuery('.statuscenterid').html('<i class="fa fa-check"></i>');
							
						}
					}
			});
		}else{
			
			jQuery('.disablebtn').prop('disabled', true);
			jQuery('.statuscenterid').html('');
			jQuery('.uploadresultsouter').html("");
			jQuery('.displayerror').html('');
			
			// Set selected
			jQuery('.getlearners').val(null).trigger('change.select2');
		}
	});	
	
	
	jQuery( 'body' ).on('change','.getlearners',function() {
		
		var id = jQuery(this).val();
		
		var centerid = jQuery(".checkcenterid").val();
		
		if(centerid == ''){
			
			jQuery('.disablebtn').prop('disabled', true);
						
			var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
			errorhtml += '<li>Please enter centre ID Number.</li>';
			errorhtml += '</ul></div>';
			jQuery('.displayerror').html(errorhtml).addClass('error');
			
			jQuery('.uploadresultsouter').html("");
			
			// Set selected
			jQuery('.getlearners').val(null).trigger('change.select2');
			
			
		}else{
			
			jQuery('.loader').css('display','flex');
			
			jQuery('.displayerror').html('');
			
			usersoptions =  unitsOptions = totalunits = '';
			
			jQuery.ajax({
						
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "fetch_unit", id: id, centerid : centerid},
					success: function (data) {
						
						jQuery('.loader').css('display','none');
						
						if(data.status == 'fail'){
							
							jQuery('.disablebtn').prop('disabled', true);
							
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							errorhtml += '<li>' + data.message + '</li>';
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
							
							jQuery('.uploadresultsouter').html("");
							
							
						}else{
							
							jQuery('.disablebtn').prop('disabled', false);
							
							var users = data.zohoLearnerUser;
							
							if(users.length > 0){
								
								var innerHTML = '<div class="heading"><h4>Learner Details ( You only allow at a time 5 learners results submit.)</h4></div>';
							
								innerHTML += '<div class="addmorelearnerdetailsouter"><input type="hidden" name="totalrows" class="totalrowsr" value="0"><div class="addmorelearnerdetailsreapter"><div class="addnewresults"><a href="javascript:void(0)" class="add_more_entry_results" title="Add New Entry"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Results</a></div><div class="appendtabledata"></div></div></div>';
								
								
								jQuery('.uploadresultsouter').html(innerHTML);
								
								totalunits = data.totalunit;
								
								var users = data.zohoLearnerUser;
								
								jQuery( users ).each(function( index,value ) {
									usersoptions += '<option value="'+value.id+'">'+value.name+'</option>';
								}); 
								
								jQuery.map( data.message, function( val, i ) {
									
									var cl = capitalizeFirstLetter(i);
									
									if(val.length > 0){
									
										unitsOptions += '<optgroup label="'+cl+'">';
										
										jQuery( val ).each(function( index,value ) {
											
											unitsOptions += '<option value="'+value.id+'">'+value.name+'</option>';
												
										});
									
										unitsOptions += '</optgroup>';
									
									}
									
								});
								
							}else{
								
								var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
								errorhtml += '<li>You have uploaded results for all learners.</li>';
								errorhtml += '</ul></div>';
								jQuery('.displayerror').html(errorhtml).addClass('error');
								
								jQuery('.uploadresultsouter').html("");
								
								jQuery('.disablebtn').prop('disabled', true);
							}
							
						}
					}
				});
			}
		});
	
	
	/* Add more results */
	
	jQuery('body').on('click','.add_more_entry_results',function(){
		
		var grade = '<option value="Pass">Pass</option><option value="Merit">Merit</option><option value="Distinction">Distinction</option><option value="Fail">Fail</option>';
		
		var totalrowsl = jQuery('.totalrowsr').val();
		
		totalrowsl     = parseInt(totalrowsl) + parseInt(1);
		
		if(totalrowsl <= 5){
		
			var Html = '<div class="loop del-'+totalrowsl+'"><div class="row"><div class="col-md-6"><div class="removable_row"><a href="javascript:void(0)" class="remove_more_entry_results" data-id="'+totalrowsl+'" title="Remove Entry"><i class="fa fa-window-close" aria-hidden="true"></i></a><div class="form-group"><label for="exampleInputEmail1">Select the Learner</label><select class="form-control userselect" name="results[user][]" required><option value="">-Select-</option>'+usersoptions+'</select></div></div></div><div class="col-md-6"><div class="form-group"><label style="display:block;">Upload</label><input type="file" name="results[file][]" accept=".doc,.docx,application/msword"></div></div></div><div class="row">';
			
			for (let i = 1; i <= totalunits; i++) {
				
				Html += '<div class="col-md-3"><div class="form-group"><label>Unit '+i+'</label><select class="form-control" name="results[unit'+i+'][]" required><option value="">-Select-</option>'+unitsOptions+'</select></div></div><div class="col-md-3"><div class="form-group"><label>Grade '+i+'</label><select class="form-control" name="results[grade'+i+'][]" required><option value="">-Select-</option>'+grade+'</select></div></div>';
				
			}
			
			Html += '</div><script>jQuery(".userselect").select2();</script></div><input type="hidden" name="totalunits" value="'+totalunits+'">'; 
			
			jQuery('.appendtabledata').append(Html); 
			jQuery('.totalrowsr').val(totalrowsl);
			
		}
		
	});
	
	jQuery('body').on('click','.remove_more_entry_results',function(){	
	
		var currentDataID = jQuery(this).attr('data-id');
		
		jQuery(".del-" + currentDataID).remove();
		var totalchilds = jQuery('.totalrowsr').val();
		
		var totalchild = parseInt(totalchilds) - 1;
		
        jQuery(".totalrowsr").val(totalchild);
	
	});
	
	
	jQuery('form#custom_learner_results').on('submit', function (e) {
		
		var Rdata = new FormData(this);
		jQuery('.disablebtn').prop('disabled', true);
		jQuery('.displayerror').html('');
		jQuery('.loader').css('display','flex');
		jQuery.ajax({
			type: 'POST',
			dataType: 'json',
			url: rwbObj.ajaxurl,
			data: Rdata,
			success: function (data) {
				jQuery('.loader').css('display','none');
				jQuery('.disablebtn').prop('disabled', false);
				if (data.status == 'fail') {
					var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
					jQuery(data.message).each(function (index, value) {
						errorhtml += '<li>' + value + '</li>';
					});
					errorhtml += '</ul></div>';
					jQuery('.displayerror').html(errorhtml).addClass('error');
				} else {
					
					var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
					jQuery('#custom_learner_results')[0].reset();
					jQuery('.displayerror').html(sucesshtml).addClass('sucess');
					
					setTimeout(function () {
						jQuery('.displayerror').html("").removeClass('sucess');
						location.reload();
					}, 2000);
				}
			},
			cache: false,
			contentType: false,
			processData: false
		});
		e.preventDefault();
	});
	
	
	/* Front Learner Datatable */
	var tableLearners = jQuery('#dashboardlearners').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.Ajaxlearners,
					'data': function (data) {
						
						var quali_filter  = jQuery('.filter_Qualification').val();	
						var from_date 	  = jQuery('#search_start').val();
						var to_date       = jQuery('#search_end').val();
						
						data.searchquali      = quali_filter;	
						data.searchByFromdate = from_date;
						data.searchByTodate   = to_date;
					}
				},
				"deferLoading": rwbObj.total_learners,
				"order": [[0, "desc"]],
				language: {
					searchPlaceholder: "Search By Name",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
			
			/* Learner filter by qualification */
			
			jQuery('#Qualification_btn_filter').click(function () {	
			
			
			
				var filter_Qualification = jQuery('.filter_Qualification').val();				
			
				if (filter_Qualification == '') {					
			
					alert('Please select at least one qualification.');				
			
				} else { 					
			
					tableLearners.draw();				
			
				}			
			
			});						
			
			jQuery('body').on('click', '.clearQualificationfilter', function () {	
			
				
				jQuery('.filter_Qualification').val(null).trigger('change.select2');
				tableLearners.draw();	
			
			});
			
			/* Filter by start and end date */
			
			jQuery('#btn_search').click(function () {
				var from_date = jQuery('#search_start').val();
				var to_date = jQuery('#search_end').val();
				if (from_date == '' || to_date == '') {
					alert('Please enter both Start and End date.');
				} else {
					tableLearners.draw();
				}
			});
			
			jQuery('body').on('click', '.cleardatefilter', function () {
				jQuery('#search_start').val("");
				jQuery('#search_end').val("");
				tableLearners.draw();
			});
			
			/* Load more learners details */
			
			jQuery('body').on('click','.viewinfo',function(){
				
				var userID = jQuery(this).attr('data-user');
				var ID = jQuery(this).attr('data-id');
				
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "get_learners_full_details", userID: userID, ID : ID},
					success: function (data) {
						jQuery('.loader').css('display','none');
						
						var tableHtml = '<table class="table table-striped table-hover"><thead class="table-light"></thead><tbody>';
						
						tableHtml += '<tr><th>Name</th><td>'+data.name+'</td></tr>';
						tableHtml += '<tr><th>Email</th><td><a href="mailto:'+data.email+'">'+data.email+'</a></td></tr>';
						tableHtml += '<tr><th>The Qualification</th><td>'+data.qualification+'</td></tr>';
						tableHtml += '<tr><th>DOB</th><td>'+data.dob+'</td></tr>';
						tableHtml += '<tr><th>Gender</th><td>'+data.gender+'</td></tr>';
						tableHtml += '<tr><th>Ethnicity</th><td>'+data.ethnicity+'</td></tr>';
						tableHtml += '<tr><th>Funding</th><td>'+data.funding+'</td></tr>';
						tableHtml += '<tr><th>Start Date</th><td>'+data.startdate+'</td></tr>';
						tableHtml += '<tr><th>End Date</th><td>'+data.enddate+'</td></tr>';
						tableHtml += '<tr><th>Assessment Language</th><td>'+data.language+'</td></tr>';
						tableHtml += '<tr><th>Registered Date</th><td>'+data.registered+'</td></tr>';
						
						tableHtml += '</tbody></table>';
						
						jQuery('.morelearnersdetailsTitle').text('Learners - '+data.name);
						
						jQuery('.morelearnersdetailsContent').html(tableHtml);
						
						jQuery('.morelearnersdetails').trigger('click');
						
					}
				});
				
			});
			
			/* Load learners results details */
			
			
			jQuery('body').on('click','.viewresults',function(){
				
				var userID = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "get_learners_results", userID: userID },
					success: function (response) {
						jQuery('.loader').css('display','none');
						
						if(response.status == 'fail'){
							
							jQuery('.morelearnersdetailsTitle').text('Learners - '+response.data.name);
						
							jQuery('.morelearnersdetailsContent').html("No results uploaded.");
						
						}else{
							
							jQuery('.morelearnersdetailsTitle').text('Learners - '+response.data.name);
							
							var tableHtml = '<table class="table table-striped table-hover"><thead class="table-light"></thead><tbody>';
							
							tableHtml += '<tr><th>The Qualification</th><td>'+response.data.quali+'</td></tr>';
							
							tableHtml += '<tr align="center"><th colspan="2">Results</th></tr>';
							
							var resultsMeta = response.data.meta;
							
							jQuery(resultsMeta).each(function (index, value) {
								
									if(value.grade == 'Fail' && value.result_resubmit == 0){
										
										var includeResubmitResult = '</span><span class="results-resubmit"><a href="javascript:void(0)">Re-submit Again</a></span>';
										
										tableHtml += '<tr class="failed Unitrow-'+value.id+'"><th><span style="color: #5c2e92;">Unit  -  </span> '+value.unit+'</th><td><span class="chnageunitres">'+value.grade+includeResubmitResult+'</td></tr><tr class="updateresult"><td colspan="2" align="right"><select class="updategradeval-'+value.id+'"><option value="">Select Grade</option><option value="Pass">Pass</option><option value="Merit">Merit</option><option value="Distinction">Distinction</option></select><span class="savegrade"><a href="javascript:void(0)" class="UaveUnitGrade btn btn-sucess" data-id='+value.id+' data-recoard='+value.zoho_result_id+'>Update</a></span><span class="popuploader"><img src="'+rwbObj.pluginurl+'/assets/images/loader.gif" width="6%"></span><span class="unitresponse"></span></td></tr>';
										
									}else{
									
										tableHtml += '<tr><th><span style="color: #5c2e92;">Unit  -  </span> '+value.unit+'</th><td>'+value.grade+'</td></tr>';
										
									}
							});
							
							tableHtml += '<tr align="center"><th colspan="2">&nbsp;</th></tr>';
							
							tableHtml += '<tr><th>Result Uploaded</th><td>'+response.data.created+'</td></tr>';
							
							jQuery('.morelearnersdetailsContent').html(tableHtml);
							
						}
						
						jQuery('.morelearnersdetails').trigger('click');
					}
				});
				
			});
			
			jQuery('body').on('click','.morelearnersdetailsPopupClose',function(){
		
				jQuery('.morelearnersdetailsContent').html("");
		
			});	
			
			/* Learners profile update */
			
			jQuery('form#update_learners_details').on('submit', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('');
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (data) {
						jQuery('.loader').css('display','none');
						jQuery('.disablebtn').prop('disabled', false);
						if (data.status == 'fail') {
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(data.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
						} else {
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
							jQuery('.displayerror').html(sucesshtml).addClass('sucess');
							
							setTimeout(function () {
								jQuery('.displayerror').html("").removeClass('sucess');
								location.reload();
							}, 2000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
			});
			
			
			
			
			/* Front staff Datatable */
			
			var tableStaff = jQuery('#dashboardcenterstaff').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.Ajaxstaff,
					'data': function (data) {
					
					}
				},
				"deferLoading": rwbObj.total_staff,
				"order": [[0, "desc"]],
				language: {
					searchPlaceholder: "Search By Name, Email, Job Title",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
			
			
			/* Add new staff */
			
			jQuery('form#add_staff').on('submit', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('');
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (data) {
						jQuery('.loader').css('display','none');
						jQuery('.disablebtn').prop('disabled', false);
						if (data.status == 'fail') {
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(data.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
						} else {
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
							jQuery('.displayerror').html(sucesshtml).addClass('sucess');
							
							jQuery('#add_staff')[0].reset();
							
							setTimeout(function () {
								jQuery('.displayerror').html("").removeClass('sucess');
								location.reload();
							}, 2000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
			});
			
			
			/* Update Staff */
			
			jQuery('form#update_staff').on('submit', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('');
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (data) {
						jQuery('.loader').css('display','none');
						jQuery('.disablebtn').prop('disabled', false);
						if (data.status == 'fail') {
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(data.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
						} else {
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
							jQuery('.displayerror').html(sucesshtml).addClass('sucess');
							
							setTimeout(function () {
								jQuery('.displayerror').html("").removeClass('sucess');
								location.reload();
							}, 2000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
			});
			
			
			
			/* Download Staff CV using ajax */
			
			jQuery('body').on('click','.resumedownloadmanually',function(){
				
				var ID = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "downlaod_staff_cv", ID: ID },
					success: function (data) {
						jQuery('.loader').css('display','none');
						var obj =  data.url ;
						DownloadFile(obj, data.name);
						
					}
				});
				
			});
			
			/* Delete Staff*/
			
			jQuery('body').on('click','.deletestaff',function(){
				
				var ID = jQuery(this).attr('data-id');
				
				if(confirm("Are you sure, want to delete this staff member from list?")){
				
					jQuery('.loader').css('display','flex');
					jQuery.ajax({
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "delete_staff_recoard", ID: ID },
						success: function (data) {
							jQuery('.loader').css('display','none');
							if (data.status == 'fail') {
								alert(data.message);
							}else{
								tableStaff.draw();
							}
						}
					});
					
				}
				
			});
			
			/* Add Additional Qualification For Learner */
			
			jQuery('form#custom_learner_add_qualification').on('submit', function (e) {
				
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('');
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (data) {
						jQuery('.loader').css('display','none');
						jQuery('.disablebtn').prop('disabled', false);
						if (data.status == 'fail') {
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(data.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
						} else {
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
							jQuery('.displayerror').html(sucesshtml).addClass('sucess');
							
							jQuery('#custom_learner_add_qualification')[0].reset();
							
							setTimeout(function () {
								jQuery('.displayerror').html("").removeClass('sucess');
								location.reload();
							}, 4000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
			});
			
			
		/* centre invoice */	
	
		var  tableInvoice = jQuery('#dashboardcenterinvoices').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.Ajaxinvoice,
					'data': function (data) {
					
					}
				},
				"deferLoading": rwbObj.total_invoice,
				"order": [[0, "desc"]],
				language: {
					searchPlaceholder: "Enter Invoice Number",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
		
			/* Download invoice using ajax */
			
			jQuery('body').on('click','.invoicedownloadmanually',function(){
				
				var ID = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "downlaod_invoice", ID: ID },
					success: function (data) {
						jQuery('.loader').css('display','none');
						var obj =  data.url ;
						DownloadFile(obj, data.name);
						
					}
				});
				
			});
			
			/* Load more invoice details */
			
			jQuery('body').on('click','.invoiceinfo',function(){
				
				
				var ID = jQuery(this).attr('data-id');
				
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "get_invoice_full_details", InvoiceID : ID},
					success: function (data) {
						jQuery('.loader').css('display','none');
						
						var tableHtml = '<table class="table table-striped table-hover"><thead class="table-light"></thead><tbody>';
						
						tableHtml += '<tr><th>Invoice ID</th><td>'+data.xero_invoice_id+'</td></tr>';
						tableHtml += '<tr><th>Invoice Name</th><td>'+data.zoho_product_name+'</td></tr>';
						tableHtml += '<tr><th>Total Learners</th><td>'+data.zoho_invoice_qty+'</td></tr>';
						tableHtml += '<tr><th>Invoice Start Date</th><td>'+data.zoho_invoice_created_date+'</td></tr>';
						tableHtml += '<tr><th>Invoice Due Date</th><td>'+data.zoho_invoice_due_date+'</td></tr>';
						tableHtml += '<tr><th>Invoice Amount</th><td>'+rwbObj.currency+" "+data.amount+'</td></tr>';
						if(data.invoice_discount > 0){
							
							tableHtml += '<tr><th>Invoice Discount(%)</th><td><span style="color:green;font-weight:bold;"> - </span>'+rwbObj.currency+" "+data.calDiscount+' ('+data.invoice_discount+'%)</td></tr>';
						}
						
						if(data.invoice_tax > 0){
							
							tableHtml += '<tr><th>Invoice Tax(%)</th><td>'+rwbObj.currency+" "+data.caltax+' ('+data.invoice_tax+'%)</td></tr>';
						}
						
						tableHtml += '<tr><th>Invoice Type</th><td>'+data.invoice_type+'</td></tr>';
						
						tableHtml += '<tr><th><b>Invoice Total</b></th><td><b>'+rwbObj.currency+" "+data.grandtotal+'</b></td></tr>';
						
						var classbtn = 'bg-success';
						
						if(data.payment_status == 'Pending'){ classbtn = 'bg-warning'; }
						
						tableHtml += '<tr><th>Invoice Status</th><td><span class="btn '+classbtn+'" style="color:#fff;">'+data.payment_status+'</span></td></tr>';
						
						tableHtml += '</tbody></table>';
						
						jQuery('.morelearnersdetailsTitle').text('Invoice Number - '+data.xero_invoice_no);
						
						jQuery('.morelearnersdetailsContent').html(tableHtml);
						
						jQuery('.morelearnersdetails').trigger('click');
						
					}
				});
				
			});
			
			/* Resubmit unit results */
			
			jQuery('body').on('click','.UaveUnitGrade',function(){
				
				var id 		       = jQuery(this).attr('data-id');
				var recoardID      = jQuery(this).attr('data-recoard');
				var updategradeval = jQuery('.updategradeval-'+id).val();
				
				jQuery('.unitresponse').text("").removeClass('rederror');
				
				jQuery('.popuploader').hide();
				
				if(updategradeval == ''){
					
					jQuery('.unitresponse').text("Please select grade from drop down").addClass('rederror');
					
					
				}else{
					
					jQuery('.popuploader').show();
					
					jQuery('.updategradeval-'+id).prop('disabled', true);
					
					jQuery('.UaveUnitGrade').hide();
					
					jQuery('.results-resubmit > a').addClass("disableresubmitbtn");
					
					jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "resubmit_unit_results", ID: id, recoardID: recoardID, updategradeval : updategradeval },
					success: function (response) {
						
						jQuery('.popuploader').hide();
						
						if(response.status == 'fail'){
							
							jQuery('.updategradeval-'+id).prop('disabled', false);
							jQuery('.unitresponse').text(response.message).addClass('rederror');
							jQuery('.results-resubmit > a').removeClass("disableresubmitbtn");
							
						}else{
						
							
							jQuery('.Unitrow-'+id).find('.chnageunitres').text(updategradeval);
							jQuery('.unitresponse').text("Result has been updated successfully.").addClass('greensucess');
							
							setTimeout(function () {
								jQuery('.morelearnersdetailsPopupClose').trigger('click');
							}, 2500);
							
						}
					}
				});
					
					
				}
				
			});
			
			
			/* New Request For EQA to generate report for learnes result  */	
	
		var  tableEQARequest = jQuery('#dashboardEQANewRequest').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.AjaxEQANewRequest,
					'data': function (data) {
						var status_filter  = jQuery('.filter_status').val();
						data.searchstatus      = status_filter;						
					}
				},
				"deferLoading": rwbObj.total_eqa_newrequest,
				"order": [[0, "desc"]],
				language: {
					searchPlaceholder: "Enter Request Number",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
			
			jQuery('#status_btn_filter').click(function () {	
			
			
			
				var statusR = jQuery('.filter_status').val();				
			
				if (statusR == '') {					
			
					alert('Please select at least one status.');				
			
				} else { 					
			
					tableEQARequest.draw();				
			
				}			
			
			});						
			
			jQuery('body').on('click', '.clearstatusfilter', function () {	
			
				
				jQuery('.filter_status').val(null).trigger('change.select2');
				tableEQARequest.draw();	
			
			});
			
			/* request accept button */
			
			jQuery('body').on("click",".requestAccept",function(){
				
					var id = jQuery(this).attr("data-id");
					
					var htmlBody = '<form id="acceptEqarequest" class="acceptEqarequest" method="post"><div class="form-group"><label for="exampleFormControlInput1">Select a date of when it can be done <span class="astrick">*</span></label><input type="text" class="form-control requestsdate" name="acceptdate" value="" autocomplete="off" required><em style="color:red;font-size: 11px;">This date should not be more than 14 days in the future.</em></div><input type="hidden" name="requestid" class="requestid" value="'+id+'"><input type="hidden" name="action" value="accept_request"><input type="submit" value="Submit" class="btn btn-success disablebtnpopup"></form><div class="displayerror" style="margin-top:25px;"></div><script> jQuery( ".requestsdate" ).datepicker({minDate:0,dateFormat: "mm/dd/yy", showOn: "button", buttonImageOnly: true,buttonText: "Select date",buttonImage: rwbObj.pluginurl+"/assets/css/images/calendar.gif",changeMonth: true,changeYear: true,maxDate: new Date(new Date().getFullYear(), 11, 31),yearRange: "1970:+nn"});</script>'; 
				
					jQuery('.morelearnersdetailsContent').html(htmlBody);
					jQuery('.morelearnersdetails').trigger('click');
					
					/* submit accept request by EQA */
			
					jQuery('form#acceptEqarequest').on('submit', function (e) {
						
						var Rdata = new FormData(this);
						
						jQuery('.displayerror').html('');
						jQuery('.disablebtnpopup').prop("disabled",true);
						jQuery('.requestsdate').prop("disabled",true);
						jQuery('.disablebtnpopup').val("Loading...");
						
						jQuery.ajax({
							type: 'POST',
							dataType: 'json',
							url: rwbObj.ajaxurl,
							data: Rdata,
							success: function (data) {
								
								if (data.status == 'fail') {
									
									jQuery('.requestsdate').val("");
									jQuery('.disablebtnpopup').prop("disabled",false);
									jQuery('.requestsdate').prop("disabled",false);
									jQuery('.disablebtnpopup').val("Submit");
									
									var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
									errorhtml += '<li>' + data.message + '</li>';
									
									errorhtml += '</ul></div>';
									jQuery('.displayerror').html(errorhtml).addClass('error');
								} else {
									
									var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
									jQuery('.displayerror').html(sucesshtml).addClass('sucess');
									
									jQuery('#acceptEqarequest')[0].reset();
									
									setTimeout(function () {
										jQuery('.displayerror').html("").removeClass('sucess');
										location.reload();
									}, 4000);
								}
								
							},
							cache: false,
							contentType: false,
							processData: false
						});
						e.preventDefault();
					});
				
			});
			
			/* Request reject by eqa */
			
			jQuery('body').on("click",".requestReject",function(){
				
				var id = jQuery(this).attr("data-id");
				
				if(confirm("Are you sure, want to reject this task")){
					
					jQuery('.loader').css('display','flex');
					
					jQuery('.displayerrorinner').html("").removeClass('error');
					
					jQuery.ajax({
						
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "reject_request_by_eqa", ID: id },
						success: function (data) {
							jQuery('.loader').css('display','none');
							
							if (data.status == 'fail') {
									
									var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
									errorhtml += '<li>' + data.message + '</li>';
									
									errorhtml += '</ul></div>';
									jQuery('.displayerrorinner').html(errorhtml).addClass('error');
									
								} else {
									
									var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + data.message + '</div>';
									jQuery('.displayerrorinner').html(sucesshtml).addClass('sucess');
									
									setTimeout(function () {
										jQuery('.displayerrorinner').html("").removeClass('sucess');
										location.reload();
									}, 5000);
								}
						}
					});
				}
			});
			
			
			/* EQA check learner`s list */
			
			jQuery('body').on('click','.eqaviewresults',function(){
				
				var id = jQuery(this).attr("data-id");
				var result_report_id = jQuery(this).attr("data-rid");
				
				jQuery('.loader').css('display','flex');
				
					jQuery.ajax({
						
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "get_learners_list_for_eqa", ID: id, result_report_id : result_report_id },
						success: function (data) {
							jQuery('.loader').css('display','none');
							var Tablehtml = '<table class="table table table-striped"><thead class="thead-dark"><tr><th scope="col">Name</th><th>Qualification</th><th>View Results</th></tr></thead><tbody>'; 
							jQuery.map( data, function( val, i ) {
							  Tablehtml += '<tr><th>'+val.name+'</th><td>'+val.qname+'</td><td><a class="eqamanageresults" href="javascript:void(0)" title="View learners Results" data-id="'+val.id+'" data-rid="'+val.rid+'"><i class="fa fa-list-alt" aria-hidden="true"></i></a></td></tr>';
							});
							Tablehtml += '</tbody></table>';
							jQuery('.morelearnersdetailsContent').html(Tablehtml);
							jQuery('.morelearnersdetails').trigger('click');
						}
					});
			});
			
	
			
			/* Results display for EQA */
			
			jQuery('body').on('click','.eqamanageresults',function(){
				
				var userID = jQuery(this).attr('data-id');
				var rID = jQuery(this).attr('data-rid');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "get_learners_results", userID: userID },
					success: function (response) {
						jQuery('.loader').css('display','none');
						
						if(response.status == 'fail'){
							
							jQuery('.eqaacesslearnersresultsTitle').text('Learners - '+response.data.name);
						
							jQuery('.morelearnersdetailsContent').html("No results uploaded.");
						
						}else{
							
							jQuery('.eqaacesslearnersresultsTitle').text('Learners - '+response.data.name);
							
							var tableHtml = '<table class="table table-striped table-hover"><thead class="table-light"></thead><tbody>';
							
							tableHtml += '<tr><th>The Qualification</th><td>'+response.data.quali+'</td></tr>';
							
							tableHtml += '<tr align="center"><th colspan="2">Results</th></tr>';
							
							var resultsMeta = response.data.meta;
							
							jQuery(resultsMeta).each(function (index, value) {
								
									if(rID == ''){
										
										var includeResubmitResult = '</span><span class="results-resubmit"><a href="javascript:void(0)">Update Grade</a></span>';
										
										tableHtml += '<tr class="failed Unitrow-'+value.id+'"><th><span style="color: #5c2e92;">Unit  -  </span> '+value.unit+'</th><td><span class="chnageunitres">'+value.grade+includeResubmitResult+'</td></tr><tr class="updateresult"><td colspan="2" align="right"><select class="updategradeval-'+value.id+'"><option value="">Select Grade</option><option value="Pass">Pass</option><option value="Merit">Merit</option><option value="Distinction">Distinction</option><option value="Fail">Fail</option></select><span class="savegrade"><a href="javascript:void(0)" class="UaveUnitGrade btn btn-sucess" data-id='+value.id+' data-recoard='+value.zoho_result_id+'>Update</a></span><span class="popuploader"><img src="'+rwbObj.pluginurl+'/assets/images/loader.gif" width="6%"></span><span class="unitresponse"></span></td></tr>';
										
									}else{
									
										tableHtml += '<tr><th><span style="color: #5c2e92;">Unit  -  </span> '+value.unit+'</th><td>'+value.grade+'</td></tr>';
										
									}
							});
							
							tableHtml += '<tr align="center"><th colspan="2">&nbsp;</th></tr>';
							
							tableHtml += '<tr><th>Result Uploaded</th><td>'+response.data.created+'</td></tr>';
							
							jQuery('.eqaacesslearnersresultsContent').html(tableHtml);
							
						}
						
						jQuery('.eqaacesslearnersresults').trigger('click');
					}
				});
				
			});
			
			/* Front Centre Actions Points Datatable */
			var tableCAP = jQuery('#dashboardcenteractionpoints').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.AjaxCPA,
					'data': function (data) {
						
						var status_filter  = jQuery('.filter_apstatus').val();
						data.searchstatus      = status_filter;		
					}
				},
				"deferLoading": rwbObj.total_cap,
				"order": [[0, "desc"]],
				"searching": false,
				language: {
					searchPlaceholder: "Search By Name",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
			
			jQuery('#apstatus_btn_filter').click(function () {	
			
			
			
				var statusR = jQuery('.filter_apstatus').val();				
			
				if (statusR == '') {					
			
					alert('Please select at least one status.');				
			
				} else { 					
			
					tableCAP.draw();				
			
				}			
			
			});						
			
			jQuery('body').on('click', '.clearapstatusfilter', function () {	
			
				
				jQuery('.filter_apstatus').val(null).trigger('change.select2');
				tableCAP.draw();	
			
			});
			
			/* view actions content by id */
			
			jQuery('body').on('click','.viewinfoaction',function(){
				
				var id = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				
					jQuery.ajax({
						
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "get_centre_action_point_content", ID: id},
						success: function (response) {
							jQuery('.loader').css('display','none');
							jQuery('.morelearnersdetailsTitle').text("Content");
							jQuery('.morelearnersdetailsContent').html(response.content);
							jQuery('.morelearnersdetails').trigger('click');
						}
					});
				
			});
			
			/*  create a popup with form Evidence againt action point */
			
			jQuery('body').on('click','.uploadEvidence',function(){
				
				var id = jQuery(this).attr('data-id');
				
				var html = '<form id="centre_upload_Evidence" method="post" enctype="multipart/form-data"><div class="form-group"><label for="exampleFormControlInput1" style="display: block;">Upload Evidence<span class="astrick">*</span></label><input type="file" name="evidence" autocomplete="off" required><em class="supportfile">Support file pdf,jpg,jpeg,docx,doc,png</em></div><input type="hidden" name="action" value="centre_upload_Evidence"><input type="hidden" name="id" value="'+id+'"><input type="submit" value="Submit" class="btn btn-primary disablebtn"></form><div class="displayerror" style="margin-top: 25px;"></div>';
				
				jQuery('.morelearnersdetailsTitle').text("Upload Evidence");
				jQuery('.morelearnersdetailsContent').html(html);
				jQuery('.morelearnersdetails').trigger('click');
				
			});
			
			/* upload Evidence in wp as well as zoho */
			
			jQuery('body').on('submit','form#centre_upload_Evidence', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('').removeClass('alert alert-danger');
				jQuery('.disablebtn').val('Processing...');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (response) {
						jQuery('.disablebtn').val('Submit');
						
						if(response.status == 'fail'){
						
						var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							errorhtml += '<li>' + response.message + '</li>';
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
							
						}else{
							
							jQuery('#centre_upload_Evidence')[0].reset();
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + response.message + '</div>';
									jQuery('.displayerror').html(sucesshtml).addClass('sucess');
									
									setTimeout(function () {
										jQuery('.displayerror').html("").removeClass('sucess');
										location.reload();
									}, 5000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
		});
		
		/* download evidence */
		
		jQuery('body').on('click','.downloadevidence',function(){
		
			var ID = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "downlaod_centre_upload_evidence", ID: ID },
					success: function (data) {
						jQuery('.loader').css('display','none');
						var obj =  data.url ;
						DownloadFile(obj, data.name);
						
					}
				});
		});	


			/* Front Centre Actions Points Datatable */
			var tableCLR = jQuery('#dashboardclr').DataTable({
				
				responsive: true,
				"processing": true,
				"serverSide": true,
				'serverMethod': 'post',
				'searching': true, // Set false to Remove default Search Control
				'ajax': {
					url: rwbObj.AjaxCLR,
					'data': function (data) {	
					}
				},
				"deferLoading": rwbObj.countlearnersreport,
				"order": [[0, "desc"]],
				"searching": false,
				language: {
					searchPlaceholder: "Search By Name",
					"processing": "<img src='"+rwbObj.pluginurl+"assets/images/loader.gif' alt='loader' width='80' />"
				},
				dom: 'Bfrtip',
				buttons: [
					 'pageLength'
				],
				lengthMenu: [
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
					[10, 50, 100, 250, 500,1000,1500,2500,5000],
				],
				"pageLength": 50,
				/*fixedColumns:   {
					left: 3
				},*/
				'columnDefs': [{
					'targets': [0], // column index (start from 0)
					'orderable': false, // set orderable false for selected columns,
					/*'render': function (data, type, full, meta){
					 return '<input type="checkbox" class="ids" name="id[]" value="' + jQuery('<div/>').text(data).html() + '">';
				  }*/
				}]
			});
			
			
			/* Add Learners Report Bt EQA */
			
			jQuery('body').on('click','.add_entry',function(){
				
				var requestID = jQuery(this).attr('data-id');
				
				jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "get_learners_data_for_report", requestID: requestID },
					success: function (response) {
						jQuery('.loader').css('display','none');
						
						if(response.status == 'fail'){
							
							alert(response.message);
						}else{
							
							
							var formHTML = '<form class="eqa_save_report" id="eqa_save_report" method="post" enctype="multipart/form-data"><div class="row mt-3"><div class="col-md-12"><div class="form-group"><label for="exampleFormControlInput1"><input type="checkbox" name="rpl" value="1">&nbsp;&nbsp;Is RPL being used against this learner</label></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Learner<span class="astrick">*</span></label><select class="form-control popupmselect" name="reportlearners"><option value="">-Select-</option>'; 
							
								jQuery(response.data.learner).each(function (index, value) {
									formHTML += '<option value="'+value.zoho_recoard_id+'">'+value.name+'</option>';
								});
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Qualification<span class="astrick">*</span></label><select class="form-control popupmselect reportqualification" name="reportqualification"><option value="">-Select-</option>';
							
								jQuery(response.data.qualification).each(function (index, value) {
									formHTML += '<option value="'+value.zoho_record_id+'">'+value.name+'</option>';
								});
							
							formHTML += '</select></div></div></div>';
							
							
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Unit Title<span class="astrick">*</span></label><select class="form-control popupmselect reportunit" name="reportunit"></select></div></div></div>';
							
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Grade - based on EQA judgement<span class="astrick">*</span></label><select class="form-control popupmselect" name="grade"><option value="">-Select-</option>';
							
								jQuery(response.data.grade).each(function (index, value) {
									formHTML += '<option value="'+value+'">'+value+'</option>';
								});
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>EQA judgement<span class="astrick">*</span></label><select class="form-control popupmselect" name="judgement"><option value="">-Select-</option><option value="EQA agrees with decision">EQA agrees with decision</option><option value="EQA does not agree with assessment decision">EQA does not agree with assessment decision</option></select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Feedback / Comments<span class="astrick">*</span></label><textarea class="form-control" name="feedback"></textarea></div></div></div>';
							
							formHTML += '<input type="hidden" name="centreID" value="'+response.data.asign_centre+'"><input type="hidden" name="ReportID" value="'+response.data.result_report_id+'"><input type="hidden" name="action" value="save_eqa_submit_learner_report"><input type="submit" value="Save" class="btn btn-primary disablebtn">';
							
							
							formHTML += '</form><div class="displayerror" style="margin-top:25px;"></div><script>jQuery(".popupmselect").select2();</script>';
							
							jQuery('.morelearnersdetailsTitle').text("Learner Report");
							jQuery('.morelearnersdetailsContent').html(formHTML);
							jQuery('.morelearnersdetails').trigger('click');
						}
					}
				});
				
			});
			
			
			jQuery("body").on('change','.reportqualification',function(){
				
				var QID = jQuery(this).val();
				
				if(QID == ''){
					alert("Please select first qualification");
				}else{
					
					jQuery.ajax({
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "get_related_units", QID: QID },
						success: function (response) {
							if(response.status == 'fail'){
								alert(response.message);
							}else{
								console.log(response.data);
								var optionHTML = '<option value="">-Select-</option>';
								jQuery(response.data).each(function (index, value) {
									optionHTML += '<option value="'+value.zoho_unit_id+'">'+value.unit_name+'</option>';
								});
								
								jQuery('.reportunit').html(optionHTML);
							}
							
						}
					});
				
				}
			});
			
			/* submit new entries By EQA */
			
			jQuery('body').on('submit','form#eqa_save_report', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('').removeClass('alert alert-danger');
				jQuery('.disablebtn').val('Processing...');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (response) {
						jQuery('.disablebtn').val('Save');
						
						if(response.status == 'fail'){
						
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(response.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
							
							jQuery('.disablebtn').prop('disabled', false);
							
						}else{
							
							jQuery('#eqa_save_report')[0].reset();
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + response.message + '</div>';
									jQuery('.displayerror').html(sucesshtml).addClass('sucess');
									
									setTimeout(function () {
										jQuery('.displayerror').html("").removeClass('sucess');
										location.reload();
									}, 4000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
		});
		
		
		jQuery('#select_all').on('click',function(){
			if(this.checked){
				jQuery('.checkboxList').each(function(){
					this.checked = true;
				});
			}else{
				 jQuery('.checkboxList').each(function(){
					this.checked = false;
				});
			}
		});
    
		jQuery('.checkboxList').on('click',function(){
			
			if(jQuery('.checkboxList:checked').length == jQuery('.checkboxList').length){
				jQuery('#select_all').prop('checked',true);
			}else{
				jQuery('#select_all').prop('checked',false);
			}
		});
		
		jQuery("body").on("click",".editreportl",function(){
			
			var EditId    = jQuery(this).attr("data-id");
			var requestID = jQuery(this).attr("data-request");
			
			jQuery('.loader').css('display','flex');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: { action: "update_learners_data_for_report", requestID: requestID , EditId : EditId },
					success: function (response) {
						jQuery('.loader').css('display','none');
						
						if(response.status == 'fail'){
							
							alert(response.message);
						}else{
							
		
							
							var RPLchecked = '';
							
							if(response.data.updateData.RPL == 1){
								
								RPLchecked = 'checked';
							}
							
							var formHTML = '<form class="eqa_update_report" id="eqa_update_report" method="post" enctype="multipart/form-data"><div class="row mt-3"><div class="col-md-12"><div class="form-group"><label for="exampleFormControlInput1"><input type="checkbox" name="rpl" value="1" '+RPLchecked+'>&nbsp;&nbsp;Is RPL being used against this learner</label></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Learner<span class="astrick">*</span></label><select class="form-control popupmselect" name="reportlearners"><option value="">-Select-</option>'; 
							
								jQuery(response.data.learner).each(function (index, value) {
									
									if(value.zoho_recoard_id == response.data.updateData.learner_id){
										
										formHTML += '<option value="'+value.zoho_recoard_id+'" selected>'+value.name+'</option>';
										
									}else{
										
										formHTML += '<option value="'+value.zoho_recoard_id+'">'+value.name+'</option>';
									}
									
									
								});
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Qualification<span class="astrick">*</span></label><select class="form-control popupmselect reportqualification" name="reportqualification"><option value="">-Select-</option>';
							
								jQuery(response.data.qualification).each(function (index, value) {
									
									if(value.zoho_record_id == response.data.updateData.qualification_id){
										
										formHTML += '<option value="'+value.zoho_record_id+'" selected>'+value.name+'</option>';
										
									}else{
									
										formHTML += '<option value="'+value.zoho_record_id+'">'+value.name+'</option>';
									
									}
								});
							
							formHTML += '</select></div></div></div>';
							
							
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Unit Title<span class="astrick">*</span></label><select class="form-control popupmselect reportunit" name="reportunit"><option value="">-Select-</option>';
							
							jQuery(response.data.units).each(function (index, value) {
									
									if(value.zoho_unit_id == response.data.updateData.unit_id){
										
										formHTML += '<option value="'+value.zoho_unit_id+'" selected>'+value.unit_name+'</option>';
										
									}else{
									
										formHTML += '<option value="'+value.zoho_unit_id+'">'+value.unit_name+'</option>';
									
									}
								});
							
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Grade - based on EQA judgement<span class="astrick">*</span></label><select class="form-control popupmselect" name="grade"><option value="">-Select-</option>';
							
								jQuery(response.data.grade).each(function (index, value) {
								
									if(value == response.data.updateData.grade){
											formHTML += '<option value="'+value+'" selected>'+value+'</option>';
									}else{
									
											formHTML += '<option value="'+value+'">'+value+'</option>';
									}
								});
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>EQA judgement<span class="astrick">*</span></label><select class="form-control popupmselect" name="judgement"><option value="">-Select-</option>';
							
								jQuery(response.data.judgement).each(function (index, value) {
								
									if(value == response.data.updateData.EQA_judgement){
										
											formHTML += '<option value="'+value+'" selected>'+value+'</option>';
									}else{
									
											formHTML += '<option value="'+value+'">'+value+'</option>';
									}
								});
							
							
							formHTML += '</select></div></div></div>';
							
							formHTML += '<div class="row"><div class="col-md-12"><div class="form-group"><label>Feedback / Comments<span class="astrick">*</span></label><textarea class="form-control" name="feedback">'+response.data.updateData.feedback+'</textarea></div></div></div>';
							
							formHTML += '<input type="hidden" name="updateID" value="'+EditId+'"><input type="hidden" name="centreID" value="'+response.data.asign_centre+'"><input type="hidden" name="ReportID" value="'+response.data.result_report_id+'"><input type="hidden" name="action" value="update_eqa_submit_learner_report"><input type="submit" value="Update" class="btn btn-primary disablebtn">';
							
							
							formHTML += '</form><div class="displayerror" style="margin-top:25px;"></div><script>jQuery(".popupmselect").select2();</script>';
							
							jQuery('.morelearnersdetailsTitle').text("Learner Report");
							jQuery('.morelearnersdetailsContent').html(formHTML);
							jQuery('.morelearnersdetails').trigger('click');
						}
					}
				});
			
		});
		
		
		jQuery('body').on('submit','form#eqa_update_report', function (e) {
		
				var Rdata = new FormData(this);
				jQuery('.disablebtn').prop('disabled', true);
				jQuery('.displayerror').html('').removeClass('alert alert-danger');
				jQuery('.disablebtn').val('Processing...');
				jQuery.ajax({
					type: 'POST',
					dataType: 'json',
					url: rwbObj.ajaxurl,
					data: Rdata,
					success: function (response) {
						jQuery('.disablebtn').val('Update');
						
						if(response.status == 'fail'){
						
							var errorhtml = '<div class="alert alert-danger alert-dismissible fade show removeerror"><ul>';
							jQuery(response.message).each(function (index, value) {
								errorhtml += '<li>' + value + '</li>';
							});
							errorhtml += '</ul></div>';
							jQuery('.displayerror').html(errorhtml).addClass('error');
							
							jQuery('.disablebtn').prop('disabled', false);
							
						}else{
							
							jQuery('#eqa_update_report')[0].reset();
							
							var sucesshtml = '<div class="alert alert-success fade in alert-dismissible fade show removeerror"><strong>Success! </strong>' + response.message + '</div>';
									jQuery('.displayerror').html(sucesshtml).addClass('sucess');
									
									setTimeout(function () {
										jQuery('.displayerror').html("").removeClass('sucess');
										location.reload();
									}, 4000);
						}
					},
					cache: false,
					contentType: false,
					processData: false
				});
				e.preventDefault();
		});
		
		/* delete learner report by EQA */
		
		jQuery("body").on("click",".editreportd",function(){
			
			var deleid = jQuery(this).attr("data-id");
			
			if(confirm("Are you sure, want to delete this entry?")){
				
				jQuery('.loader').css('display','flex');
				
				jQuery.ajax({
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "delete_learner_eqa_report", deleid: deleid },
						success: function (response) {
							jQuery('.loader').css('display','none');
							jQuery('.rowfadout-'+deleid).fadeOut();
							alert(response.message);
						}
					});
			}
			
		});
		
		
		/* Submit learner data by EQA */
		
		jQuery("body").on("click",".submitlreport",function(){
			
			submitIDs = [];
			
			jQuery("input:checkbox[name=checkboxList]:checked").each(function(){
				submitIDs.push($(this).val());
			});
			
			if(submitIDs.length > 0){
				
				jQuery('.loader').css('display','flex');
				
				jQuery.ajax({
						type: 'POST',
						dataType: 'json',
						url: rwbObj.ajaxurl,
						data: { action: "send_leareners_data", ids: submitIDs },
						success: function (response) {
							jQuery('.loader').css('display','none');
							alert(response.message);
							setTimeout(function () {
								location.reload();
							}, 3000);
						}
					});
				
			}else{
				
				alert("Please select at least one entry OR no recoard found.")
			}
			
		});
		
});

function DownloadFile(url, fileName) {
	//Set the File URL.
	jQuery('.customloading').show();
	jQuery.ajax({
		url: url,
		cache: false,
		xhr: function () {
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function () {
				if (xhr.readyState == 2) {
					if (xhr.status == 200) {
						xhr.responseType = "blob";
					} else {
						xhr.responseType = "text";
					}
				}
			};
			return xhr;
		},
		success: function (data) {

			jQuery('.customloading').hide();

			//Convert the Byte Data to BLOB object.
			var blob = new Blob([data], { type: "application/octetstream" });

			//Check the Browser type and download the File.
			var isIE = false || !!document.documentMode;
			if (isIE) {
				window.navigator.msSaveBlob(blob, fileName);
			} else {
				var url = window.URL || window.webkitURL;
				link = url.createObjectURL(blob);
				var a = jQuery("<a />");
				a.attr("download", fileName);
				a.attr("href", link);
				jQuery("body").append(a);
				a[0].click();
				jQuery("body").remove(a);
			}
		}
	});
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}