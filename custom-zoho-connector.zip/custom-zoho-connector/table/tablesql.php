<?php 
class ZOHO_table {

	function create_zoho_unit_table() {
		
		global $wpdb;
		
		$table_1   = $wpdb->prefix . 'zoho_unit';
		$table_2   = $wpdb->prefix . 'custom_qualification';
		$table_3   = $wpdb->prefix . 'learners_results';
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		if ( $wpdb->get_var( "show tables like '$table_1'" ) != $table_1 ) {
		
			$sqlunit = "CREATE TABLE $table_1 (
				id mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
				zoho_unit_id varchar(255) NOT NULL,
				unit_name text NOT NULL,
				quali_zoho_id varchar(255) NOT NULL,
				type varchar(255) NOT NULL,
				created datetime NOT NULL,
				PRIMARY KEY  (id)
				);";
				
			dbDelta( $sqlunit );	
				
		}
		
		
		if ( $wpdb->get_var( "show tables like '$table_2'" ) != $table_2 ) {
		
			$sqlqualification = "CREATE TABLE $table_2 (
				id mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
				zoho_record_id varchar(255) NOT NULL,
				name text NOT NULL,
				date datetime NOT NULL,
				PRIMARY KEY  (id)
				);";
				
			dbDelta( $sqlqualification );	
				
		}
		
	}
}
?>