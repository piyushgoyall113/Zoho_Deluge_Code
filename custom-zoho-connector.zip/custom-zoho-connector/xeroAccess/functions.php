<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require ZOHO_PLUGIN_PATH . 'xeroLib/vendor/autoload.php';
// Use this class to deserialize error caught
use XeroAPI\XeroPHP\AccountingObjectSerializer;

/* Get first Xero authorization */

add_action('wp_ajax_authxerologin','authorization_xero');
add_action('wp_ajax_nopriv_authxerologin','authorization_xero');

function authorization_xero(){
	
	session_start();

 $provider = new \League\OAuth2\Client\Provider\GenericProvider([
    'clientId'                => get_option('xero_client_id'),   
    'clientSecret'            => get_option('xero_client_secret'),
    'redirectUri'             => 'https://atheportal.24livehost.com/wp-admin/admin-ajax.php?action=authxero',
    'urlAuthorize'            => 'https://login.xero.com/identity/connect/authorize',
    'urlAccessToken'          => 'https://identity.xero.com/connect/token',
    'urlResourceOwnerDetails' => 'https://api.xero.com/api.xro/2.0/Organisation'
  ]);

  // Scope defines the data your app has permission to access.
  // Learn more about scopes at https://developer.xero.com/documentation/oauth2/scopes
  $options = [
    'scope' => ['openid email profile offline_access accounting.settings accounting.transactions accounting.contacts accounting.journals.read accounting.reports.read accounting.attachments']
  ];

  // This returns the authorizeUrl with necessary parameters applied (e.g. state).
  $authorizationUrl = $provider->getAuthorizationUrl($options);

  // Save the state generated for you and store it to the session.
  // For security, on callback we compare the saved state with the one returned to ensure they match.
  $_SESSION['oauth2state'] = $provider->getState();

  // Redirect the user to the authorization URL.
  header('Location: ' . $authorizationUrl);
  exit();
	
die;	
}

/* Get code , access token , expire time etc */

add_action('wp_ajax_authxero','token_xero');
add_action('wp_ajax_nopriv_authxero','token_xero');

function token_xero(){
	
	session_start();
	
	$path = ZOHO_PLUGIN_PATH.'front/zohoSync/';
	
	$provider = new \League\OAuth2\Client\Provider\GenericProvider([
	
		'clientId'                => get_option('xero_client_id'),   
		'clientSecret'            => get_option('xero_client_secret'),
		'redirectUri'             => 'https://atheportal.24livehost.com/wp-admin/admin-ajax.php?action=authxero',
		'urlAuthorize'            => 'https://login.xero.com/identity/connect/authorize',
		'urlAccessToken'          => 'https://identity.xero.com/connect/token',
		'urlResourceOwnerDetails' => 'https://api.xero.com/api.xro/2.0/Organisation'
  ]);
  
  $oauth = 0;
  
  $message = '';
  
  
  // If we don't have an authorization code then get one
  if (!isset($_GET['code'])) {
	  
   $oauth = 0;
   
   $message = "Something went wrong, no authorization code found";

  // Check given state against previously stored one to mitigate CSRF attack
  } elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
	  
	  unset($_SESSION['oauth2state']);
	
	$oauth = 0;
	
	 $message = "Invalid state";
	
  } else {
  
    try {
      // Try to get an access token using the authorization code grant.
      $accessToken = $provider->getAccessToken('authorization_code', [
        'code' => $_GET['code']
      ]);
	
           
      $config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$accessToken->getToken() );
      $identityApi = new XeroAPI\XeroPHP\Api\IdentityApi(
        new GuzzleHttp\Client(),
        $config
      );
       
      $result = $identityApi->getConnections();

      update_option('wc_xero_access_token', $accessToken->getToken());
	  
	  update_option('wc_xero_access_token_expires_on',$accessToken->getExpires());
	  
	  update_option('wc_xero_TenantID',$result[0]->getTenantId());
	  
	  update_option('wc_xero_Refresh_Token',$accessToken->getRefreshToken());
	  
	  update_option('wc_xero_ID_Token', $accessToken->getValues()["id_token"]);
	
	$oauth = 1;
	
	 $message = "Xero App Connected";
     
    } catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
		
		$oauth = 0;
		
		 $message = "Token FAILED";
	}
  }
  
  wp_redirect(admin_url('admin.php?page=xero_connect&oauth='.$oauth.'&msg='.$message));
  exit;
	
die;	
}

/* Get xero refesh token */

function xero_refresh_token(){
	
	$provider = new \League\OAuth2\Client\Provider\GenericProvider([
	
      'clientId'                 => get_option('xero_client_id'),   
	  'clientSecret'            => get_option('xero_client_secret'),
      'redirectUri'             => 'https://atheportal.24livehost.com/wp-admin/admin-ajax.php?action=authxero',
      'urlAuthorize'            => 'https://login.xero.com/identity/connect/authorize',
      'urlAccessToken'          => 'https://identity.xero.com/connect/token',
      'urlResourceOwnerDetails' => 'https://identity.xero.com/resources'
    ]);
	
	$status = 0;
	
	try {
	
	$newAccessToken = $provider->getAccessToken('refresh_token', [
      'refresh_token' => get_option('wc_xero_Refresh_Token')
    ]);
	
	// Save my token, expiration and refresh token
    
	update_option('wc_xero_access_token', $newAccessToken->getToken());
	update_option('wc_xero_access_token_expires_on',$newAccessToken->getExpires());
	update_option('wc_xero_Refresh_Token',$newAccessToken->getRefreshToken());
	update_option('wc_xero_ID_Token', $newAccessToken->getValues()["id_token"]);

	$status = 1;	
	
	} catch (\League\OAuth2\Client\Provider\Exception\IdentityProviderException $e) {
		
		$status = 0;
	}
	
	return $status;
}

/* Direct get access token */

add_action('wp_ajax_newToken','newToken_xero');
add_action('wp_ajax_nopriv_newToken','newToken_xero');

function newToken_xero(){
	
	$newToken = xero_refresh_token();
	echo $access_token = get_option('wc_xero_access_token');
die;	
}

/* Get invoice attachment */

//add_action('wp_ajax_invoiceAttachment','invoiceAttachment');
//add_action('wp_ajax_nopriv_invoiceAttachment','invoiceAttachment');
 
function invoiceAttachment(){
	
	$active_access_token = 1;
			
	if(time() > get_option('wc_xero_access_token_expires_on')){
		
		$active_access_token = xero_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$resourceUrl = "https://api.xero.com/api.xro/2.0/Invoice/e326e3f7-e29e-4f0b-b550-621334c9ba75";
		
		$access_token = get_option('wc_xero_access_token');
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		 $response = wp_remote_request( $resourceUrl, array(
										'method' => 'GET',
											'headers' => array(
												'Authorization'  => 'Bearer ' . $access_token,
												'Xero-Tenant-Id' => $xeroTenantId,
												'Accept'         => 'application/json',
												'Content-Type'   => 'application/json',
											)
								));
								
		//echo "<pre>"; print_r($response['body']);	
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

		$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);

		$result = $apiInstance->getOnlineInvoice($xeroTenantId, "e326e3f7-e29e-4f0b-b550-621334c9ba75");
		
		//echo  '<pre>'; print_r($result->getOnlineInvoices()[0]->getOnlineInvoiceUrl());

	}
	
die;	
}

/* After completed payment on Xero update all information as well as in ZOHO */

function update_payment_information_in_zoho_invoce($data){
	
	
	//$path = ZOHO_PLUGIN_PATH.'front/zohoSync/logs.txt';
	
	$UpdateZOHOCenterParam = array();
	$moduleName = $ZohoID = '';
	
	if(!empty($data['zoho_learner_id'])){
		
		$ZohoID 			     = $data['zoho_learner_id'];
		$UpdateZOHOCenterParam[] = array('Is_learners_registered_or_not'=>'Registered');
		$moduleName 			 = 'Learner_Registration';
		
	}else{
		
		$ZohoID 			 = get_invoice_user_id($data['zoho_invoice_id']);
		$UpdateZOHOCenterParam[] = array('Application_Status'=>'Registered');
		$moduleName 			 = 'Center_Registration';
	}
	
	$UpdateZOHOParam[] = array('Status'=> $data['payment_status'],'Xero_payment_ID' => $data['xero_payment_id']);
	
	$active_access_ZOHOtoken = 1;
	if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
	{
		$active_access_ZOHOtoken = get_refresh_token();
	}	

	if($active_access_ZOHOtoken === 1){ 
		
		$ZOHOInvoicedata     = array();
		$ZOHOInvoicedata     = $UpdateZOHOParam;
		$params       	     = array('data'=>$ZOHOInvoicedata);	
		$ResponseData        = update_zoho_data('Invoices', $params, $data['zoho_invoice_id'], 'PUT');
		
		if($data['late_fee'] == 0){
		
			$ZOHOCenterdata     = array();
			$ZOHOCenterdata     = $UpdateZOHOCenterParam;
			$paramsCenter       = array('data'=>$ZOHOCenterdata);
			
			if($data['zoho_invoice_type'] != 'CRIL'){

				$ResponseCenterData        = update_zoho_data($moduleName, $paramsCenter, $ZohoID, 'PUT');	
			}
			
			if(!empty($data['zoho_learner_id'])){
				
				$UpdateZOHOaddimissionParam[] = array('Payment'=> "Paid");
			
				$ZOHOlAdata                      = array();
				$ZOHOlAdata 					 = $UpdateZOHOaddimissionParam;
				$paramslearner_addimission       = array('data'=>$ZOHOlAdata);
				
				$ResponseLaddimissionData        = update_zoho_data("Learners_Admission", $paramslearner_addimission, $data['zoho_learner_addimission_id'], 'PUT');
			
			}
		
		}
	
	}
	
	attach_xero_invoice_pdf($data['InvoiceNumver'],$data['InvoiceID'],$data['zoho_invoice_id']);
}

/* Invoice attachment */

function attach_xero_invoice_pdf($a,$b,$c){
	
	global $wpdb;
	$table = $wpdb->prefix.'zoho_xero_invoice';
	
	$active_access_token = 1;
		
	if(time() > get_option('wc_xero_access_token_expires_on')){
		
		$active_access_token = xero_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$access_token = get_option('wc_xero_access_token');
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

		$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);
		
		try {
			
			$resourceUrl = "https://api.xero.com/api.xro/2.0/Invoice/".$b;
			
			$response = wp_remote_request( $resourceUrl, array(
					'method' => 'GET',
						'headers' => array(
							'Authorization'  => 'Bearer ' . $access_token,
							'Xero-Tenant-Id' => $xeroTenantId,
							'Accept'         => 'application/pdf',
						)
					));
					
			if( !is_wp_error( $response ) ){
				
					$results = $response['body'];	
					
					$file       = $a.'.pdf';
					$targetPath = ZOHO_PLUGIN_PATH.'front/invoice/'.$file; 
					file_put_contents( $targetPath, $results );
					
					$wpdb->update($table,array('attachment'=>$file),array('zoho_invoice_id'=>$c));
					
					/* Attach invoice in ZOHO CRM */
					
					$active_access_ZOHOtoken = 1;
					if(strtotime(current_time('mysql')) > get_option('wc_zoho_access_token_expires_on')) 
					{
						
						$active_access_ZOHOtoken = get_refresh_token();
					}
					
					if($active_access_ZOHOtoken === 1){
					
						$Attachparams = array('file'=>new \CURLFILE($targetPath));
						$SendAttachment = request_zoho_file_upload('Invoices/'.$c.'/Attachments', $Attachparams,'POST');
						
					}
			}
			
			
		}catch (\XeroAPI\XeroPHP\ApiException $e) {
			
			$error = AccountingObjectSerializer::deserialize(
					  $e->getResponseBody(),
					  '\XeroAPI\XeroPHP\Models\Accounting\Error',
					  []
					);
			
			$error->getElements()[0]["validation_errors"][0]["message"];
		  
		}
	}
}

/* How to get online invoice Url from Xero */

function get_xero_invoice_url($invoiceID){
	
	$XeroInvoiceUrl = "";
	
	$active_access_token = 1;
			
	if(time() > get_option('wc_xero_access_token_expires_on')){
		
		$active_access_token = xero_refresh_token();
	}
	
	if($active_access_token === 1){
		
		$access_token = get_option('wc_xero_access_token');
		$xeroTenantId = get_option('wc_xero_TenantID');
		
		// Configure OAuth2 access token for authorization: OAuth2
		$config = XeroAPI\XeroPHP\Configuration::getDefaultConfiguration()->setAccessToken( (string)$access_token );       

		$apiInstance = new XeroAPI\XeroPHP\Api\AccountingApi(
			new GuzzleHttp\Client(),
			$config
		);

		$result = $apiInstance->getOnlineInvoice($xeroTenantId, $invoiceID);
		
		$XeroInvoiceUrl = $result->getOnlineInvoices()[0]->getOnlineInvoiceUrl();
		
	}
	
	return $XeroInvoiceUrl;
}
?>