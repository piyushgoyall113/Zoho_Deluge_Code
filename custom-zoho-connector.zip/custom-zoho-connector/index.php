<?php 
/**
Plugin Name: Zoho CRM Connector
Description: Automatic data synchronizing solution from your package enquiry.
Version: 1.3
Author: Dotsquares
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


// Define ZOHO_ABSPATH.
	if ( ! defined( 'ZOHO_ABSPATH' ) ) {
		define( 'ZOHO_ABSPATH', dirname( __FILE__ ) . '/' );
	}

	define('ZOHO_PLUGIN_URL',plugin_dir_url( __FILE__ ));
	define('ZOHO_PLUGIN_PATH',plugin_dir_path( __FILE__ ));
	
	define('TEMP_FOLDER',ZOHO_PLUGIN_PATH.'temp/');
	
	define('TEMP_URL',site_url().'/wp-content/plugins/custom-zoho-connector/temp/');

	define('ZOHO_CLIENT_ID',get_option('zoho_client_id'));
	define('ZOHO_CLIENT_SECRET',get_option('zoho_client_secret'));
	define('ZOHO_REDIRECT_URL',admin_url('admin-ajax.php').'?action=authzoho');
	define('ZOHO_AUTH_URL','https://accounts.zoho.com/oauth/v2/token');
	define('ZOHO_AUTHTOKEN',get_option('wc_zoho_access_token'));
	define('ZOHO_DOMAIN_URL','https://www.zohoapis.com/crm/v2/');
	
	
	define('XERO_REDIRECT_URL',admin_url('admin-ajax.php').'?action=authxero');
	
	
	include('table/tablesql.php');
	$raphplugin = new ZOHO_table();
	register_activation_hook(__FILE__, array($raphplugin, 'create_zoho_unit_table') );
	
	function theme_options_panel(){
 
		global $_registered_pages;

		add_menu_page( 'Zoho Api Connector', 'Zoho Api Connector', 'manage_options', 'zoho_connect', 'callback_zoho_connect');
		
		add_submenu_page( 'zoho_connect','Xero Api Connector', 'Xero Api Connector', 'manage_options', 'xero_connect', 'callback_xero_connect');

		add_action( 'admin_init', 'register_zoho_api_settings' );
		
		add_action( 'admin_init', 'register_xero_api_settings' );
	}
	add_action('admin_menu', 'theme_options_panel');
	
	function callback_zoho_connect(){
		
		include('admin/view/connect.php');
		
	}
	
	function callback_xero_connect(){
		
		include('admin/view/xeroconnect.php');
		
	}
	
	function register_zoho_api_settings() {
		//register our settings
		register_setting( 'zoho-settings-group', 'zoho_client_id' );
		register_setting( 'zoho-settings-group', 'zoho_client_secret' );
	}
	
	function register_xero_api_settings() {
		//register our settings
		register_setting( 'xero-settings-group', 'xero_client_id' );
		register_setting( 'xero-settings-group', 'xero_client_secret' );
		register_setting( 'xero-settings-group', 'xero_webhook_key' );
		register_setting( 'xero-settings-group', 'xero_currency' );
	}
	
	/* Zoho authorization */
	include('admin/process/auth.php');
	
	/* Inser Applicattion Data In Zoho CRM */
	include('admin/process/InsertapplicationDataCRM.php');
	
	/* display latest registered user on top */
	add_action( 'pre_user_query', 'tgm_order_users_by_date_registered' );
	function tgm_order_users_by_date_registered( $query ) {
		global $pagenow;
		if ( ! is_admin() || 'users.php' !== $pagenow ) {
			return;
		}
		$orderCheck = $_GET['order'];
		if(empty($orderCheck)){
			 $query->query_orderby = 'ORDER BY user_registered DESC';
		}else{
			 $query->query_orderby = 'ORDER BY user_registered '.$orderCheck;
		}
	   
	}

/* Frontend Shortcode */


function frontend_register_styles_script() {
	
	wp_enqueue_style('jquery-ui', ZOHO_PLUGIN_URL.'assets/css/jquery-ui.css');
	
	wp_enqueue_style('select2CustomCss', ZOHO_PLUGIN_URL.'assets/select2/dist/css/select2.min.css');
	
	wp_enqueue_style( 'datatablesCss',  ZOHO_PLUGIN_URL . 'assets/css/datatables.min.css');	
	
	wp_enqueue_style( 'bootstrapmin',  ZOHO_PLUGIN_URL . 'assets/css/bootstrap.min.css');
	
	wp_enqueue_style( 'dataTablesbootstrapmin',  ZOHO_PLUGIN_URL . 'assets/css/dataTables.bootstrap.min.css');
	wp_enqueue_style( 'dataTables.responsive',  ZOHO_PLUGIN_URL . 'assets/css/responsive.bootstrap.min.css');
	
	wp_enqueue_style( 'buttons.dataTables',  ZOHO_PLUGIN_URL . 'assets/css/buttons.dataTables.min.css');
	
	wp_enqueue_style( 'responsive.dataTables.min',  ZOHO_PLUGIN_URL . 'assets/css/responsive.dataTables.min.css');	
	
	wp_enqueue_style('customCss', ZOHO_PLUGIN_URL.'assets/css/customCss.css');
	
	wp_enqueue_script( 'dataTablesJquery',  ZOHO_PLUGIN_URL . 'assets/js/jquery.dataTables.min.js');
	
	wp_enqueue_script( 'bootstrap.min.js',  ZOHO_PLUGIN_URL . 'assets/js/dataTables.bootstrap4.min.js');
	
	wp_enqueue_script('bootstrap.bundle', ZOHO_PLUGIN_URL.'assets/js/bootstrap.bundle.min.js');
	
	wp_enqueue_script( 'bootstrap.button',  ZOHO_PLUGIN_URL . 'assets/js/dataTables.buttons.min.js');	 
	
	wp_enqueue_script('jquery-ui-js', ZOHO_PLUGIN_URL.'assets/js/jquery-ui.js');
	
	wp_enqueue_script('select2Custom', ZOHO_PLUGIN_URL.'assets/select2/dist/js/select2.min.js');
	
	wp_enqueue_script( 'dataTablesresponsive-js',  ZOHO_PLUGIN_URL . 'assets/js/dataTables.responsive.min.js');
	
	wp_enqueue_script('custom', ZOHO_PLUGIN_URL.'assets/js/custom.js');
	
	$ulc_array = array(
		
		'ajaxurl'        		=> admin_url('admin-ajax.php'),
		'site_url'       		=> site_url(),
		'nonce'          		=> wp_create_nonce('ajaxnonce'),
		'pluginurl'      		=> ZOHO_PLUGIN_URL,
		'total_learners' 		=> get_respective_centre_learners(),
		'Ajaxlearners'   		=> ZOHO_PLUGIN_URL.'front/ajax/search_learners.php',
		'Ajaxstaff'      		=> ZOHO_PLUGIN_URL.'front/ajax/search_staff.php',
		'Ajaxinvoice'    		=> ZOHO_PLUGIN_URL.'front/ajax/search_invoice.php',
		'total_staff'    		=> total_center_staff(),
		'total_invoice'  		=> get_respective_centre_invoice(),
		'currency'       		=> get_option('xero_currency'),
		'total_eqa_newrequest'  => count_eqa_all_request(),
		'AjaxEQANewRequest'     => ZOHO_PLUGIN_URL.'front/ajax/AjaxEQANewRequest.php',
		'total_cap'      	    => count_centreActionspoints(),
		'AjaxCPA'      		    => ZOHO_PLUGIN_URL.'front/ajax/centreap.php',
		'countlearnersreport'   => count_learnersreport(),
		'AjaxCLR'      		    => ZOHO_PLUGIN_URL.'front/ajax/clr.php',
		'fundinglist'		    => funding(),
		'ethnicitylist'		    => Ethnicity(),
		'total_operational'     => get_operational_enddate(),
		'AjaxOEC'      		    => ZOHO_PLUGIN_URL.'front/ajax/AjaxOEC.php',
	);
	wp_localize_script( 'custom', 'rwbObj', $ulc_array );
	
}
add_action( 'wp_enqueue_scripts', 'frontend_register_styles_script' );
	


/* Add body loader */
add_action('wp_footer','body_loader');
function body_loader(){
	
	echo '<div class="loader" style="">
			<img src="'.ZOHO_PLUGIN_URL.'/assets/images/loader.gif" alt="loader" />
		</div>';
		
	global $post,$current_user;	
	if( $post->ID == 5) {
		
		$user_roles = $current_user->roles;
		$userID = $current_user->ID;
		if(in_array('applicant',$user_roles)){
			
			$validateID = validate_duplicateCenterID($userID);
			$centerID = get_user_meta($userID, 'centre_id_number',true);
			?>
				<script>
					jQuery(document).ready(function(){
						
						jQuery("#center_number").prop('disabled', true);
						jQuery("#organisation_name").prop('disabled', true);
						jQuery("#center_number").val('<?php echo $centerID?>');
					});
				</script>
			<?php
		}
	}
}



/* Qualification module call here */
include (ZOHO_PLUGIN_PATH.'admin/custom-grid-table/qualification.php');
SP_Plugin::get_instance();

include (ZOHO_PLUGIN_PATH.'admin/custom-grid-table/units.php');
Units_Plugin::get_instance();

/* Registered zoho webhook end point url  */
	include('admin/process/webhook.php');

/* ACF Dynamically load qualification */
	
function acf_load_qualification_field_choices( $field ) {
	
	global $wpdb;
	$table = $wpdb->prefix.'custom_qualification';
	$data  = $wpdb->get_results("SELECT zoho_record_id,name FROM $table ORDER BY id  ASC",ARRAY_A);
    
    // reset choices
    $field['choices'] = array();
    
    // loop through array and add to field 'choices'
	foreach( $data as $listing ) {
      $field['choices'][ $listing['zoho_record_id'] ] = $listing['name'];
   }
   // return the field
    return $field;
    
}
add_filter('acf/load_field/name=_learners_qualification', 'acf_load_qualification_field_choices');	

/* include comman function file for Front */

	function export_learners(){
	
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/export_learners_layout.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[export_learners]' );
	add_shortcode('export_learners', 'export_learners');

	
	function user_register_learners(){
	
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/front_register_learners_layout.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[register_learners]' );
	add_shortcode('register_learners', 'user_register_learners');

	function learners_submit_results(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/front_learner_results_form.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[result_learners]' );
	add_shortcode('result_learners', 'learners_submit_results');


	function Centre_Recognition_Application_Form_Qualification_list(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/qualification_list.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[qualification]' );
	add_shortcode('qualification', 'Centre_Recognition_Application_Form_Qualification_list');

	/* centre manage learners data shortcode */

	function Centre_Manage_Learners(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/centre_manage_leanrners.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[Centre_Learners]' );
	add_shortcode('Centre_Learners', 'Centre_Manage_Learners');
	
	/* Learners profile update */
	
	function learners_update_profile(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/front_learner_profile.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[learners_profile]' );
	add_shortcode('learners_profile', 'learners_update_profile');
	
	/* Manage centre staff  */
	
	function centre_staff(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/centre_staff.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[centre_staff]' );
	add_shortcode('centre_staff', 'centre_staff');
	
	/* Add new staff  */
	
	function centre_add_new_staff(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/add_staff.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[Add_Staff]' );
	add_shortcode('Add_Staff', 'centre_add_new_staff');
	
	
	/* Update staff  */
	
	function update_staff_profile(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/update_staff.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[update_Staff]' );
	add_shortcode('update_Staff', 'update_staff_profile');
	
	
	/* EQAs check learners result */
	
	function eqa_assign_results(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/eqa_results.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[eqa_results]' );
	add_shortcode('eqa_results', 'eqa_assign_results');
	
	
	/* Add More Qualification For learners */
	
	function learners_addmore_qualification(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/LearnersMoreQualification.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[LearnersMoreQualification]' );
	add_shortcode('LearnersMoreQualification', 'learners_addmore_qualification');
	
	/* dashboard prtal */
	
	function centre_dashboard(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/Centre_Dashboard.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[Centre_Dashboard]' );
	add_shortcode('Centre_Dashboard', 'centre_dashboard');
	
	
	/* dashboard invoices */
	
	function centre_invoices(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/invoices.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[invoices]' );
	add_shortcode('invoices', 'centre_invoices');
	
	/* EQA New request panael */
	
	function neq_request_eqa(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/new_request.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[EQARequest]' );
	add_shortcode('EQARequest', 'neq_request_eqa');
	
	/* Submit learners Report By website */
	
	function submit_learners_report(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/submit_learners_report.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[submit_learners_report]' );
	add_shortcode('submit_learners_report', 'submit_learners_report');
	
	/* Centre Action Point panael */
	
	function centre_action_point(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/centre_action_point.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[CAP]' );
	add_shortcode('CAP', 'centre_action_point');
	
	/* Centre learners report  panael */
	
	function centre_learners_report(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/centre_learners_report.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[CLR]' );
	add_shortcode('CLR', 'centre_learners_report');
	
	function centre_learners_report_full(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/centre_learners_report_full.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[CLRF]' );
	add_shortcode('CLRF', 'centre_learners_report_full');
	
	/* check learner register status */
	
	function public_check_learner_register_status(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/public_check_learner_register_status.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[PCLS]' );
	add_shortcode('PCLS', 'public_check_learner_register_status');
	
	
	/* check learner certificate status */
	
	function public_check_learner_certificate_status(){
		
		ob_start();
		include(ZOHO_PLUGIN_PATH.'/front/public_check_learner_certificate_status.php');
		return ob_get_clean();
	}
	
	do_shortcode( '[PCLC]' );
	add_shortcode('PCLC', 'public_check_learner_certificate_status');
	
	include('front/front_process.php');	
	include('front/front_commanFunctions.php'); 
	include('front/ajax/ajaxAction.php'); 
	
	include('front/emailtemplate/email_function.php'); 
	
	include('front/zohoSync/invokeUrlZOHO.php'); 
	
	include('xeroAccess/functions.php'); 
	
	
/* set url rules */
function set_rules_learners() {
	add_rewrite_rule('learner-update/?([^/]*)', 'index.php?pagename=learner-update&userid=$matches[1]', 'top');
	add_rewrite_rule('staff-update/?([^/]*)', 'index.php?pagename=staff-update&staffid=$matches[1]', 'top');
	add_rewrite_rule('eqa-results/?([^/]*)', 'index.php?pagename=eqa-results&ids=$matches[1]', 'top');
	add_rewrite_rule('view-full-report/?([^/]*)', 'index.php?pagename=view-full-report&view=$matches[1]', 'top');
	add_rewrite_rule('submit-learners-report/?([^/]*)', 'index.php?pagename=submit-learners-report&reportID=$matches[1]', 'top');
}
/* set query string parameter in url */
function set_query_vars_learners($vars) {
  $vars[] = 'userid';
  $vars[] = 'staffid';
  $vars[] = 'ids';
  $vars[] = 'view';
  $vars[] = 'reportID';
  return $vars;
}
add_action('init', 'set_rules_learners');
add_filter('query_vars', 'set_query_vars_learners');	

function wpse27856_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','wpse27856_set_content_type' );

// Please edit the address and name below.
 
// Change the From name.
add_filter( 'wp_mail_from_name', function ( $original_email_from ) {
    return 'ATHE';
} );
?>